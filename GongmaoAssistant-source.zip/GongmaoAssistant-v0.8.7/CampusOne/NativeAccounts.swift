import SwiftUI
import WebKit

extension Service {
    var nativeProvider: NativeProvider? {
        switch storeID {
        case "1490809012": return .life798
        case "1152127141": return .xiqueer
        case "1142157881": return .ujing
        case "1264484428": return .quzhi
        default: return nil
        }
    }
}

@MainActor struct AccountAccessView: View {
    let service: Service
    var body: some View {
        if let provider = service.nativeProvider { NativeAccountsView(service: service, provider: provider) }
        else if !service.isBuiltIn { WebAccountsView(service: service) }
        else { CampusEmptyState("未配置原生适配器", systemImage: "lock.shield") }
    }
}

@MainActor struct NativeAccountsView: View {
    @EnvironmentObject private var store: CampusStore
    let service: Service
    let provider: NativeProvider
    @AppStorage("native.account.metadata.v1") private var metadata = Data()
    @AppStorage("native.account.selection.v1") private var selection = Data()
    @State private var alias = ""
    @State private var pending: NativeAccount?
    @State private var legacyPending: WebAccount?
    @State private var clearing = false
    @State private var message = ""
    private var accounts: [NativeAccount] { (try? JSONDecoder().decode([NativeAccount].self, from: metadata)) ?? [] }
    private var selected: [String: UUID] { (try? JSONDecoder().decode([String: UUID].self, from: selection)) ?? [:] }
    var body: some View {
        List {
            Section {
                CampusProviderHeader(service: service, subtitle: provider.loginMethod, status: "认证服务未接通")
            }
            Section {
                if provider == .xiqueer {
                    loginField("学校", placeholder: "选择学校", symbol: "building.2")
                    loginField("教务账号", placeholder: "输入学号", symbol: "person.crop.circle")
                    loginField("密码", placeholder: "输入密码", symbol: "lock")
                } else {
                    loginField("手机号码", placeholder: "+86  输入手机号码", symbol: "phone")
                    if provider == .life798 {
                        loginField("图形验证码", placeholder: "输入图形验证码", symbol: "photo")
                        Button("刷新图形验证码", campusIcon: "arrow.clockwise") {}.disabled(true)
                    }
                    loginField("短信验证码", placeholder: "输入短信验证码", symbol: "message")
                    Button("获取短信验证码", campusIcon: "message") {}.disabled(true)
                }
                Button {} label: {
                    Label("登录并绑定", systemImage: "arrow.right.circle.fill")
                        .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 9)
                }.buttonStyle(.borderedProminent).disabled(true)
            } header: { Text("账号登录") }  footer: { Text("认证尚未接通，暂不收集手机号、学号、密码或验证码。") }
            Section {
                DisclosureGroup("当前接入状态") {
                    Text(provider.blocker).font(.footnote).foregroundStyle(.secondary)
                    Phase6StatusRows(provider: provider)
                }
            }
            Section {
                ForEach(accounts.filter { $0.provider == provider }) { account in
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text(account.alias).font(.headline); Spacer()
                            if selected[provider.rawValue] == account.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(service.color).accessibilityLabel("当前配置") }
                        }
                        Text("未登录 · 仅本地备注").font(.caption).foregroundStyle(.secondary)
                        Button("选择此账号配置") { choose(account) }.disabled(selected[provider.rawValue] == account.id)
                        Button("删除本地配置", role: .destructive) { pending = account }
                    }
                }
                TextField("账号备注，例如 主账号", text: $alias).autocorrectionDisabled()
                Button("添加独立账号配置", campusIcon: "person.badge.plus") { add() }.disabled(!NativeAccount.validAlias(alias))
            } header: { Text("本地账号配置") }  footer: { Text("备注不是账号密码。各平台及各账号使用不同的本地标识与 Keychain 存储命名空间；当前没有真实登录会话。") }
            let legacy = store.webAccounts.filter { $0.serviceID == service.id }
            if !legacy.isEmpty {
                Section("旧版网页会话清理") {
                    ForEach(legacy) { profile in
                        Button("清除旧网页配置：\(profile.name)", role: .destructive) { legacyPending = profile }.disabled(clearing)
                    }
                    Text("旧版网页登录入口已停用，可主动清除对应网站数据。不会影响自定义网页服务。") .font(.footnote).foregroundStyle(.secondary)
                }
            }
            if clearing { ProgressView("正在清理…") }
            if !message.isEmpty { Text(message).font(.footnote).foregroundStyle(.secondary) }
        }.listStyle(.insetGrouped).navigationTitle("账号登录")
         .navigationBarTitleDisplayMode(.inline)
         .confirmationDialog("删除本地账号配置？", isPresented: Binding(get: { pending != nil }, set: { if !$0 { pending = nil } }), titleVisibility: .visible) {
             Button("删除", role: .destructive) { if let account = pending { remove(account) }; pending = nil }
         } message: { Text("清除本地凭证及备注，不会注销服务商账号。") }
         .confirmationDialog("清除旧网页登录数据？", isPresented: Binding(get: { legacyPending != nil }, set: { if !$0 { legacyPending = nil } }), titleVisibility: .visible) {
             Button("确认清除", role: .destructive) {
                 guard let profile = legacyPending else { return }; legacyPending = nil; clearing = true
                 Task { @MainActor in
                     defer { clearing = false }
                     do {
                         if #available(iOS 17.0, *) { try await WKWebsiteDataStore.remove(forIdentifier: profile.id) }
                         store.webAccounts.removeAll { $0.id == profile.id }; message = "旧版网页配置已清除。"
                     } catch { message = "清除失败，请重试。" }
                 }
             }
         } message: { Text("不会删除原平台账号。") }
    }
    private func loginField(_ title: String, placeholder: String, symbol: String) -> some View {
        HStack(spacing: 12) {
            FeatureIcon(symbol: symbol, color: service.color, size: 38)
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.caption.weight(.medium)).foregroundStyle(.secondary)
                Text(placeholder).font(.body).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            Image(systemName: "lock").font(.caption).foregroundStyle(.tertiary)
        }.padding(.vertical, 5).accessibilityElement(children: .combine).accessibilityHint("认证服务未接通，暂不可输入")
    }
    private func add() {
        guard NativeAccount.validAlias(alias) else { return }
        let account = NativeAccount(provider: provider, alias: alias.trimmingCharacters(in: .whitespacesAndNewlines))
        if let data = try? JSONEncoder().encode(accounts + [account]) { metadata = data; choose(account); alias = "" }
        else { message = "保存账号配置失败。" }
    }
    private func choose(_ account: NativeAccount) {
        var values = selected; values[provider.rawValue] = account.id
        if let data = try? JSONEncoder().encode(values) { selection = data }
    }
    private func remove(_ account: NativeAccount) {
        do {
            try KeychainStore().remove(account: account)
            metadata = try JSONEncoder().encode(accounts.filter { $0.id != account.id })
            if selected[provider.rawValue] == account.id {
                var values = selected; values.removeValue(forKey: provider.rawValue); selection = try JSONEncoder().encode(values)
            }
            message = "本地账号配置已删除。"
        } catch { message = "安全存储清理失败，账号配置未确认删除。" }
    }
}
