import SwiftUI
import AVFoundation
import UIKit
import PhotosUI
import Vision
import ImageIO
import UniformTypeIdentifiers

struct ScanView: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State private var raw = ""
    @State private var picking = false
    @State private var scanning = false
    @State private var status = ""
    @State private var selected: UUID?
    @State private var copied = false
    @State private var photoLoading = false
    var matches: [Service] { Routing.matches(raw, services: store.services) }
    var choices: [Service] { matches.isEmpty ? store.services.filter { $0.enabled } : matches }
    var body: some View {
        List {
            Section {
                Button { requestCamera() } label: {
                    HStack(spacing: 14) { FeatureIcon(symbol: "qrcode.viewfinder", size: 58); VStack(alignment: .leading, spacing: 5) { Text("扫描设备二维码").font(.headline); Text("识别后核对服务商").font(.caption).foregroundStyle(.secondary) }; Spacer(); Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary) }
                }.buttonStyle(.plain)
                if photoLoading { ProgressView("正在识别图片…") }
                Button { picking = true } label: { Label("从相册识别二维码", systemImage: "photo") }.disabled(photoLoading)

                if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(.secondary) }
                CampusMultiline(title: "或粘贴设备二维码内容", text: $raw).textInputAutocapitalization(.never).autocorrectionDisabled()
                if !raw.isEmpty { Button("清空") { raw = ""; selected = nil; copied = false } }
            } footer: { Text("只支持标准二维码；专有小程序码、蓝牙设备码等需要各平台支持。相机不可用时可手动粘贴。") }
            if !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Section("识别结果") {
                    if matches.count == 1 { Label("规则匹配：\(matches[0].name)", systemImage: "checkmark.circle").foregroundStyle(.green) }
                    else if matches.count > 1 { Label("多个服务匹配，请手动确认", systemImage: "exclamationmark.triangle").foregroundStyle(.orange) }
                    else { Label("无法确定服务商", systemImage: "questionmark.circle").foregroundStyle(.secondary) }
                    if let host = Routing.httpsURL(raw)?.host { CampusValueRow("二维码域名", value: host) }
                    else { Text("非标准 HTTPS 链接，不自动解析设备信息。") .font(.footnote).foregroundStyle(.secondary) }
                    if choices.isEmpty { Text("没有可用的服务，请先启用服务。") }
                    else {
                        Picker("选择服务", selection: $selected) {
                            Text("请选择").tag(nil as UUID?)
                            ForEach(choices) { service in Text(service.name).tag(Optional(service.id)) }
                        }
                        if let id = selected ?? (matches.count == 1 ? matches[0].id : nil), choices.contains(where: { $0.id == id }) {
                            NavigationLink { ServiceDetail(id: id) } label: { Label("确认并打开服务入口", systemImage: "arrow.up.forward.app") }
                        }
                    }
                    Button(copied ? "已复制" : "复制二维码原文", campusIcon: "doc.on.doc") {
                        UIPasteboard.general.setItems([["public.utf8-plain-text": raw]], options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(120)]); copied = true
                    }
                    Text("打开服务入口不会自动传入设备编号、启动设备或付款。请在原平台确认设备。二维码原文不写入历史。") .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }.navigationTitle("扫一扫").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
            .sheet(isPresented: $picking) {
                CampusPhotoPicker { data in
                    picking = false
                    if let data = data { Task { await readPhoto(data) } }
                }
            }
            .onChange(of: raw) { _ in selected = nil; copied = false }
            .fullScreenCover(isPresented: $scanning) {
                CampusNavigation {
                    CameraScanner(onCode: { code in raw = code; scanning = false }, onError: { text in status = text; scanning = false })
                        .ignoresSafeArea(edges: .bottom).navigationTitle("扫描设备二维码").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { scanning = false } } }
                }
            }
    }
    @MainActor private func readPhoto(_ data: Data) async {
        photoLoading = true; defer { photoLoading = false }
        do {
            guard data.count <= 30_000_000 else { status = "图片超过大小限制。"; return }
            let codes = try await Task.detached(priority: .userInitiated) { () throws -> [String] in
                let request = VNDetectBarcodesRequest(); request.symbologies = [.qr]
                try VNImageRequestHandler(data: data).perform([request])
                return Array(Set((request.results ?? []).compactMap(\.payloadStringValue)))
            }.value
            if codes.count == 1 { raw = codes[0]; status = "已识别相册二维码。" }
            else { raw = ""; status = codes.isEmpty ? "图片中未识别到标准二维码。" : "图片中存在多个二维码，请裁剪后重试。" }
        } catch { status = "图片识别失败。" }
    }
    private func requestCamera() {
        guard AVCaptureDevice.default(for: .video) != nil else { status = "当前设备没有可用相机，可从相册识别或粘贴。"; return }
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: startIfAvailable()
        case .notDetermined:
            Task { if await AVCaptureDevice.requestAccess(for: .video) { startIfAvailable() } else { status = "未授权相机，可在系统设置开启。" } }
        default: status = "相机权限不可用，请前往系统设置，或粘贴原文。"
        }
    }
    private func startIfAvailable() {
        guard AVCaptureDevice.authorizationStatus(for: .video) == .authorized else { status = "相机当前不可用。"; return }
        status = ""; scanning = true
    }
}

// PHPicker grants access only to the selected photo, available since iOS 14.
struct CampusPhotoPicker: UIViewControllerRepresentable {
    let onResult: (Data?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onResult) }
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration(); config.filter = .images; config.selectionLimit = 1
        let picker = PHPickerViewController(configuration: config); picker.delegate = context.coordinator; return picker
    }
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let onResult: (Data?) -> Void
        init(_ onResult: @escaping (Data?) -> Void) { self.onResult = onResult }
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            guard let provider = results.first?.itemProvider else { onResult(nil); return }
            provider.loadDataRepresentation(forTypeIdentifier: UTType.image.identifier) { data, _ in
                DispatchQueue.main.async { self.onResult(data) }
            }
        }
    }
}

struct CameraScanner: UIViewControllerRepresentable {
    let onCode: (String) -> Void
    let onError: (String) -> Void
    func makeUIViewController(context: Context) -> CampusCameraController { CampusCameraController(onCode: onCode, onError: onError) }
    func updateUIViewController(_ uiViewController: CampusCameraController, context: Context) {}
    static func dismantleUIViewController(_ uiViewController: CampusCameraController, coordinator: ()) { uiViewController.stop() }
}
final class CampusCameraController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    private let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "gongmao.qr.camera")
    private var preview: AVCaptureVideoPreviewLayer?
    private var delivered = false
    private var configured = false
    private let onCode: (String) -> Void
    private let onError: (String) -> Void
    private let guide = UIView()
    init(onCode: @escaping (String) -> Void, onError: @escaping (String) -> Void) { self.onCode = onCode; self.onError = onError; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) not supported") }
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = .black
        guide.layer.borderColor = UIColor.white.withAlphaComponent(0.9).cgColor; guide.layer.borderWidth = 2; guide.layer.cornerRadius = 22
        guide.isUserInteractionEnabled = false; view.addSubview(guide)
        let layer = AVCaptureVideoPreviewLayer(session: session); layer.videoGravity = .resizeAspectFill; view.layer.insertSublayer(layer, at: 0); preview = layer
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews(); preview?.frame = view.bounds
        let side = min(view.bounds.width * 0.70, view.bounds.height * 0.55); guide.frame = CGRect(x: (view.bounds.width-side)/2, y: (view.bounds.height-side)/2, width: side, height: side)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        queue.async { [weak self] in
            guard let self = self else { return }
            if !self.configured {
                guard let camera = AVCaptureDevice.default(for: .video), let input = try? AVCaptureDeviceInput(device: camera) else { self.fail(); return }
                self.session.beginConfiguration()
                let output = AVCaptureMetadataOutput()
                guard self.session.canAddInput(input), self.session.canAddOutput(output) else { self.session.commitConfiguration(); self.fail(); return }
                self.session.addInput(input); self.session.addOutput(output)
                guard output.availableMetadataObjectTypes.contains(.qr) else { self.session.commitConfiguration(); self.fail(); return }
                output.setMetadataObjectsDelegate(self, queue: .main); output.metadataObjectTypes = [.qr]
                self.session.commitConfiguration(); self.configured = true
            }
            if !self.session.isRunning { self.session.startRunning() }
        }
    }
    override func viewWillDisappear(_ animated: Bool) { super.viewWillDisappear(animated); stop() }
    func stop() { queue.async { [session] in if session.isRunning { session.stopRunning() } } }
    private func fail() { DispatchQueue.main.async { [weak self] in guard let self = self, !self.delivered else { return }; self.delivered = true; self.onError("相机启动失败，请重试或从相册识别。") } }
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard !delivered, let code = (metadataObjects.first as? AVMetadataMachineReadableCodeObject)?.stringValue, !code.isEmpty else { return }
        delivered = true; stop(); UISelectionFeedbackGenerator().selectionChanged(); onCode(code)
    }
}
