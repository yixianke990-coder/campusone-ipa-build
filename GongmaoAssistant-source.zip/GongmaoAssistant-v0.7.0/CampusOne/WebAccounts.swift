import SwiftUI
import WebKit

@MainActor struct WebAccountsView: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.openURL) private var openURL
    let service: Service
    @State private var name = ""
    @State private var message = ""
    @State private var selected: WebAccount?
    @State private var pending: WebAccount?
    @State private var clearing = false
    @State private var removeProfile = false
    private var sessionLabel: String {
        if #available(iOS 17.0, *) { return "独立会话 · 登录状态由网站确认" }
        return "临时独立会话 · 关闭后需重新登录"
    }
    private var current: Service { store.services.first { $0.id == service.id } ?? service }
    var body: some View {
        List {
            Section("官方登录入口") {
                if let notice = current.phase2Notice { Text(notice).font(.footnote).foregroundStyle(.secondary) }
                if current.miniProgramKeyword != nil { OfficialContainerGuide(service: current) }
                if let url = WebLoginRules.entryURL(current.url) {
                    Text(url.host ?? "").font(.headline).textSelection(.enabled)
                    Text("确认这是服务商或学校提供的官方网页后，再输入账号、密码或验证码。工贸助手 不读取表单内容。") .font(.footnote).foregroundStyle(.secondary)
                    Button("在系统浏览器打开") { openURL(url) }.disabled(!current.enabled)
                    if store.webAccounts.allSatisfy({ !$0.belongs(to: current) }) {
                        Button("创建独立会话并打开", campusIcon: "globe") {
                            let profile = WebAccount(serviceID: current.id, entry: url.absoluteString, name: "默认网页账号")
                            store.webAccounts.append(profile)
                            selected = profile
                        }.disabled(clearing || !current.enabled)
                    }
                } else {
                    Text("尚未配置可用的官方 HTTPS 网页。不能通过此页面登录原生 App。") .foregroundStyle(.secondary)
                }
                NavigationLink { ServiceEditor(service: current) } label: { Label("配置官方网页入口", systemImage: "link") }
                if let url = current.storeURL { Link("原 App 的 App Store 页面", destination: url) }
            }
            Section {
                ForEach(store.webAccounts.filter { $0.serviceID == current.id }) { profile in
                    VStack(alignment: .leading, spacing: 8) {
                        FeatureRow(title: profile.name, subtitle: "本地账号配置", color: current.color)
                        Text(profile.belongs(to: current) ? sessionLabel : "原入口已变更，请清除旧会话后新增账号").font(.caption).foregroundStyle(.secondary)
                        Button("打开账号网页") { selected = profile }.disabled(!profile.belongs(to: current) || clearing || !current.enabled)
                        Button("清除本地登录会话", role: .destructive) { pending = profile; removeProfile = false }.disabled(clearing)
                        Button("删除账号配置", role: .destructive) { pending = profile; removeProfile = true }.disabled(clearing)
                    }
                }
                TextField("新增账号名称，例如 学号尾号", text: $name).autocorrectionDisabled()
                Button("新增独立账号") {
                    guard let url = WebLoginRules.entryURL(current.url), WebLoginRules.validLabel(name) else { return }
                    store.webAccounts.append(WebAccount(serviceID: current.id, entry: url.absoluteString, name: name.trimmingCharacters(in: .whitespacesAndNewlines)))
                    name = ""
                }.disabled(WebLoginRules.entryURL(current.url) == nil || !WebLoginRules.validLabel(name) || clearing || !current.enabled)
                if clearing { ProgressView("正在清除网页数据") }
                if !message.isEmpty { Text(message).font(.footnote) }
            } header: { Text("独立网页登录账号") }  footer: { Text("iOS 17+ 使用独立持久网页容器；iOS 15–16 使用每次打开新建的临时会话，不保存登录 Cookie。清除本地会话不等于在服务商服务器注销；请优先使用网站自身的退出功能。") }
            Section("原生接口状态") {
                Text("此功能是真实网页登录容器，不是原生 API 登录。登录是否成功、验证码、企业微信跳转均由原网站决定。网页会话不会自动同步课表、设备状态、余额或订单。") .font(.footnote).foregroundStyle(.secondary)
            }
        }.navigationTitle(current.name + " · 账号")
        .sheet(item: $selected) { profile in
            if let url = profile.entryURL { WebLoginPage(profile: profile, url: url) }
        }
        .confirmationDialog(removeProfile ? "删除账号配置及本地会话？" : "清除本地登录会话？", isPresented: Binding(get: { pending != nil }, set: { if !$0 { pending = nil } }), titleVisibility: .visible) {
            Button("确认清除", role: .destructive) {
                guard let profile = pending else { return }
                let deleting = removeProfile
                pending = nil; clearing = true; message = ""
                Task { @MainActor in
                    do {
                        if #available(iOS 17.0, *) { try await WKWebsiteDataStore.remove(forIdentifier: profile.id) }
                        if deleting { store.webAccounts.removeAll { $0.id == profile.id } }
                        message = deleting ? "已删除本地账号配置及网站数据。" : "已清除本地网站数据，下次打开需要重新登录（由网站决定）。"
                    } catch { message = "清除失败。请关闭账号网页后重试。" }
                    clearing = false
                }
            }
        } message: { Text("不会删除服务商的账号，也不会撤销服务器端授权。") }
    }
}

@MainActor private final class WebLoginBrowser: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published var host: String
    @Published var loading = true
    @Published var canGoBack = false
    @Published var message = ""
    let webView: WKWebView
    init(profile: WebAccount, url: URL) {
        host = url.host ?? ""
        let config = WKWebViewConfiguration()
        if #available(iOS 17.0, *) { config.websiteDataStore = WKWebsiteDataStore(forIdentifier: profile.id) }
        else { config.websiteDataStore = .nonPersistent() }
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.load(URLRequest(url: url))
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url, WebLoginRules.allowedNavigation(url) else {
            message = "网页尝试打开非 HTTPS 或外部应用链接，已阻止。可返回并使用原平台。"
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url, WebLoginRules.allowedNavigation(url) { webView.load(navigationAction.request) }
        return nil
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { loading = true; message = "" }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) { host = webView.url?.host ?? ""; canGoBack = webView.canGoBack }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { loading = false; host = webView.url?.host ?? ""; canGoBack = webView.canGoBack }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { failed(error) }
    private func failed(_ error: Error) { loading = false; if (error as NSError).code != NSURLErrorCancelled { message = "网页加载失败。请检查网络、官方入口，或使用原 App。" } }
}
private struct WebLoginContent: UIViewRepresentable {
    let view: WKWebView
    func makeUIView(context: Context) -> WKWebView { view }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
@MainActor private struct WebLoginPage: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @StateObject private var browser: WebLoginBrowser
    let profile: WebAccount
    init(profile: WebAccount, url: URL) {
        self.profile = profile
        _browser = StateObject(wrappedValue: WebLoginBrowser(profile: profile, url: url))
    }
    var body: some View {
        CampusNavigation {
            VStack(spacing: 0) {
                HStack(spacing: 8) { Image(systemName: "globe"); Text(browser.host).font(.caption.monospaced()).textSelection(.enabled); Spacer() }.padding(12).background(.thinMaterial)
                if #unavailable(iOS 17.0) { Text("旧版系统：临时会话，关闭后不保留登录状态。" ).font(.caption).foregroundStyle(.secondary).padding(8) }
                if browser.loading { ProgressView("正在打开官方网页…").font(.caption).frame(maxWidth: .infinity).padding(8) }
                if !browser.message.isEmpty { VStack(alignment: .leading, spacing: 8) { Label(browser.message, systemImage: "exclamationmark.circle").font(.footnote); Button("重新加载") { browser.webView.reload() }.buttonStyle(.bordered) }.frame(maxWidth: .infinity, alignment: .leading).padding(12).background(Color.orange.opacity(0.10)) }
                WebLoginContent(view: browser.webView)
            }.navigationTitle(profile.name).navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("关闭") { browser.webView.stopLoading(); dismiss() } }
                    ToolbarItemGroup(placement: .primaryAction) {
                        Button("后退", campusIcon: "chevron.backward") { browser.webView.goBack() }.disabled(!browser.canGoBack)
                        Button("刷新", campusIcon: "arrow.clockwise") { browser.webView.reload() }
                        if let entry = profile.entryURL {
                            Button("在浏览器打开官方入口", campusIcon: "safari") { openURL(entry) }
                        }
                    }
                }
        }
    }
}
