# Muse / Xcode 最终交接指令
请导入本 ZIP 内 CampusOne.xcodeproj 原生 SwiftUI 工程，不要将其转成网页套壳。保持工贸助手原版 iOS Liquid Glass UI、学校蓝金配色、四平台（喜鹊儿、慧生活798、U净、趣智校园）及自定义网页。最低部署 iOS 15，iOS 27 需对应 SDK 验收。
本项目包含 CampusOne 主 target 与 CampusWidgets 扩展 target。请依据 Documentation/RELEASE_070.md 配置真实 bundle ID、App Group、两个 target 的签名与权限；使用支持 iOS 26 API 的 SDK 完整编译，解决实际编译错误，不删除功能逃避错误。验证桌面/锁屏小组件、ActivityKit、灵动岛、App Intents、控制中心、设备认证、课程提醒、备份恢复、扫码、网页会话。iOS 15/16 走兼容路径。
仅将真实测试成功的能力标记为可用。三家设备平台没有正式授权业务 API，当前为官方 App Store 和小程序搜索指引；喜鹊儿 H5 需要本人登录验收。不得模拟登录、余额、订单、设备状态，不得猜测私有接口、小程序 ID、签名算法。原生在线课表仅连接合法授权兼容 JSON。
按 Documentation/UI_REVIEW.md、P0.md 和 RELEASE_070.md 逐项验收。通过构建及签名后才能产出 IPA。若 Muse 不支持 SwiftUI 或扩展签名，明确说明并改用兼容 Xcode 环境。
