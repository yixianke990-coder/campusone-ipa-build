import XCTest
@testable import NativeCore
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
final class NativeCoreTests: XCTestCase {
    func testAllAdaptersUnavailable() { XCTAssertTrue(NativeProvider.allCases.allSatisfy { !NativeRegistry.service(for: $0).isAuthorized }) }
    func testAccountScope() { let id = UUID(); XCTAssertNotEqual(NativeAccount(id: id, provider: .xiqueer, alias: "A").storageKey, NativeAccount(id: id, provider: .ujing, alias: "A").storageKey) }
    func testAliasValidation() { XCTAssertFalse(NativeAccount.validAlias(" \n")); XCTAssertFalse(NativeAccount.validAlias(String(repeating: "a", count: 33))); XCTAssertTrue(NativeAccount.validAlias("主账号")) }
    func testApprovedOrigin() { let o = ApprovedOrigin(url: URL(string: "https://example.com:443/a")!)!; XCTAssertTrue(o.contains(URL(string: "https://example.com/b")!)); for s in ["http://example.com", "https://example.com.evil.test", "https://a@example.com", "https://example.com:444", "https://example.com/#x"] { XCTAssertFalse(o.contains(URL(string: s)!)) } }
    func testReadRejectsMutation() { let url = URL(string: "https://example.com/x")!; var r = URLRequest(url: url); r.httpMethod = "POST"; XCTAssertThrowsError(try ApiClient.validate(r, origin: ApprovedOrigin(url: url)!, purpose: .read)); XCTAssertNoThrow(try ApiClient.validate(r, origin: ApprovedOrigin(url: url)!, purpose: .mutation)) }
    func testReadRejectsBody() { let url = URL(string: "https://example.com/x")!; var r = URLRequest(url: url); r.httpBody = Data([1]); XCTAssertThrowsError(try ApiClient.validate(r, origin: ApprovedOrigin(url: url)!, purpose: .read)) }
    func testMissingAuthorizationNeverSends() async { let url = URL(string: "https://example.invalid/x")!; let client = ApiClient(account: NativeAccount(provider: .life798, alias: "test"), origin: ApprovedOrigin(url: url)!); do { let _: String = try await client.send(URLRequest(url: url), purpose: .read, as: String.self); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) }; await client.close() }
    func testOperationUncertainLocks() throws { var op = PendingOperation(); try op.markSubmitted(); op.markUncertain(); XCTAssertThrowsError(try op.markSubmitted()); try op.reconcile(confirmed: true); XCTAssertEqual(op.state, .confirmed); XCTAssertThrowsError(try op.markSubmitted()) }
    func testOperationRoundtrip() throws { var op = PendingOperation(); try op.markSubmitted(); op.markUncertain(); XCTAssertEqual(try JSONDecoder().decode(PendingOperation.self, from: JSONEncoder().encode(op)), op) }
    func testUjingQR() { for scheme in ["http", "https"] { XCTAssertTrue(NativeQR.ujingCandidate("\(scheme)://app.littleswan.com/u_download.html?type=Ujing&uuid=example")) } }
    func testUjingQRRejectsLookalikes() { for s in ["https://app.littleswan.com.evil.test/u_download.html?type=Ujing&uuid=x", "https://app.littleswan.com/u_download.html?type=Ujing&uuid=x&uuid=y", "https://app.littleswan.com/u_download.html?type=Ujing", "https://app.littleswan.com/u_download.html?type=Ujing&uuid=%20", "https://app.littleswan.com/wrong?type=Ujing&uuid=x", "https://u@app.littleswan.com/u_download.html?type=Ujing&uuid=x"] { XCTAssertFalse(NativeQR.ujingCandidate(s)) } }
    func testRegistryStatusFailsClosed() async { let a = NativeAccount(provider: .xiqueer, alias: "test"); do { _ = try await NativeRegistry.service(for: a.provider).sessionStatus(account: a); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) } }
    func testLoginFailsClosed() async { let a = NativeAccount(provider: .xiqueer, alias: "test"); let service = NativeRegistry.service(for: a.provider); do { _ = try await service.beginLogin(account: a, input: .schoolAccount(schoolReference: "sample", account: "sample", password: "synthetic")); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) } }
    func testChallengeFailsClosed() async { let a = NativeAccount(provider: .life798, alias: "test"); do { _ = try await NativeRegistry.service(for: a.provider).completeLogin(account: a, challenge: "sample", response: "synthetic"); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) } }

}
