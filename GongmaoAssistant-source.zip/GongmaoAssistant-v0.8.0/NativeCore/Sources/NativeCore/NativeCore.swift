import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if canImport(Security)
import Security
#endif

public enum NativeProvider: String, Codable, CaseIterable, Sendable {
    case life798, xiqueer, ujing, quzhi
    public var title: String {
        switch self { case .life798: return "慧生活798"; case .xiqueer: return "喜鹊儿"; case .ujing: return "U净"; case .quzhi: return "趣智校园" }
    }
    public var loginMethod: String {
        switch self { case .life798: return "手机号码 · 官方验证码流程"; case .xiqueer: return "学校选择 · 教务账号"; case .ujing: return "手机号码 · 官方授权"; case .quzhi: return "厂商 SDK 提供的登录方式" }
    }
    public var blocker: String {
        switch self { case .life798: return "需要厂商分配应用身份、验证码及业务接口授权。"; case .xiqueer: return "需要学校或教务服务商授权的认证、会话及课表接口。"; case .ujing: return "需要正式认证、订单、设备及支付接口授权。"; case .quzhi: return "需要厂商正式 SDK 或授权业务接口。" }
    }
}
public struct NativeAccount: Codable, Equatable, Identifiable, Sendable {
    public let id: UUID
    public let provider: NativeProvider
    public var alias: String
    public init(id: UUID = UUID(), provider: NativeProvider, alias: String) { self.id = id; self.provider = provider; self.alias = alias }
    public static func validAlias(_ text: String) -> Bool {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return !trimmed.isEmpty && trimmed.count <= 32 && !trimmed.unicodeScalars.contains { CharacterSet.controlCharacters.contains($0) }
    }
    public var storageKey: String { provider.rawValue + "." + id.uuidString }
}
public enum NativeAPIError: Error, Equatable, LocalizedError {
    case authorizationMissing, invalidEndpoint, unsafeMethod, invalidResponse, http(Int), emptyBody, decoding, keychain(Int32), unavailable, unresolvedOperation
    public var errorDescription: String? {
        switch self { case .authorizationMissing: return "尚未取得平台原生接口授权。"; case .invalidEndpoint: return "接口地址不在授权范围内。"; case .unsafeMethod: return "请求方法与业务类型不一致。"; case .invalidResponse: return "服务器响应无效。"; case .http(let code): return "请求失败（HTTP \(code)）。"; case .emptyBody: return "服务器没有返回业务数据。"; case .decoding: return "暂不能解析此接口响应。"; case .keychain: return "安全存储操作失败。"; case .unavailable: return "当前环境不支持此功能。"; case .unresolvedOperation: return "前一次操作结果尚未确认，请先核对订单。" }
    }
}
// Provider-specific adapters implement this contract only after written approval.
// The release registry below deliberately has NO authorized adapter or endpoint.
public protocol PlatformService: Sendable {
    var provider: NativeProvider { get }
    var isAuthorized: Bool { get }
    func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome
    func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome
    func sessionStatus(account: NativeAccount) async throws -> NativeSessionState
    func signOut(account: NativeAccount) async throws
}
// These inputs are transient, never Codable or persisted. The provider must define
// their meaning and enforce its own challenge, consent, and session validation.
public enum NativeLoginInput: Sendable {
    case schoolAccount(schoolReference: String, account: String, password: String)
    case phoneChallenge(phone: String)
}
public enum NativeLoginOutcome: Equatable, Sendable {
    case challengeRequired(reference: String)
    case authenticated
}
public enum NativeSessionState: Equatable, Sendable { case signedOut, valid, expired }
public struct UnavailablePlatformService: PlatformService {
    public let provider: NativeProvider
    public var isAuthorized: Bool { false }
    public init(provider: NativeProvider) { self.provider = provider }
    public func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome { throw NativeAPIError.authorizationMissing }
    public func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome { throw NativeAPIError.authorizationMissing }
    public func sessionStatus(account: NativeAccount) async throws -> NativeSessionState { throw NativeAPIError.authorizationMissing }
    public func signOut(account: NativeAccount) async throws { throw NativeAPIError.authorizationMissing }
}
public enum NativeRegistry {
    public static func service(for provider: NativeProvider) -> any PlatformService { UnavailablePlatformService(provider: provider) }
}
// Authentication input is intentionally not collected in the release UI. The approved
// adapter must supply its own documented login/challenge flows and response mapping.
public struct ApprovedOrigin: Equatable, Sendable {
    public let host: String
    public let port: Int
    public init?(url: URL) {
        guard let c = URLComponents(url: url, resolvingAgainstBaseURL: false), c.scheme?.lowercased() == "https", let host = c.host?.lowercased(), !host.isEmpty, c.user == nil, c.password == nil, c.fragment == nil, (1...65535).contains(c.port ?? 443) else { return nil }
        self.host = host; self.port = c.port ?? 443
    }
    public func contains(_ url: URL) -> Bool { ApprovedOrigin(url: url) == self }
}
public enum RequestPurpose: Sendable { case read, mutation }
public protocol RequestAuthorizer: Sendable {
    func authorize(_ request: URLRequest, account: NativeAccount) async throws -> URLRequest
}
public struct MissingAuthorizer: RequestAuthorizer {
    public init() {}
    public func authorize(_ request: URLRequest, account: NativeAccount) async throws -> URLRequest { throw NativeAPIError.authorizationMissing }
}
private final class NoRedirect: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
// One client per account, isolated ephemeral session, no global Cookie jar, no redirects.
// There is no automatic application-level retry, including on transport errors.
public actor ApiClient {
    private let account: NativeAccount
    private let origin: ApprovedOrigin
    private let authorizer: any RequestAuthorizer
    private let session: URLSession
    public init(account: NativeAccount, origin: ApprovedOrigin, authorizer: any RequestAuthorizer = MissingAuthorizer()) {
        self.account = account; self.origin = origin; self.authorizer = authorizer
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 15; config.timeoutIntervalForResource = 30
        config.httpMaximumConnectionsPerHost = 4; config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.urlCache = nil; config.urlCredentialStorage = nil
        config.httpShouldSetCookies = false; config.httpCookieStorage = nil
        session = URLSession(configuration: config, delegate: NoRedirect(), delegateQueue: nil)
    }
    public static func validate(_ request: URLRequest, origin: ApprovedOrigin, purpose: RequestPurpose) throws {
        guard let url = request.url, origin.contains(url) else { throw NativeAPIError.invalidEndpoint }
        let method = (request.httpMethod ?? "GET").uppercased()
        switch purpose {
        case .read: guard ["GET", "HEAD"].contains(method), request.httpBody == nil, request.httpBodyStream == nil else { throw NativeAPIError.unsafeMethod }
        case .mutation: guard ["POST", "PUT", "PATCH", "DELETE"].contains(method) else { throw NativeAPIError.unsafeMethod }
        }
    }
    public func send<T: Decodable>(_ request: URLRequest, purpose: RequestPurpose, as type: T.Type) async throws -> T {
        try Self.validate(request, origin: origin, purpose: purpose)
        let authorized = try await authorizer.authorize(request, account: account)
        try Self.validate(authorized, origin: origin, purpose: purpose)
        let (data, response) = try await session.data(for: authorized)
        guard let http = response as? HTTPURLResponse, let url = http.url, origin.contains(url) else { throw NativeAPIError.invalidResponse }
        guard (200...299).contains(http.statusCode) else { throw NativeAPIError.http(http.statusCode) }
        guard !data.isEmpty else { throw NativeAPIError.emptyBody }
        do { return try JSONDecoder().decode(type, from: data) } catch { throw NativeAPIError.decoding }
    }
    public func close() { session.invalidateAndCancel() }
}
// A durable operation record can be saved by a future authorized adapter before sending.
// Unknown outcome stays locked; it does not imply failure or permit automatic retry.
public struct PendingOperation: Codable, Equatable, Sendable {
    public enum State: String, Codable, Sendable { case prepared, submitted, uncertain, confirmed, rejected }
    public let id: UUID
    public private(set) var state: State
    public init(id: UUID = UUID()) { self.id = id; state = .prepared }
    public mutating func markSubmitted() throws { guard state == .prepared else { throw NativeAPIError.unresolvedOperation }; state = .submitted }
    public mutating func markUncertain() { if state == .submitted { state = .uncertain } }
    public mutating func reconcile(confirmed: Bool) throws { guard state == .submitted || state == .uncertain else { throw NativeAPIError.unresolvedOperation }; state = confirmed ? .confirmed : .rejected }
}
public struct KeychainStore: Sendable {
    public init() {}
    #if canImport(Security)
    private func query(_ account: NativeAccount) -> [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "GongmaoAssistant.native-session.v1", kSecAttrAccount as String: account.storageKey] }
    #endif
    public func save(_ data: Data, account: NativeAccount) throws {
        #if canImport(Security)
        let q = query(account)
        let status = SecItemUpdate(q as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return }
        guard status == errSecItemNotFound else { throw NativeAPIError.keychain(status) }
        var item = q; item[kSecValueData as String] = data; item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let added = SecItemAdd(item as CFDictionary, nil); guard added == errSecSuccess else { throw NativeAPIError.keychain(added) }
        #else
        throw NativeAPIError.unavailable
        #endif
    }
    public func load(account: NativeAccount) throws -> Data? {
        #if canImport(Security)
        var q = query(account); q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?; let status = SecItemCopyMatching(q as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }; guard status == errSecSuccess, let data = result as? Data else { throw NativeAPIError.keychain(status) }; return data
        #else
        throw NativeAPIError.unavailable
        #endif
    }
    public func remove(account: NativeAccount) throws {
        #if canImport(Security)
        let status = SecItemDelete(query(account) as CFDictionary); guard status == errSecSuccess || status == errSecItemNotFound else { throw NativeAPIError.keychain(status) }
        #else
        throw NativeAPIError.unavailable
        #endif
    }
}
// The QR pattern is third-party reported, not a verified device or authorization.
// HTTP is accepted ONLY for offline recognition; no URL is opened or requested.
public enum NativeQR {
    public static func ujingCandidate(_ raw: String) -> Bool {
        guard raw.utf8.count <= 4096, let c = URLComponents(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
              ["http", "https"].contains(c.scheme?.lowercased() ?? ""), c.host?.lowercased() == "app.littleswan.com",
              c.user == nil, c.password == nil, c.port == nil, c.fragment == nil, c.percentEncodedPath == "/u_download.html" else { return false }
        let items = c.queryItems ?? []
        let types = items.filter { $0.name == "type" }, ids = items.filter { $0.name == "uuid" }
        guard types.count == 1, types[0].value == "Ujing", ids.count == 1, let id = ids[0].value, !id.isEmpty, id.utf8.count <= 256 else { return false }
        return !id.unicodeScalars.contains { CharacterSet.whitespacesAndNewlines.contains($0) || CharacterSet.controlCharacters.contains($0) }
    }
}
