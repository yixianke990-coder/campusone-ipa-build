import SwiftUI
import UIKit

@main struct CampusOneApp: App {
    @StateObject private var store = CampusStore()
    @AppStorage("appearance") private var appearance = "system"
    var body: some Scene {
        WindowGroup { CampusPrivacyGate { RootView() }.environmentObject(store).tint(Color(uiColor: UIColor { traits in traits.userInterfaceStyle == .dark ? UIColor(red: 0.55, green: 0.74, blue: 0.99, alpha: 1) : UIColor(red: 0.10, green: 0.29, blue: 0.48, alpha: 1) })).preferredColorScheme(appearance == "light" ? .light : appearance == "dark" ? .dark : nil) }
    }
}

enum MainTab: Hashable { case home, courses, services, settings, search }

struct RootView: View {
    @State private var tab: MainTab = .home
    @State private var systemScan = false
    @Environment(\.scenePhase) private var phase
    @EnvironmentObject private var store: CampusStore
    var body: some View {
        Group {
            if #available(iOS 26, *) { modernTabs.tabBarMinimizeBehavior(.onScrollDown) }
            else if #available(iOS 18, *) { modernTabs }
            else { legacyTabs }
        }
        .sheet(isPresented: $systemScan) { CampusNavigation { ScanView() } }
        .onReceive(NotificationCenter.default.publisher(for: CampusShared.routeNotification)) { _ in consumeRoute() }
        .onChange(of: phase) { value in if value == .active { consumeRoute(); CampusWidgetBridge.publish(store); Task { await CampusLiveTimer.reconcile(store.timers) } } }
        .onChange(of: store.courses) { _ in CampusWidgetBridge.publish(store); Task { await CampusCourseReminders.cancel() } }
        .onChange(of: store.onlineSnapshot) { _ in CampusWidgetBridge.publish(store); Task { await CampusCourseReminders.cancel() } }
        .onChange(of: store.term) { _ in CampusWidgetBridge.publish(store); Task { await CampusCourseReminders.cancel() } }
        .task { consumeRoute(); CampusWidgetBridge.publish(store); await CampusLiveTimer.reconcile(store.timers) }
        .alert("保存失败", isPresented: Binding(get: { store.storageError != nil }, set: { if !$0 { store.storageError = nil } })) {
            Button("确定", role: .cancel) { store.storageError = nil }
        } message: { Text(store.storageError ?? "") }
    }
    private func consumeRoute() { if let route = CampusShared.consume() { navigate(route) } }
    private func navigate(_ route: CampusSystemRoute) {
        switch route { case .home: tab = .home; case .courses: tab = .courses; case .services: tab = .services; case .settings: tab = .settings; case .scan: tab = .home; systemScan = true }
    }
    @available(iOS 18.0, *)
    private var modernTabs: some View {
        TabView(selection: $tab) {
            Tab("首页", systemImage: "house", value: MainTab.home) { CampusNavigation { HomeView(tab: $tab) } }
            Tab("课表", systemImage: "calendar", value: MainTab.courses) { CampusNavigation { CoursesView() } }
            Tab("服务", systemImage: "square.grid.2x2", value: MainTab.services) { CampusNavigation { ServicesView() } }
            Tab("设置", systemImage: "gearshape", value: MainTab.settings) { CampusNavigation { SettingsView() } }
            Tab(value: MainTab.search, role: .search) { CampusNavigation { SearchView() } }
        }
    }
    private var legacyTabs: some View {
        TabView(selection: $tab) {
            CampusNavigation { HomeView(tab: $tab) }.tabItem { Label("首页", systemImage: "house") }.tag(MainTab.home)
            CampusNavigation { CoursesView() }.tabItem { Label("课表", systemImage: "calendar") }.tag(MainTab.courses)
            CampusNavigation { ServicesView() }.tabItem { Label("服务", systemImage: "square.grid.2x2") }.tag(MainTab.services)
            CampusNavigation { SettingsView() }.tabItem { Label("设置", systemImage: "gearshape") }.tag(MainTab.settings)
            CampusNavigation { SearchView() }.tabItem { Label("搜索", systemImage: "magnifyingglass") }.tag(MainTab.search)
        }
    }

}

extension Service {
    var color: Color {
        switch tint { case "blue": .blue; case "orange": .orange; case "indigo": .indigo; case "teal": .teal; default: .green }
    }
}
struct ServiceIcon: View {
    let service: Service
    var body: some View {
        FeatureIcon(symbol: service.symbol, color: service.color, size: 50)
    }
}
struct ServiceRow: View {
    let service: Service
    var body: some View {
        HStack(spacing: 12) {
            ServiceIcon(service: service)
            VStack(alignment: .leading, spacing: 4) {
                Text(service.name).font(.headline)
                Text(service.category + (service.isBuiltIn ? " · 原生待授权" : " · 网页服务")).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
    }
}
struct HomeView: View {
    @EnvironmentObject private var store: CampusStore
    @Binding var tab: MainTab
    @Environment(\.dynamicTypeSize) private var typeSize
    @State private var scan = false
    var today: [Course] { store.displayedCourses.filter { course in
        guard course.weekday == Course.today() else { return false }
        if store.term.name.isEmpty { return course.detail?.term.isEmpty ?? true }
        guard let week = store.term.currentWeek() else { return false }
        return store.term.includes(course, week: week)
    }.sorted { $0.start < $1.start } }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack(alignment: .center, spacing: 16) {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("工贸 · 校园生活", systemImage: "graduationcap.fill").font(.caption.weight(.semibold)).foregroundStyle(Color(red: 0.96, green: 0.85, blue: 0.63))
                        Text("学习与生活").font(.title.bold()).foregroundStyle(.white)
                        Text(Date.now.formatted(.dateTime.month().day().weekday(.wide))).font(.subheadline).foregroundStyle(.white.opacity(0.85))
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "graduationcap.fill").font(.system(size: 46, weight: .light)).foregroundStyle(.white.opacity(0.85)).accessibilityHidden(true)
                }.padding(20).frame(maxWidth: .infinity, alignment: .leading)
                 .background(LinearGradient(colors: [Color(red: 0.10, green: 0.23, blue: 0.39), Color(red: 0.16, green: 0.36, blue: 0.57)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                 .accessibilityElement(children: .combine)
                HStack(spacing: 10) {
                    Button { tab = .courses } label: { CampusQuickAction(title: "课表", symbol: "calendar", color: .blue) }.buttonStyle(.plain)
                    Button { scan = true } label: { CampusQuickAction(title: "扫一扫", symbol: "qrcode.viewfinder", color: .teal) }.buttonStyle(.plain)
                    Button { tab = .search } label: { CampusQuickAction(title: "搜索", symbol: "magnifyingglass", color: .indigo) }.buttonStyle(.plain)
                }
                VStack(alignment: .leading, spacing: 12) {
                    HStack { Label("今日课程", systemImage: "calendar").font(.headline); Spacer(); Button("完整课表") { tab = .courses }.font(.subheadline) }
                    if today.isEmpty { Text(store.displayedCourses.isEmpty ? "尚未导入课表" : "今日暂无课程").font(.title2.bold()); Text(store.displayedCourses.isEmpty ? "同步在线课表或手动添加课程后显示。" : "请以学校最新安排为准。").font(.subheadline).foregroundStyle(.secondary) }
                    else { Text("共 \(today.count) 节课程记录").font(.caption.weight(.medium)).foregroundStyle(.secondary); ForEach(today) { course in NavigationLink { CourseInspection(course: course) } label: { CourseRow(course: course) }.buttonStyle(.plain) } }
                    if let snapshot = store.onlineSnapshot { Label("缓存更新：" + snapshot.syncedAt.formatted(date: .omitted, time: .shortened), systemImage: "clock").font(.caption).foregroundStyle(.secondary) }
                    else { Label("本地课表 · 未连接在线数据", systemImage: "internaldrive").font(.caption).foregroundStyle(.secondary) }
                }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                HStack { Text("我的服务").font(.title2.bold()); Spacer(); Button("管理") { tab = .services } }
                Text("学习、生活与个人网页入口").font(.subheadline).foregroundStyle(.secondary)
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: typeSize.isAccessibilitySize ? 1 : 2), spacing: 12) {
                    ForEach(store.services.filter { $0.enabled && $0.showOnHome }) { service in
                        NavigationLink { ServiceDetail(id: service.id) } label: {
                            VStack(alignment: .leading, spacing: 9) { HStack { ServiceIcon(service: service); Spacer(minLength: 0); Image(systemName: "arrow.up.right").font(.caption).foregroundStyle(.tertiary) }; Text(service.name).font(.headline).foregroundStyle(.primary); Text(service.category).font(.caption).foregroundStyle(.secondary) }
                                .frame(maxWidth: .infinity, alignment: .leading).padding(14).background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                        }.buttonStyle(.plain)
                    }
                    Button { tab = .services } label: {
                        VStack(alignment: .leading, spacing: 9) { FeatureIcon(symbol: "plus", color: .secondary, size: 50); Text("添加服务").font(.headline).foregroundStyle(.primary); Text("自定义网页").font(.caption).foregroundStyle(.secondary) }.frame(maxWidth: .infinity, alignment: .leading).padding(14).background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    }.buttonStyle(.plain)
                }
                Button { scan = true } label: {
                    HStack(spacing: 14) { Image(systemName: "qrcode.viewfinder").font(.largeTitle); VStack(alignment: .leading) { Text("扫一扫").font(.headline); Text("精确匹配 · 手动确认").font(.caption) }; Spacer(); Image(systemName: "chevron.right") }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
                }.buttonStyle(.borderedProminent).buttonBorderShape(.roundedRectangle(radius: 22))
                Label("各平台独立登录，扫码后需确认服务。", systemImage: "lock.shield").font(.caption).foregroundStyle(.secondary)
            }.padding(16)
        }.background(Color(uiColor: .systemGroupedBackground)).navigationTitle("工贸助手")
            .sheet(isPresented: $scan) { CampusNavigation { ScanView() } }
    }
}

struct SearchView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var query = ""
    private var keyword: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var services: [Service] { store.services.filter { $0.enabled && (keyword.isEmpty || ($0.name + $0.category).localizedCaseInsensitiveContains(keyword)) } }
    private var courses: [Course] { store.displayedCourses.filter { !keyword.isEmpty && ($0.name + $0.location + ($0.detail?.teacher ?? "")).localizedCaseInsensitiveContains(keyword) } }
    private var features: [(Service, String)] {
        guard !keyword.isEmpty else { return [] }
        return store.services.filter(\.enabled).flatMap { service in
            let groups = service.storeID == "1152127141" ? AcademicCenter.groups : (ProviderEvidence.forService(service)?.groups ?? [])
            return groups.flatMap { $0.1 }.filter { $0.localizedCaseInsensitiveContains(keyword) }.map { (service, $0) }
        }
    }
    var body: some View {
        List {
            if keyword.isEmpty { Section { Label("搜索课程、老师、教室或服务功能", systemImage: "magnifyingglass").foregroundStyle(.secondary) } }
            if !services.isEmpty { Section("服务") { ForEach(services) { service in NavigationLink { ServiceDetail(id: service.id) } label: { ServiceRow(service: service) } } } }
            if !courses.isEmpty { Section("课程") { ForEach(courses) { course in NavigationLink { CourseInspection(course: course) } label: { CourseRow(course: course) } } } }
            if !features.isEmpty { Section("平台功能") { ForEach(features.indices, id: \.self) { index in
                let item = features[index]
                NavigationLink { OfficialFeature(service: item.0, title: item.1) } label: { FeatureRow(title: item.1, subtitle: item.0.name + " · 原生待授权", color: item.0.color) }
            } } }
            if !keyword.isEmpty && services.isEmpty && courses.isEmpty && features.isEmpty { CampusEmptyState.search(text: keyword) }
        }.navigationTitle("搜索").searchable(text: $query, prompt: "搜索课程、教师、服务")
    }
}

// Native SF Symbols in a consistent, accessible two-tone icon tile.
struct FeatureIcon: View {
    let symbol: String
    var color: Color = .accentColor
    var size: CGFloat = 42
    var body: some View {
        Image(systemName: UIImage(systemName: symbol) == nil ? "doc.text" : symbol).font(.system(size: size * 0.46, weight: .semibold))
            .symbolRenderingMode(.hierarchical).foregroundStyle(color)
            .frame(width: size, height: size)
            .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: size * 0.29, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: size * 0.29, style: .continuous).strokeBorder(color.opacity(0.10), lineWidth: 1))
            .accessibilityHidden(true)
    }
}
struct FeatureRow: View {
    let title: String
    var subtitle: String = ""
    var color: Color = .accentColor
    var body: some View {
        HStack(spacing: 12) {
            FeatureIcon(symbol: FeatureSymbols.icon(title), color: color)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.body.weight(.medium))
                if !subtitle.isEmpty { Text(subtitle).font(.caption).foregroundStyle(.secondary) }
            }
        }.padding(.vertical, 3)
    }
}


// Compatible navigation, value rows and empty states shared by all screens.
struct CampusNavigation<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        if #available(iOS 16, *) { NavigationStack { content } }
        else { NavigationView { content }.navigationViewStyle(.stack) }
    }
}
struct CampusValueRow: View {
    let title: String; let value: String
    init(_ title: String, value: String) { self.title = title; self.value = value }
    var body: some View {
        HStack(alignment: .firstTextBaseline) { Text(title); Spacer(minLength: 12); Text(value).foregroundStyle(.secondary).multilineTextAlignment(.trailing) }.accessibilityElement(children: .combine)
    }
}
struct CampusEmptyState: View {
    let title: String; let systemImage: String; var description: Text?
    init(_ title: String, systemImage: String, description: Text? = nil) { self.title = title; self.systemImage = systemImage; self.description = description }
    static func search(text: String) -> Self { .init("没有搜索结果", systemImage: "magnifyingglass", description: Text("试试其他课程、教师或服务名称。")) }
    var body: some View {
        VStack(spacing: 10) {
            FeatureIcon(symbol: systemImage, color: .accentColor, size: 52)
            Text(title).font(.headline)
            if let description = description { description.font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center) }
        }.frame(maxWidth: .infinity).padding(.vertical, 22).accessibilityElement(children: .combine)
    }
}
struct CampusMultiline: View {
    let title: String; @Binding var text: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            TextEditor(text: $text).frame(minHeight: 72).accessibilityLabel(title)
        }
    }
}
struct CampusQuickAction: View {
    let title: String; let symbol: String; let color: Color
    var body: some View {
        VStack(spacing: 6) { FeatureIcon(symbol: symbol, color: color, size: 40); Text(title).font(.footnote.weight(.medium)).foregroundStyle(.primary) }
            .frame(maxWidth: .infinity).padding(.vertical, 10)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}
extension Button where Label == SwiftUI.Label<Text, Image> {
    init(_ title: String, campusIcon: String, action: @escaping () -> Void) {
        self.init(action: action) { SwiftUI.Label(title, systemImage: campusIcon) }
    }
}
