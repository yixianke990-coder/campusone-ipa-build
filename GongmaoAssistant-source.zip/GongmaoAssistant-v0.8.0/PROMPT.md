# Muse / Xcode 工程交接（v0.8.0）
导入 CampusOne.xcodeproj，不转换为网页套壳。保留工贸助手原版蓝金 iOS Liquid Glass UI、iOS 15 最低部署目标、iOS 27 待 SDK 验收、四个原生平台目录及独立自定义网页。原生平台不以 H5、小程序或外部 App 跳转代替登录。
NativeCore 是单独可测试 Swift Package；同一 Swift 文件已列入主 Target，不需另加同名 package 依赖。NativeRegistry 四家默认拒绝，当前无正式授权接口。只在获得文档和书面授权之后实现对应 adapter，禁止模拟认证、猜测私有签名、伪造身份/位置、模拟余额订单或设备状态。
依据 Documentation/RELEASE_080.md、RELEASE_070.md、UI_REVIEW.md 配置真实 bundle ID、App Group、主应用及 CampusWidgets 扩展签名；使用支持 iOS 26 API 的 SDK 编译，不删功能逃避错误。验证 iOS 15/16 回退、原生账号页面、独立自定义网页、扫码、课表、桌面/锁屏小组件、ActivityKit、控制中心、快捷指令、Face ID、提醒及备份恢复。真实第三方业务必须单独联调。通过编译签名才可生成 IPA；Muse 不支持原生工程或扩展时改用兼容 Xcode 环境。
