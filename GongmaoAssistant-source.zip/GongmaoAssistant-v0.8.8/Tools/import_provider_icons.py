#!/usr/bin/env python3
"""Import developer-supplied, licensed PNGs into the app asset catalog."""
import argparse, json, pathlib, struct, shutil
p=argparse.ArgumentParser()
p.add_argument('directory',type=pathlib.Path,help='Folder containing the four permitted PNGs')
p.add_argument('--confirm-permission',action='store_true',required=True,help='Confirm permission to distribute all four assets')
a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1]/'CampusOne'/'Assets.xcassets'
mapping={'慧生活798_icon_1024.png':'ProviderLife798','喜鹊儿_icon_1024.png':'ProviderXiqueer','U净_icon_1024.png':'ProviderUjing','趣智校园_icon_1024.png':'ProviderQuzhi'}
for filename in mapping:
    src=a.directory/filename
    data=src.read_bytes()
    if len(data)<33 or data[:8]!=b'\x89PNG\r\n\x1a\n' or data[12:16]!=b'IHDR' or struct.unpack('>II',data[16:24])!=(1024,1024):
        p.error(f'{filename} must be a 1024×1024 PNG')
for filename,asset in mapping.items():
    dest=root/(asset+'.imageset'); dest.mkdir(exist_ok=True)
    shutil.copyfile(a.directory/filename,dest/'icon.png')
    (dest/'Contents.json').write_text(json.dumps({'images':[{'filename':'icon.png','idiom':'universal'}],'info':{'author':'xcode','version':1}},indent=2)+'\n')
print('Four licensed brand assets imported. Rebuild and inspect before distribution.')
