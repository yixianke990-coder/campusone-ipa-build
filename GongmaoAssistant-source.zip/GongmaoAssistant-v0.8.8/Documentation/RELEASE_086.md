# v0.8.6 — 完整工程补充（Build 19）

## 基线与来源
以用户此前的 GongmaoAssistant-v0.8.4.zip 完整 Xcode 工程为基线。核对用户上传的 v0.8.5 Swift Package 与六阶段交付资料。后者缺少主 App 和扩展工程，不能替换基线。选择性参考其中 XiqueerAcademicModels.swift 的 XQCourseSession 字段形态（kcmc/xqj/jc/zc/skdd/jsxm），重新编写离线转换逻辑；没有复制其网络、签名、设备或支付实现。该来源不是官方线上格式认证。

## 本次实际更改
- 主 App 与扩展版本 0.8.6 / Build 19，保留原 Xcode targets、scheme、bundle 配置、App Group、主图标、隐私清单、原 UI 和功能文件。
- 课表 → 批量导入本地课表 → 教务字段 JSON 导入：文件选择或粘贴；明确学期与实际学校节次表，转换成现有 Course；预览再确认；保存到原本地课表，不修改在线缓存。支持普通、单/双周、逗号分隔周次；拒绝不明确或非法周次、缺失节次、重复/重叠时间、超量数据。实际格式以本版说明为准，并非任意喜鹊儿服务响应均兼容。
- 四平台详情与登录页接入状态更新为第六阶段证据状态，不宣称真实接口启用。
- 共享课程快照拒绝未来时间戳，避免时钟调整或异常快照导致显示陈旧数据。
- 112 项本地模型检查、25 项 NativeCore XCTest 通过；15 项新增本地模型检查。全部 Swift 文件语法解析通过，plist 等配置检查通过。详见 TEST_RESULTS_086.txt。

## 未合并组件与原因
- 六阶段提供的 Life798Kit、XiqueerKit、UjingKit、QuzhiKit 中的真实业务客户端、私有签名及设备通信实现：未纳入运行目标；来源报告自身承认认证配置或验证缺失，不能把第三方协议样本当作授权运行配置。
- 六阶段 UI/Widget/AppIntent/Face ID 组件：本工程已存在对应功能与统一 App Group；保留原实现，未引入重复类型或不同共享容器。GlassTheme 的示例不能替代现有系统 TabView。
- 上游第三方原版图标仍未嵌入；原有资源导入入口保留。
- 真实登录、验证码、在线教务、设备使用、支付未接通。没有进行任何真实账号、设备或支付操作。

## Muse / Xcode
解压后打开 CampusOne.xcodeproj，scheme CampusOne。使用支持 iOS 26 API 的 Xcode SDK，配置原有主 App / CampusWidgets 签名和一致 App Group。最低目标 iOS 15；iOS 27 待实际 SDK 验收。运行本地功能和系统扩展后再做真机验证。当前 Linux 无 iOS SDK，语法检查不是 iOS 类型检查、完整编译或签名；本包是源码，不是 IPA。
