# v0.8.0 原生认证架构（2026-11-26）

## 范围与证据
基于 v0.7.0 完整工程与用户提供的 Native_Integration_Analysis.zip 内 00、05、06 报告及 U净报告的二维码段落。报告描述的是静态/第三方证据，未独立调用真实平台接口；未复用第三方源码、私有签名、AppID 或凭证。保留原蓝金、Liquid Glass、iOS 15 最低部署、iOS 27 兼容目标、四平台目录、自定义网页与系统扩展。

## 本版新增
- `NativeCore/`：Swift Package，iOS 15/macOS 12 最低目标；同一份 Swift 文件直接列入 Xcode 主 Target，无外部依赖。
- `PlatformService`：认证开始、挑战完成、状态、注销协议。四平台目前统一返回 authorizationMissing；不是四个已联调的服务适配器。
- `ApiClient`：每账号独立 ephemeral URLSession，禁用共享 Cookie、持久 URL 缓存和 HTTP 重定向，HTTPS 精确 origin 检查，授权器默认拒绝，无应用层自动重试。只接受明确 read/mutation 请求类型；不构造服务商私有请求。未来经授权适配器需实现具体 Cookie 罐（如需要）、续期、业务信封/错误码、证书策略。当前使用系统 TLS 验证，不启用未获正式 pin 的 SPKI 固定。
- `KeychainStore`：按平台和本地账号 UUID 隔离，WhenUnlockedThisDeviceOnly，不储存密码。Linux 分支拒绝，不以文件替代 Keychain。实际 iOS Keychain 验收待完成。
- `PendingOperation`：可编码的操作状态机，提交后/结果不明时禁止同一记录再次提交；适配器需在请求前持久化记录并以权威订单查询确认。未接入任何真实订单，未实现服务端幂等键或持久化订单工作流。URLSession 底层行为仍须在实际服务环境验证。
- `NativeQR`：对报告给出的 U净 URL 候选格式进行离线匹配，允许 HTTP 仅作为识别文本，不访问链接，精确校验 host/path/type/uuid，无重复参数。扫码仍要求用户确认，不自动传递设备参数、不启动设备、不付款。实际机身码待验证。
- `NativeAccounts.swift`：四平台独立原生账号页面，添加、选择、删除本地账号备注；无授权时登录按钮禁用且不提供真实凭证输入。旧内置平台网页会话可主动清理；自定义网页仍可单独打开。备注不得填写密码、验证码或个人凭证。

## 入口行为
四个内置平台不再在服务详情、账号、功能目录、课表及搜索默认导航至网页、官方 App Store 或小程序。旧版网址和本地数据仍保留为兼容历史配置，但不作为内置业务入口。自定义网页不变。独立 JSON 课表导入/在线同步仍是合法通用数据来源，不代表喜鹊儿认证。

## 真实接入待办
| 平台 | 必需资料 |
|---|---|
| 喜鹊儿 | 校方授权、学校目录、账号认证及课表/教务接口、会话测试 |
| 慧生活798 | 厂商分配本应用身份、正式验证码认证、设备/钱包/结算接口与许可 |
| U净 | 正式认证、位置权限规则、设备与订单、支付、官方授权 SDK |
| 趣智校园 | 厂商正式 SDK 或授权接口、设备型号兼容性、结算与测试环境 |

只有取得授权后才能替换 NativeRegistry 的对应适配器、启用相应原生表单。不能冒充官方客户端。不得复用原应用身份或签名，不可伪造位置。

## 测试与交付
- `cd NativeCore && swift test`（Linux 可执行，不含 Apple Security 测试）
- 工程原模型测试：`swiftc CampusOne/Models.swift Shared/SystemModels.swift Tests/main.swift -o /tmp/gmtests && /tmp/gmtests`
- 所有 Swift 文件语法解析，工程与 plist 格式检查。检查记录见 TEST_RESULTS_080.txt。
- 尚无 Xcode/iOS SDK；未完成主 App/扩展编译、真机渲染、账号/设备/支付实测、签名和 IPA。Muse 兼容性未知。系统扩展签名参见 RELEASE_070.md。
