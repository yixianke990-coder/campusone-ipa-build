# v0.8.8 登录调用链修订（2026-11-26）

以 v0.8.7 完整工程为基础。主工程的登录页以前只有静态字段和空操作按钮；现按 NativeRegistry 的实际可用状态决定显示内容。NativeLoginFlow 将 UI 的发起认证及提交挑战操作转交 PlatformService，并在报告成功前确认对应账号会话有效。凭证仅为瞬态输入。未注册适配器时不显示空输入控件。现阶段四平台注册表仍不可用；没有发送真实验证码，也没有启用设备和支付。通用挑战输入不等于慧生活798图形验证码实现。

## GitHub 公开项目复核（仓库说明级，不是源代码全量审计）

- https://github.com/nocookies111/life-798 — 慧生活798 Android 多账号、用水及消费统计；发布需要服务配置，未启用其认证实现。
- https://github.com/lizhengqiang/kingosoft_api — 喜鹊儿接口研究，未复制其代码。
- https://github.com/Sakana07X/kingosoft-api-notes — 喜鹊儿教务研究，不能证明本校可接入。
- https://github.com/JasonBeam/campus-daily — 广东工商职业技术大学校园客户端，包含 U净，学校不同，未验证运行兼容性。
- https://github.com/funcfang/U-Clean-Reserve — U净状态监听，不是完整客户端。
- https://github.com/yehu-imei/linyu — 趣智第三方客户端，部署存在区域差异，未验证本校。

本次没有引入上述仓库的源码或依赖，没有复制私有认证实现。所上传 v0.8.5 的 RemainingBlockers.md 本身记载慧生活及喜鹊儿认证缺口，其他两家也未完成真机验证。不能据此认定任何平台可用。

## 验证
Linux Swift 6.2.1: NativeCore 34 项测试通过（4 项新增，使用合成适配器）。未执行 iOS SDK 类型检查、完整编译、真实登录、设备与支付测试。保留原工程与 UI 资产。此版本不是业务接通版。
