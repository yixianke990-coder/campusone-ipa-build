# 课表和平台接入契约
当前不包含喜鹊儿或慧生活798的原生私有 API。原生登录需要官方授权、可验证登录协议与合法测试环境。设备控制还需合法配对及计费协议。不得跳过计费、伪造设备状态、自动提交选课或考勤。网页配置只使用官方稳定 HTTPS 入口；不保存临时登录码。

## 工贸助手自己的只读 JSON feed（不是喜鹊儿 API）
GET HTTPS；可选 Bearer token（仅 Keychain；拒绝重定向）。Content-Type: application/json。例：
```json
{"schemaVersion":1,"courses":[{"name":"示例课程","location":"A101","weekday":1,"start":480,"end":570,"detail":{"teacher":"","note":"","term":"示例学期","firstWeek":1,"lastWeek":16,"parity":"odd"}}]}
```
`weekday` 1=周一；时间单位为自午夜起分钟；detail 可整体省略（兼容旧格式），存在时需全部字段。parity 为 all/odd/even；周次 1–30。成功的空数组可替换旧在线课表；失败保留旧缓存。手动课程不受刷新影响。JSON 批量导入同样支持 detail 字段（顶层为数组）。单一在线快照，跨学期需接口本身返回带学期信息的数据或切换接口。节假日、跨天和不规则调课仍须由授权数据源处理。
