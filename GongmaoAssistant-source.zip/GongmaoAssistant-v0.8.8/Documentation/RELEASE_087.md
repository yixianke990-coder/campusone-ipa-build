# v0.8.7 — 会话与扫码增强（Build 20）

基线：用户提供的 v0.8.6 完整 App 工程；核对 v0.8.5 的 AuthSession.swift 与 OrderStateMachine.swift，重新实现通用持久化组件，不移植厂商签名、网关或设备协议。保留所有原工程文件、App/Widget target、原 UI、系统扩展与现有功能。

## 新增
- SessionVault：使用原有账号隔离 Keychain 命名空间持久化不透明会话数据，冷启动可按已知账号读取，拒绝跨账号记录和超限数据；本地票据绝不等于服务端已认证。默认实际 Keychain，Linux 测试使用注入的内存存储代替，未测试真实 iOS Keychain。
- OperationJournal：独立 Keychain 命名空间保存每账号未确认操作；先保存提交状态，重启恢复为 uncertain，未确认时拒绝再次准备；只允许取消未提交操作。后续正式适配器应使用 shared 实例串行调用，并依据独立验证的服务端结果对账。当前没有实际支付或设备请求，未接入运行中的业务流程。
- 原生相机手电筒：依据相机能力启用按钮，切换照明，扫码或离开时关闭；无手电筒的设备保持禁用。源码语法通过，实际硬件效果待验证。

## 验证
- 112 项本地模型检查通过；NativeCore 30 项 XCTest 通过（新增 5 项）。Swift 6.2.1 Linux。
- App、Widget、Shared、NativeCore 及测试 Swift 语法解析通过；plist / entitlement / privacy manifest / asset JSON 解析通过。
- 不能在当前 Linux 环境完成 iOS SDK 类型检查、Xcode 构建、签名、Muse 构建或真机验收。

## 仍未完成
- 四平台真实验证码、登录、在线数据、真实设备使用、支付及结算：未启用，未测试；第六阶段客户端没有直接纳入运行目标。
- 原平台图标未随包嵌入，原导入工具 Tools/import_provider_icons.py 保留。工贸助手独立主图标保留。
- 本版是源码工程，不是 IPA。原生 Liquid Glass 和 iOS 15–27 为现有兼容目标，未进行全版本实际验证。
