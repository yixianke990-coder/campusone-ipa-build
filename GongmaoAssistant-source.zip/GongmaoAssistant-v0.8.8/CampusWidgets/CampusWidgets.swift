import SwiftUI
import WidgetKit
import ActivityKit
import AppIntents

struct CampusEntry: TimelineEntry { let date: Date; let snapshot: CampusWidgetSnapshot? }
struct CampusTimeline: TimelineProvider {
    func placeholder(in context: Context) -> CampusEntry { .init(date: Date(), snapshot: nil) }
    func getSnapshot(in context: Context, completion: @escaping (CampusEntry) -> Void) { completion(.init(date: Date(), snapshot: CampusShared.snapshot())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<CampusEntry>) -> Void) {
        let now = Date(), snap = CampusShared.snapshot()
        let boundaries = Array(Set((snap?.upcoming(at: now) ?? []).flatMap { [$0.start, $0.end] }.filter { $0 > now })).sorted().prefix(40)
        let entries = [now] + Array(boundaries)
        completion(Timeline(entries: entries.map { .init(date: $0, snapshot: snap) }, policy: .after(now.addingTimeInterval(1800))))
    }
}
struct CampusWidgetView: View {
    let entry: CampusEntry
    @Environment(\.widgetFamily) private var family
    var body: some View {
        if #available(iOS 17, *) { content.containerBackground(for: .widget) { Color(uiColor: .systemBackground) } }
        else { content.padding(8) }
    }
    private var content: some View {
        let lessons = entry.snapshot?.upcoming(at: entry.date) ?? []
        return VStack(alignment: .leading, spacing: 6) {
            Label("工贸助手", systemImage: "graduationcap.fill").font(.caption.weight(.semibold))
            if let lesson = lessons.first {
                Text(lesson.start <= entry.date ? "当前课程" : "下一节课").font(.caption2).foregroundStyle(.secondary)
                Text(lesson.title).font(.headline).lineLimit(2).privacySensitive()
                Text(lesson.start, style: .time).font(.caption).privacySensitive()
                if family == .systemMedium, lessons.count > 1 { Text("随后：" + lessons[1].title).font(.caption).lineLimit(1).privacySensitive() }
            } else {
                Text(entry.snapshot == nil ? "打开课表" : "暂无近期课程").font(.headline)
                Text("本地课表 · 不自动登录").font(.caption2).foregroundStyle(.secondary)
            }
        }.frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading).widgetURL(CampusSystemRoute.courses.url)
    }
}
struct CampusScheduleWidget: Widget {
    let kind = "CampusScheduleWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CampusTimeline()) { entry in CampusWidgetView(entry: entry) }
            .configurationDisplayName("工贸助手课表").description("查看本机保存的下一节课。")
            .supportedFamilies(families)
    }
    private var families: [WidgetFamily] {
        if #available(iOS 16, *) { return [.systemSmall, .systemMedium, .accessoryRectangular] }
        return [.systemSmall, .systemMedium]
    }
}
@available(iOS 16.1, *)
struct CampusTimerWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: CampusTimerAttributes.self) { context in
            HStack(spacing: 12) {
                Image(systemName: "timer").font(.title2)
                VStack(alignment: .leading) { Text("本地使用提醒").font(.headline); Text("请在官方平台核实设备").font(.caption) }
                Spacer()
                countdown(context.state).font(.title2.monospacedDigit())
            }.padding().widgetURL(CampusSystemRoute.services.url)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) { Image(systemName: "timer") }
                DynamicIslandExpandedRegion(.trailing) { countdown(context.state).monospacedDigit() }
                DynamicIslandExpandedRegion(.bottom) { Text("本地计时 · 非真实设备状态").font(.caption) }
            } compactLeading: { Image(systemName: "timer") }
              compactTrailing: { countdown(context.state).monospacedDigit().frame(maxWidth: 65) }
              minimal: { Image(systemName: "timer") }
              .widgetURL(CampusSystemRoute.services.url)
        }
    }
    @ViewBuilder private func countdown(_ state: CampusTimerAttributes.ContentState) -> some View {
        if state.finished || state.end <= Date() || state.end <= state.started { Text("结束") }
        else { Text(timerInterval: state.started...state.end, countsDown: true) }
    }
}
@available(iOS 18.0, *)
struct CampusScanControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: "CampusScanControl") {
            ControlWidgetButton(action: OpenCampusScanner()) { Label("校园扫一扫", systemImage: "qrcode.viewfinder") }
        }.displayName("校园扫一扫").description("打开工贸助手扫码页。")
    }
}
@available(iOS 18.0, *)
struct CampusScheduleControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(kind: "CampusScheduleControl") {
            ControlWidgetButton(action: OpenCampusSchedule()) { Label("查看课表", systemImage: "calendar") }
        }.displayName("查看课表").description("打开工贸助手课表。")
    }
}
@main struct CampusWidgets: WidgetBundle {
    @WidgetBundleBuilder var body: some Widget {
        CampusScheduleWidget()
        if #available(iOS 16.1, *) { CampusTimerWidget() }
        if #available(iOS 18.0, *) { CampusScanControl(); CampusScheduleControl() }
    }
}
