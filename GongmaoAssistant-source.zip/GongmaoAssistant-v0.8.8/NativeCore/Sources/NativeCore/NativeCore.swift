import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if canImport(Security)
import Security
#endif

public enum NativeProvider: String, Codable, CaseIterable, Sendable {
    case life798, xiqueer, ujing, quzhi
    public var title: String {
        switch self { case .life798: return "慧生活798"; case .xiqueer: return "喜鹊儿"; case .ujing: return "U净"; case .quzhi: return "趣智校园" }
    }
    public var loginMethod: String {
        switch self { case .life798: return "手机号码 · 官方验证码流程"; case .xiqueer: return "学校选择 · 教务账号"; case .ujing: return "手机号码 · 官方授权"; case .quzhi: return "厂商 SDK 提供的登录方式" }
    }
    public var blocker: String {
        switch self { case .life798: return "需要厂商分配应用身份、验证码及业务接口授权。"; case .xiqueer: return "需要学校或教务服务商授权的认证、会话及课表接口。"; case .ujing: return "需要正式认证、订单、设备及支付接口授权。"; case .quzhi: return "需要厂商正式 SDK 或授权业务接口。" }
    }
}
public struct NativeAccount: Codable, Equatable, Identifiable, Sendable {
    public let id: UUID
    public let provider: NativeProvider
    public var alias: String
    public init(id: UUID = UUID(), provider: NativeProvider, alias: String) { self.id = id; self.provider = provider; self.alias = alias }
    public static func validAlias(_ text: String) -> Bool {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return !trimmed.isEmpty && trimmed.count <= 32 && !trimmed.unicodeScalars.contains { CharacterSet.controlCharacters.contains($0) }
    }
    public var storageKey: String { provider.rawValue + "." + id.uuidString }
}
public enum NativeAPIError: Error, Equatable, LocalizedError {
    case authorizationMissing, invalidEndpoint, unsafeMethod, invalidResponse, http(Int), emptyBody, decoding, keychain(Int32), unavailable, unresolvedOperation
    public var errorDescription: String? {
        switch self { case .authorizationMissing: return "尚未取得平台原生接口授权。"; case .invalidEndpoint: return "接口地址不在授权范围内。"; case .unsafeMethod: return "请求方法与业务类型不一致。"; case .invalidResponse: return "服务器响应无效。"; case .http(let code): return "请求失败（HTTP \(code)）。"; case .emptyBody: return "服务器没有返回业务数据。"; case .decoding: return "暂不能解析此接口响应。"; case .keychain: return "安全存储操作失败。"; case .unavailable: return "当前环境不支持此功能。"; case .unresolvedOperation: return "前一次操作结果尚未确认，请先核对订单。" }
    }
}
// Provider-specific adapters implement this contract only after written approval.
// The release registry below deliberately has NO authorized adapter or endpoint.
public protocol PlatformService: Sendable {
    var provider: NativeProvider { get }
    var isAuthorized: Bool { get }
    func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome
    func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome
    func sessionStatus(account: NativeAccount) async throws -> NativeSessionState
    func signOut(account: NativeAccount) async throws
}
// These inputs are transient, never Codable or persisted. The provider must define
// their meaning and enforce its own challenge, consent, and session validation.
public enum NativeLoginInput: Sendable {
    case schoolAccount(schoolReference: String, account: String, password: String)
    case phoneChallenge(phone: String)
}
public enum NativeLoginOutcome: Equatable, Sendable {
    case challengeRequired(reference: String)
    case authenticated
}
public enum NativeSessionState: Equatable, Sendable { case signedOut, valid, expired }
public struct UnavailablePlatformService: PlatformService {
    public let provider: NativeProvider
    public var isAuthorized: Bool { false }
    public init(provider: NativeProvider) { self.provider = provider }
    public func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome { throw NativeAPIError.authorizationMissing }
    public func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome { throw NativeAPIError.authorizationMissing }
    public func sessionStatus(account: NativeAccount) async throws -> NativeSessionState { throw NativeAPIError.authorizationMissing }
    public func signOut(account: NativeAccount) async throws { throw NativeAPIError.authorizationMissing }
}
public enum NativeRegistry {
    public static func service(for provider: NativeProvider) -> any PlatformService { UnavailablePlatformService(provider: provider) }
}
// Authentication input is intentionally not collected in the release UI. The approved
// adapter must supply its own documented login/challenge flows and response mapping.
public struct ApprovedOrigin: Equatable, Sendable {
    public let host: String
    public let port: Int
    public init?(url: URL) {
        guard let c = URLComponents(url: url, resolvingAgainstBaseURL: false), c.scheme?.lowercased() == "https", let host = c.host?.lowercased(), !host.isEmpty, c.user == nil, c.password == nil, c.fragment == nil, (1...65535).contains(c.port ?? 443) else { return nil }
        self.host = host; self.port = c.port ?? 443
    }
    public func contains(_ url: URL) -> Bool { ApprovedOrigin(url: url) == self }
}
public enum RequestPurpose: Sendable { case read, mutation }
public protocol RequestAuthorizer: Sendable {
    func authorize(_ request: URLRequest, account: NativeAccount) async throws -> URLRequest
}
public struct MissingAuthorizer: RequestAuthorizer {
    public init() {}
    public func authorize(_ request: URLRequest, account: NativeAccount) async throws -> URLRequest { throw NativeAPIError.authorizationMissing }
}
private final class NoRedirect: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
// One client per account, isolated ephemeral session, no global Cookie jar, no redirects.
// There is no automatic application-level retry, including on transport errors.
public actor ApiClient {
    private let account: NativeAccount
    private let origin: ApprovedOrigin
    private let authorizer: any RequestAuthorizer
    private let session: URLSession
    public init(account: NativeAccount, origin: ApprovedOrigin, authorizer: any RequestAuthorizer = MissingAuthorizer()) {
        self.account = account; self.origin = origin; self.authorizer = authorizer
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 15; config.timeoutIntervalForResource = 30
        config.httpMaximumConnectionsPerHost = 4; config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.urlCache = nil; config.urlCredentialStorage = nil
        config.httpShouldSetCookies = false; config.httpCookieStorage = nil
        session = URLSession(configuration: config, delegate: NoRedirect(), delegateQueue: nil)
    }
    public static func validate(_ request: URLRequest, origin: ApprovedOrigin, purpose: RequestPurpose) throws {
        guard let url = request.url, origin.contains(url) else { throw NativeAPIError.invalidEndpoint }
        let method = (request.httpMethod ?? "GET").uppercased()
        switch purpose {
        case .read: guard ["GET", "HEAD"].contains(method), request.httpBody == nil, request.httpBodyStream == nil else { throw NativeAPIError.unsafeMethod }
        case .mutation: guard ["POST", "PUT", "PATCH", "DELETE"].contains(method) else { throw NativeAPIError.unsafeMethod }
        }
    }
    public func send<T: Decodable>(_ request: URLRequest, purpose: RequestPurpose, as type: T.Type, format: NativeResponseFormat = .rawJSON) async throws -> T {
        try Self.validate(request, origin: origin, purpose: purpose)
        let authorized = try await authorizer.authorize(request, account: account)
        try Self.validate(authorized, origin: origin, purpose: purpose)
        let (data, response) = try await session.data(for: authorized)
        guard let http = response as? HTTPURLResponse, let url = http.url, origin.contains(url) else { throw NativeAPIError.invalidResponse }
        guard (200...299).contains(http.statusCode) else { throw NativeAPIError.http(http.statusCode) }
        guard !data.isEmpty else { throw NativeAPIError.emptyBody }
        return try NativeResponseDecoder.decode(type, from: data, format: format)
    }
    public func close() { session.invalidateAndCancel() }
}
// A durable operation record can be saved by a future authorized adapter before sending.
// Unknown outcome stays locked; it does not imply failure or permit automatic retry.
public struct PendingOperation: Codable, Equatable, Sendable {
    public enum State: String, Codable, Sendable { case prepared, submitted, uncertain, confirmed, rejected }
    public let id: UUID
    public private(set) var state: State
    public init(id: UUID = UUID()) { self.id = id; state = .prepared }
    public mutating func markSubmitted() throws { guard state == .prepared else { throw NativeAPIError.unresolvedOperation }; state = .submitted }
    public mutating func markUncertain() { if state == .submitted { state = .uncertain } }
    public mutating func reconcile(confirmed: Bool) throws { guard state == .submitted || state == .uncertain else { throw NativeAPIError.unresolvedOperation }; state = confirmed ? .confirmed : .rejected }
}
public protocol AccountDataStorage: Sendable {
    func save(_ data: Data, account: NativeAccount) throws
    func load(account: NativeAccount) throws -> Data?
    func remove(account: NativeAccount) throws
}
public struct KeychainStore: AccountDataStorage {
    public enum Scope: String, Sendable { case session = "GongmaoAssistant.native-session.v1", operation = "GongmaoAssistant.native-operation.v1" }
    private let scope: Scope
    public init(scope: Scope = .session) { self.scope = scope }
    #if canImport(Security)
    private func query(_ account: NativeAccount) -> [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: scope.rawValue, kSecAttrAccount as String: account.storageKey] }
    #endif
    public func save(_ data: Data, account: NativeAccount) throws {
        #if canImport(Security)
        let q = query(account)
        let status = SecItemUpdate(q as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return }
        guard status == errSecItemNotFound else { throw NativeAPIError.keychain(status) }
        var item = q; item[kSecValueData as String] = data; item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let added = SecItemAdd(item as CFDictionary, nil); guard added == errSecSuccess else { throw NativeAPIError.keychain(added) }
        #else
        throw NativeAPIError.unavailable
        #endif
    }
    public func load(account: NativeAccount) throws -> Data? {
        #if canImport(Security)
        var q = query(account); q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?; let status = SecItemCopyMatching(q as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }; guard status == errSecSuccess, let data = result as? Data else { throw NativeAPIError.keychain(status) }; return data
        #else
        throw NativeAPIError.unavailable
        #endif
    }
    public func remove(account: NativeAccount) throws {
        #if canImport(Security)
        let status = SecItemDelete(query(account) as CFDictionary); guard status == errSecSuccess || status == errSecItemNotFound else { throw NativeAPIError.keychain(status) }
        #else
        throw NativeAPIError.unavailable
        #endif
    }
}
// The QR pattern is third-party reported, not a verified device or authorization.
// HTTP is accepted ONLY for offline recognition; no URL is opened or requested.
public enum NativeQR {
    public static func ujingCandidate(_ raw: String) -> Bool {
        guard raw.utf8.count <= 4096, let c = URLComponents(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
              ["http", "https"].contains(c.scheme?.lowercased() ?? ""), c.host?.lowercased() == "app.littleswan.com",
              c.user == nil, c.password == nil, c.port == nil, c.fragment == nil, c.percentEncodedPath == "/u_download.html" else { return false }
        let items = c.queryItems ?? []
        let types = items.filter { $0.name == "type" }, ids = items.filter { $0.name == "uuid" }
        guard types.count == 1, types[0].value == "Ujing", ids.count == 1, let id = ids[0].value, !id.isEmpty, id.utf8.count <= 256 else { return false }
        return !id.unicodeScalars.contains { CharacterSet.whitespacesAndNewlines.contains($0) || CharacterSet.controlCharacters.contains($0) }
    }
}

// Phase 4: candidates are display-only. Never forward raw codes or authenticate from a scan.
public enum QRClassification: Equatable, Sendable {
    case candidate(NativeProvider), sensitive, ambiguousNumber, unknown
    public static func resolve(_ raw: String) -> Self {
        let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty, s.utf8.count <= 4096 else { return .unknown }
        if s.allSatisfy({ "0123456789".contains($0) }) {
            if (18...24).contains(s.count) || s.count == 6 { return .sensitive }
            return .ambiguousNumber
        }
        if NativeQR.ujingCandidate(s) { return .candidate(.ujing) }
        guard let c = URLComponents(string: s), c.scheme?.lowercased() == "https", c.user == nil, c.password == nil, c.port == nil, c.fragment == nil else { return .unknown }
        switch c.host?.lowercased() {
        case "d.ujing.online": return .candidate(.ujing)
        case "i.ilife798.com", "act.hnkzy.com", "cloud.hnkzy.com": return .candidate(.life798)
        case "v3-api.china-qzxy.cn": return .candidate(.quzhi)
        default: return .unknown
        }
    }
}

// Local validation only. Field code meanings are hypotheses from fixture analysis.
public enum AcademicControl: String, Sendable {
    case text, choice, multiChoice, timeRange, readOnly
    public static func from(_ code: String) -> Self {
        switch code { case "1": return .text; case "2", "22", "25": return .choice; case "55": return .multiChoice; case "74": return .timeRange; default: return .readOnly }
    }
}
public struct AcademicOption: Codable, Equatable, Sendable { public let dm: String; public let mc: String }
public struct AcademicField: Codable, Equatable, Sendable {
    public let field_ctr: String, field_lable: String, field_ywid: String
    public let field_need: String?, field_value: String?, field_editflag: String?, field_options: [AcademicOption]?, field_list: [AcademicOption]?
    public var kind: AcademicControl { .from(field_ctr) }
    public var editable: Bool { field_editflag == "1" && kind != .readOnly }
    public var required: Bool { field_need == "1" }
    public var options: [AcademicOption] { field_options ?? field_list ?? [] }
}
public struct AcademicFixture: Codable, Sendable {
    public let dataset: [AcademicField]
    public func valid() -> Bool { dataset.count <= 100 && Set(dataset.map(\.field_ywid)).count == dataset.count && dataset.allSatisfy { !$0.field_ywid.isEmpty && $0.options.count <= 100 } }
}

// These are conservative local workflow models, not mappings of verified server codes.
public enum BusinessOrderState: String, Codable, Sendable {
    case draft, awaitingPayment, paid, running, completed, cancelled, uncertain, refunding, refunded
    public func allows(_ next: Self) -> Bool {
        switch (self, next) {
        case (.draft,.awaitingPayment), (.awaitingPayment,.paid), (.awaitingPayment,.cancelled), (.paid,.running), (.paid,.refunding), (.running,.completed), (.completed,.refunding), (.refunding,.refunded), (.awaitingPayment,.uncertain), (.paid,.uncertain), (.running,.uncertain): return true
        default: return false
        }
    }
}
public enum DeviceAvailability: String, Codable, Sendable {
    case unknown, offline, idle, reserved, busy, fault, maintenance
    public var permitsOrderCandidate: Bool { self == .idle }
}
public enum ServiceSessionPhase: String, Codable, Sendable {
    case signedOut, authenticating, authenticated, serviceAuthorized, active, expired
    public var permitsBusiness: Bool { self == .active }
}
public enum SMSFlowPhase: String, Sendable {
    case unavailable, graphicChallenge, smsChallenge, verifying, authenticated
    public static func initial(authorized: Bool) -> Self { authorized ? .graphicChallenge : .unavailable }
}

// Phase 5: generic, offline-tested primitives. No provider response convention is assumed.
public enum NativeResponseFormat: Sendable { case rawJSON, explicitSuccessEnvelope }
public enum NativeResponseDecoder {
    private struct Envelope<T: Decodable>: Decodable {
        let success: Bool
        let data: T?
    }
    public static func decode<T: Decodable>(_ type: T.Type, from data: Data, format: NativeResponseFormat) throws -> T {
        do {
            switch format {
            case .rawJSON: return try JSONDecoder().decode(type, from: data)
            case .explicitSuccessEnvelope:
                let envelope = try JSONDecoder().decode(Envelope<T>.self, from: data)
                guard envelope.success, let value = envelope.data else { throw NativeAPIError.invalidResponse }
                return value
            }
        } catch let error as NativeAPIError { throw error }
        catch { throw NativeAPIError.decoding }
    }
}
// Local lease metadata does not constitute a valid server session. Missing expiry is unknown.
public enum SessionLeaseState: Equatable, Sendable { case unknown, current, refreshDue, expired }
public struct SessionLease: Codable, Equatable, Sendable {
    public let accountKey: String
    public let expiresAt: Date?
    public init(account: NativeAccount, expiresAt: Date?) { accountKey = account.storageKey; self.expiresAt = expiresAt }
    public func state(for account: NativeAccount, now: Date = Date()) -> SessionLeaseState {
        guard account.storageKey == accountKey, let expiresAt else { return .unknown }
        if expiresAt <= now { return .expired }
        return expiresAt.timeIntervalSince(now) <= 60 ? .refreshDue : .current
    }
}
// Integer minor units avoid rounding and currency mixing; local checks never confirm a payment.
public enum SettlementAudit: Equatable, Sendable {
    case incomplete, invalid, consistent
    public static func check(reserved: Int64?, charged: Int64?, refunded: Int64?, currency: String, settlementCurrency: String) -> Self {
        guard !currency.isEmpty, currency == settlementCurrency else { return .invalid }
        guard let reserved, let charged, let refunded else { return .incomplete }
        guard reserved >= 0, charged >= 0, refunded >= 0, charged <= reserved else { return .invalid }
        return reserved - charged == refunded ? .consistent : .invalid
    }
}
public struct ProviderIntegrationStatus: Sendable {
    public let authentication: String
    public let business: String
    public let payment: String
    public static func phase5(_ provider: NativeProvider) -> Self {
        switch provider {
        case .life798: return .init(authentication: "三段式验证码流程有静态证据；未接通", business: "设备指令结构未确认；余额与账单未验证", payment: "渠道未接入")
        case .xiqueer: return .init(authentication: "学校账号信封认证未接通", business: "本地课表可用；在线教务未接通；远程 Vue 未实现", payment: "教务收费未接入")
        case .ujing: return .init(authentication: "短信、密码及 Apple 登录资料未验证", business: "Weex 功能索引可查；真实设备与订单未接通", payment: "渠道未接入")
        case .quzhi: return .init(authentication: "远程认证与微应用目录未接通", business: "本地扫码可用；真实 BLE/4G 及账单未接通", payment: "渠道未接入")
        }
    }
}


public extension ProviderIntegrationStatus {
    static func phase6(_ provider: NativeProvider) -> Self {
        switch provider {
        case .life798: return .init(authentication: "第六阶段提供双通道源码；认证配置缺失，未接通", business: "来源代码已审阅；实际设备与账单未验证", payment: "未接入真实渠道")
        case .xiqueer: return .init(authentication: "第六阶段提供教务客户端；信封认证未完成", business: "新增本地教务字段课表导入；在线教务与远程 Vue 未接通", payment: "未接入真实渠道")
        case .ujing: return .init(authentication: "第六阶段提供客户端；真实认证未经验证", business: "订单与设备源码未启用；功能索引仍可查", payment: "未接入真实渠道")
        case .quzhi: return .init(authentication: "第六阶段提供客户端；真实认证未经验证", business: "设备通信源码未启用；本地扫码与记录仍可用", payment: "未接入真实渠道")
        }
    }
}


// Account-scoped persisted session metadata. An unexpired local record is not
// proof of server authentication. Only an approved adapter may validate it.
public struct PersistedSession: Codable, Equatable, Sendable {
    public let lease: SessionLease
    public let opaqueTicket: Data
    public init(account: NativeAccount, expiresAt: Date?, opaqueTicket: Data) throws {
        guard !opaqueTicket.isEmpty, opaqueTicket.count <= 65536 else { throw NativeAPIError.invalidResponse }
        lease = SessionLease(account: account, expiresAt: expiresAt)
        self.opaqueTicket = opaqueTicket
    }
}
public actor SessionVault {
    public static let shared = SessionVault()
    private let storage: any AccountDataStorage
    public init(storage: any AccountDataStorage = KeychainStore()) { self.storage = storage }
    public func save(_ session: PersistedSession, for account: NativeAccount) throws {
        try validate(session, account: account)
        try storage.save(JSONEncoder().encode(session), account: account)
    }
    public func restore(for account: NativeAccount) throws -> PersistedSession? {
        guard let data = try storage.load(account: account) else { return nil }
        guard data.count <= 131072 else { throw NativeAPIError.invalidResponse }
        let session = try JSONDecoder().decode(PersistedSession.self, from: data)
        try validate(session, account: account)
        return session
    }
    private func validate(_ session: PersistedSession, account: NativeAccount) throws {
        guard session.lease.accountKey == account.storageKey, !session.opaqueTicket.isEmpty, session.opaqueTicket.count <= 65536 else { throw NativeAPIError.invalidResponse }
    }
    public func clear(for account: NativeAccount) throws { try storage.remove(account: account) }
}

// One outstanding operation per account; persist before any future authorized
// transmission. On restart, submitted is uncertain, never permission to retry.
public actor OperationJournal {
    // Runtime adapters must share this instance to serialize account operations.
    public static let shared = OperationJournal()
    private struct Record: Codable { let accountKey: String; var operation: PendingOperation }
    private let storage: any AccountDataStorage
    public init(storage: any AccountDataStorage = KeychainStore(scope: .operation)) { self.storage = storage }
    private func read(_ account: NativeAccount) throws -> Record? {
        guard let data = try storage.load(account: account) else { return nil }
        guard data.count <= 8192 else { throw NativeAPIError.invalidResponse }
        let record = try JSONDecoder().decode(Record.self, from: data)
        guard record.accountKey == account.storageKey else { throw NativeAPIError.invalidResponse }
        return record
    }
    private func write(_ record: Record, _ account: NativeAccount) throws {
        try storage.save(JSONEncoder().encode(record), account: account)
    }
    public func prepare(for account: NativeAccount) throws -> PendingOperation {
        if let previous = try read(account), previous.operation.state != .confirmed && previous.operation.state != .rejected { throw NativeAPIError.unresolvedOperation }
        let record = Record(accountKey: account.storageKey, operation: PendingOperation())
        try write(record, account); return record.operation
    }
    public func markSubmitted(_ id: UUID, for account: NativeAccount) throws {
        guard var record = try read(account), record.operation.id == id else { throw NativeAPIError.unresolvedOperation }
        try record.operation.markSubmitted(); try write(record, account)
    }
    public func recover(for account: NativeAccount) throws -> PendingOperation? {
        guard var record = try read(account) else { return nil }
        if record.operation.state == .submitted { record.operation.markUncertain(); try write(record, account) }
        return record.operation
    }
    // Only the caller's independently verified server result can resolve an operation.
    public func reconcile(_ id: UUID, for account: NativeAccount, confirmed: Bool) throws {
        guard var record = try read(account), record.operation.id == id else { throw NativeAPIError.unresolvedOperation }
        try record.operation.reconcile(confirmed: confirmed); try write(record, account)
    }
    public func cancelPrepared(_ id: UUID, for account: NativeAccount) throws {
        guard let record = try read(account), record.operation.id == id, record.operation.state == .prepared else { throw NativeAPIError.unresolvedOperation }
        try storage.remove(account: account)
    }
}

// UI entry point for an independently approved adapter. A claimed login success
// is not displayed until that adapter confirms the same account's session.
public struct NativeLoginFlow: Sendable {
    private let service: any PlatformService
    private let account: NativeAccount
    public init(service: any PlatformService, account: NativeAccount) {
        self.service = service; self.account = account
    }
    private func check() throws {
        guard service.isAuthorized, service.provider == account.provider else { throw NativeAPIError.authorizationMissing }
    }
    private func verify(_ result: NativeLoginOutcome) async throws -> NativeLoginOutcome {
        try Task.checkCancellation()
        switch result {
        case .challengeRequired(let reference):
            guard !reference.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw NativeAPIError.invalidResponse }
        case .authenticated:
            guard try await service.sessionStatus(account: account) == .valid else { throw NativeAPIError.invalidResponse }
        }
        try Task.checkCancellation()
        return result
    }
    public func begin(_ input: NativeLoginInput) async throws -> NativeLoginOutcome {
        try check(); try Task.checkCancellation()
        switch input {
        case .schoolAccount(let school, let user, let password):
            guard account.provider == .xiqueer, !school.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, !user.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, !password.isEmpty else { throw NativeAPIError.invalidResponse }
        case .phoneChallenge(let phone):
            guard account.provider != .xiqueer, !phone.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw NativeAPIError.invalidResponse }
        }
        return try await verify(service.beginLogin(account: account, input: input))
    }
    public func complete(reference: String, response: String) async throws -> NativeLoginOutcome {
        try check(); try Task.checkCancellation()
        guard !reference.isEmpty, !response.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw NativeAPIError.invalidResponse }
        return try await verify(service.completeLogin(account: account, challenge: reference, response: response))
    }
}
