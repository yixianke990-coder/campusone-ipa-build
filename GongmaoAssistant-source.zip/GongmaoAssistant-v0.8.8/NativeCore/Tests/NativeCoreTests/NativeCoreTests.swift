import XCTest
@testable import NativeCore
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
final class NativeCoreTests: XCTestCase {
    func testAllAdaptersUnavailable() { XCTAssertTrue(NativeProvider.allCases.allSatisfy { !NativeRegistry.service(for: $0).isAuthorized }) }
    func testAccountScope() { let id = UUID(); XCTAssertNotEqual(NativeAccount(id: id, provider: .xiqueer, alias: "A").storageKey, NativeAccount(id: id, provider: .ujing, alias: "A").storageKey) }
    func testAliasValidation() { XCTAssertFalse(NativeAccount.validAlias(" \n")); XCTAssertFalse(NativeAccount.validAlias(String(repeating: "a", count: 33))); XCTAssertTrue(NativeAccount.validAlias("主账号")) }
    func testApprovedOrigin() { let o = ApprovedOrigin(url: URL(string: "https://example.com:443/a")!)!; XCTAssertTrue(o.contains(URL(string: "https://example.com/b")!)); for s in ["http://example.com", "https://example.com.evil.test", "https://a@example.com", "https://example.com:444", "https://example.com/#x"] { XCTAssertFalse(o.contains(URL(string: s)!)) } }
    func testReadRejectsMutation() { let url = URL(string: "https://example.com/x")!; var r = URLRequest(url: url); r.httpMethod = "POST"; XCTAssertThrowsError(try ApiClient.validate(r, origin: ApprovedOrigin(url: url)!, purpose: .read)); XCTAssertNoThrow(try ApiClient.validate(r, origin: ApprovedOrigin(url: url)!, purpose: .mutation)) }
    func testReadRejectsBody() { let url = URL(string: "https://example.com/x")!; var r = URLRequest(url: url); r.httpBody = Data([1]); XCTAssertThrowsError(try ApiClient.validate(r, origin: ApprovedOrigin(url: url)!, purpose: .read)) }
    func testMissingAuthorizationNeverSends() async { let url = URL(string: "https://example.invalid/x")!; let client = ApiClient(account: NativeAccount(provider: .life798, alias: "test"), origin: ApprovedOrigin(url: url)!); do { let _: String = try await client.send(URLRequest(url: url), purpose: .read, as: String.self); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) }; await client.close() }
    func testOperationUncertainLocks() throws { var op = PendingOperation(); try op.markSubmitted(); op.markUncertain(); XCTAssertThrowsError(try op.markSubmitted()); try op.reconcile(confirmed: true); XCTAssertEqual(op.state, .confirmed); XCTAssertThrowsError(try op.markSubmitted()) }
    func testOperationRoundtrip() throws { var op = PendingOperation(); try op.markSubmitted(); op.markUncertain(); XCTAssertEqual(try JSONDecoder().decode(PendingOperation.self, from: JSONEncoder().encode(op)), op) }
    func testUjingQR() { for scheme in ["http", "https"] { XCTAssertTrue(NativeQR.ujingCandidate("\(scheme)://app.littleswan.com/u_download.html?type=Ujing&uuid=example")) } }
    func testUjingQRRejectsLookalikes() { for s in ["https://app.littleswan.com.evil.test/u_download.html?type=Ujing&uuid=x", "https://app.littleswan.com/u_download.html?type=Ujing&uuid=x&uuid=y", "https://app.littleswan.com/u_download.html?type=Ujing", "https://app.littleswan.com/u_download.html?type=Ujing&uuid=%20", "https://app.littleswan.com/wrong?type=Ujing&uuid=x", "https://u@app.littleswan.com/u_download.html?type=Ujing&uuid=x"] { XCTAssertFalse(NativeQR.ujingCandidate(s)) } }
    func testRegistryStatusFailsClosed() async { let a = NativeAccount(provider: .xiqueer, alias: "test"); do { _ = try await NativeRegistry.service(for: a.provider).sessionStatus(account: a); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) } }
    func testLoginFailsClosed() async { let a = NativeAccount(provider: .xiqueer, alias: "test"); let service = NativeRegistry.service(for: a.provider); do { _ = try await service.beginLogin(account: a, input: .schoolAccount(schoolReference: "sample", account: "sample", password: "synthetic")); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) } }
    func testChallengeFailsClosed() async { let a = NativeAccount(provider: .life798, alias: "test"); do { _ = try await NativeRegistry.service(for: a.provider).completeLogin(account: a, challenge: "sample", response: "synthetic"); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) } }

}
extension NativeCoreTests {
    func testPhase4QR() {
        XCTAssertEqual(QRClassification.resolve("https://cloud.hnkzy.com/a"), .candidate(.life798))
        XCTAssertEqual(QRClassification.resolve("https://v3-api.china-qzxy.cn/a"), .candidate(.quzhi))
        XCTAssertEqual(QRClassification.resolve("https://d.ujing.online/a"), .candidate(.ujing))
        for s in ["https://cloud.hnkzy.com.evil.test/a", "https://u@cloud.hnkzy.com/a", "https://cloud.hnkzy.com:1234/a", "ilife798://unknown"] { XCTAssertEqual(QRClassification.resolve(s), .unknown) }
    }
    func testPhase4SensitiveCodes() { XCTAssertEqual(QRClassification.resolve("123456"), .sensitive); XCTAssertEqual(QRClassification.resolve("123456789012345678"), .sensitive); XCTAssertEqual(QRClassification.resolve("12345678"), .ambiguousNumber) }
    func testPhase4Form() throws {
        let data = Data(#"{"dataset":[{"field_ctr":"1","field_lable":"示例","field_ywid":"a","field_need":"1","field_editflag":"1"}]}"#.utf8)
        let f = try JSONDecoder().decode(AcademicFixture.self, from: data)
        XCTAssertTrue(f.valid()); XCTAssertTrue(f.dataset[0].editable); XCTAssertTrue(f.dataset[0].required); XCTAssertEqual(AcademicControl.from("5"), .readOnly)
    }
    func testPhase4Order() { XCTAssertTrue(BusinessOrderState.paid.allows(.running)); XCTAssertFalse(BusinessOrderState.uncertain.allows(.awaitingPayment)); XCTAssertFalse(BusinessOrderState.completed.allows(.running)) }
    func testPhase4Device() { XCTAssertTrue(DeviceAvailability.idle.permitsOrderCandidate); XCTAssertFalse(DeviceAvailability.unknown.permitsOrderCandidate) }
    func testPhase4Session() { XCTAssertFalse(ServiceSessionPhase.authenticated.permitsBusiness); XCTAssertTrue(ServiceSessionPhase.active.permitsBusiness); XCTAssertEqual(SMSFlowPhase.initial(authorized: false), .unavailable) }
}

extension NativeCoreTests {
    func testExplicitEnvelopeRejectsFailureWithData() {
        let data = Data(#"{"success":false,"data":42}"#.utf8)
        XCTAssertThrowsError(try NativeResponseDecoder.decode(Int.self, from: data, format: .explicitSuccessEnvelope))
    }
    func testExplicitEnvelopeDoesNotFallback() {
        for json in ["42", #"{"data":42}"#, #"{"success":true,"data":null}"#] {
            XCTAssertThrowsError(try NativeResponseDecoder.decode(Int.self, from: Data(json.utf8), format: .explicitSuccessEnvelope))
        }
    }
    func testExplicitEnvelopeSuccess() throws {
        XCTAssertEqual(try NativeResponseDecoder.decode(Int.self, from: Data(#"{"success":true,"data":42}"#.utf8), format: .explicitSuccessEnvelope), 42)
        XCTAssertEqual(try NativeResponseDecoder.decode(Int.self, from: Data("42".utf8), format: .rawJSON), 42)
    }
    func testLeaseIsAccountScoped() {
        let account = NativeAccount(provider: .life798, alias: "test")
        let other = NativeAccount(provider: .ujing, alias: "test")
        let now = Date(timeIntervalSince1970: 1000)
        let lease = SessionLease(account: account, expiresAt: now.addingTimeInterval(60))
        XCTAssertEqual(lease.state(for: account, now: now), .refreshDue)
        XCTAssertEqual(lease.state(for: account, now: now.addingTimeInterval(60)), .expired)
        XCTAssertEqual(lease.state(for: other, now: now), .unknown)
        XCTAssertEqual(SessionLease(account: account, expiresAt: nil).state(for: account, now: now), .unknown)
        XCTAssertEqual(SessionLease(account: account, expiresAt: now.addingTimeInterval(61)).state(for: account, now: now), .current)
    }
    func testSettlementAudit() {
        XCTAssertEqual(SettlementAudit.check(reserved: 100, charged: 60, refunded: 40, currency: "CNY", settlementCurrency: "CNY"), .consistent)
        XCTAssertEqual(SettlementAudit.check(reserved: 100, charged: 60, refunded: nil, currency: "CNY", settlementCurrency: "CNY"), .incomplete)
        XCTAssertEqual(SettlementAudit.check(reserved: 100, charged: 101, refunded: 0, currency: "CNY", settlementCurrency: "CNY"), .invalid)
        XCTAssertEqual(SettlementAudit.check(reserved: 100, charged: 60, refunded: 40, currency: "CNY", settlementCurrency: "USD"), .invalid)
        XCTAssertEqual(SettlementAudit.check(reserved: Int64.max, charged: -1, refunded: 0, currency: "CNY", settlementCurrency: "CNY"), .invalid)
    }
}

private final class TestAccountStorage: AccountDataStorage, @unchecked Sendable {
    private let lock = NSLock()
    private var data: [String: Data] = [:]
    func save(_ value: Data, account: NativeAccount) throws { lock.lock(); defer { lock.unlock() }; data[account.storageKey] = value }
    func load(account: NativeAccount) throws -> Data? { lock.lock(); defer { lock.unlock() }; return data[account.storageKey] }
    func remove(account: NativeAccount) throws { lock.lock(); defer { lock.unlock() }; data.removeValue(forKey: account.storageKey) }
}
extension NativeCoreTests {
    func testSessionColdRestoreAndClear() async throws {
        let a = NativeAccount(provider: .life798, alias: "A")
        let storage = TestAccountStorage()
        let session = try PersistedSession(account: a, expiresAt: nil, opaqueTicket: Data([1, 2]))
        try await SessionVault(storage: storage).save(session, for: a)
        let fresh = SessionVault(storage: storage)
        let restored = try await fresh.restore(for: a)
        XCTAssertEqual(restored, session)
        XCTAssertEqual(restored?.lease.state(for: a), .unknown)
        try await fresh.clear(for: a)
        let cleared = try await SessionVault(storage: storage).restore(for: a)
        XCTAssertNil(cleared)
    }
    func testSessionRejectsWrongAccountAndEmptyTicket() async throws {
        let a = NativeAccount(provider: .life798, alias: "A"), b = NativeAccount(provider: .ujing, alias: "B")
        let storage = TestAccountStorage(), vault = SessionVault(storage: storage)
        XCTAssertThrowsError(try PersistedSession(account: a, expiresAt: nil, opaqueTicket: Data()))
        let session = try PersistedSession(account: a, expiresAt: nil, opaqueTicket: Data([1]))
        do { try await vault.save(session, for: b); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .invalidResponse) }
        try storage.save(JSONEncoder().encode(session), account: b)
        do { _ = try await vault.restore(for: b); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .invalidResponse) }
    }
    func testJournalSurvivesRestartAndBlocksDuplicate() async throws {
        let a = NativeAccount(provider: .ujing, alias: "A"), b = NativeAccount(provider: .quzhi, alias: "B")
        let storage = TestAccountStorage(), first = OperationJournal(storage: storage)
        let op = try await first.prepare(for: a)
        try await first.markSubmitted(op.id, for: a)
        let fresh = OperationJournal(storage: storage)
        let recovered = try await fresh.recover(for: a)
        XCTAssertEqual(recovered?.state, .uncertain)
        do { _ = try await fresh.prepare(for: a); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .unresolvedOperation) }
        let independent = try await fresh.prepare(for: b)
        XCTAssertNotEqual(independent.id, op.id)
        try await fresh.reconcile(op.id, for: a, confirmed: false)
        let next = try await fresh.prepare(for: a)
        XCTAssertNotEqual(next.id, op.id)
    }
    func testJournalCancelOnlyBeforeSubmission() async throws {
        let a = NativeAccount(provider: .quzhi, alias: "A"), journal = OperationJournal(storage: TestAccountStorage())
        let op = try await journal.prepare(for: a)
        try await journal.cancelPrepared(op.id, for: a)
        let next = try await journal.prepare(for: a)
        try await journal.markSubmitted(next.id, for: a)
        do { try await journal.cancelPrepared(next.id, for: a); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .unresolvedOperation) }
    }
    func testJournalCorruptRecordFailsClosed() async throws {
        let a = NativeAccount(provider: .ujing, alias: "A"), storage = TestAccountStorage()
        try storage.save(Data([0]), account: a)
        do { _ = try await OperationJournal(storage: storage).prepare(for: a); XCTFail() } catch { XCTAssertNotNil(error) }
    }
}

private struct SyntheticLoginAdapter: PlatformService {
    let provider: NativeProvider
    let isAuthorized: Bool
    let session: NativeSessionState
    func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome { .challengeRequired(reference: "synthetic-reference") }
    func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome { .authenticated }
    func sessionStatus(account: NativeAccount) async throws -> NativeSessionState { session }
    func signOut(account: NativeAccount) async throws {}
}
extension NativeCoreTests {
    func testLoginFlowSyntheticChallenge() async throws {
        let a = NativeAccount(provider: .ujing, alias: "test")
        let flow = NativeLoginFlow(service: SyntheticLoginAdapter(provider: .ujing, isAuthorized: true, session: .valid), account: a)
        let first = try await flow.begin(.phoneChallenge(phone: "synthetic"))
        XCTAssertEqual(first, .challengeRequired(reference: "synthetic-reference"))
        let result = try await flow.complete(reference: "synthetic-reference", response: "synthetic")
        XCTAssertEqual(result, .authenticated)
    }
    func testLoginFlowRequiresVerifiedSession() async {
        let flow = NativeLoginFlow(service: SyntheticLoginAdapter(provider: .ujing, isAuthorized: true, session: .signedOut), account: NativeAccount(provider: .ujing, alias: "test"))
        do { _ = try await flow.complete(reference: "test", response: "test"); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .invalidResponse) }
    }
    func testLoginFlowRejectsWrongProvider() async {
        let flow = NativeLoginFlow(service: SyntheticLoginAdapter(provider: .ujing, isAuthorized: true, session: .valid), account: NativeAccount(provider: .life798, alias: "test"))
        do { _ = try await flow.begin(.phoneChallenge(phone: "synthetic")); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) }
    }
    func testLoginFlowUnavailable() async {
        let a = NativeAccount(provider: .life798, alias: "test")
        let flow = NativeLoginFlow(service: NativeRegistry.service(for: a.provider), account: a)
        do { _ = try await flow.begin(.phoneChallenge(phone: "synthetic")); XCTFail() } catch { XCTAssertEqual(error as? NativeAPIError, .authorizationMissing) }
    }
}
