// swift-tools-version: 5.7
import PackageDescription
let package = Package(name: "NativeCore", platforms: [.iOS(.v15), .macOS(.v12)], products: [.library(name: "NativeCore", targets: ["NativeCore"])], targets: [.target(name: "NativeCore"), .testTarget(name: "NativeCoreTests", dependencies: ["NativeCore"])])
