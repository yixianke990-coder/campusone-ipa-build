import SwiftUI
import UniformTypeIdentifiers
import UserNotifications

// Explicit local schedule reminders; never represent an official change notification.
@MainActor enum CampusCourseReminders {
    static let prefix = "campus.course."
    static func cancel() async {
        let center = UNUserNotificationCenter.current()
        let pending = await center.pendingNotificationRequests()
        center.removePendingNotificationRequests(withIdentifiers: pending.filter { $0.identifier.hasPrefix(prefix) }.map(\.identifier))
    }
    static func schedule(_ store: CampusStore, lead: Int) async -> String {
        let center = UNUserNotificationCenter.current()
        do {
            guard try await center.requestAuthorization(options: [.alert, .sound]) else { return "通知未授权。" }
            await cancel()
            let pending = await center.pendingNotificationRequests()
            let limit = max(0, min(32, 60 - pending.count))
            let now = Date(), cal = Calendar.current
            var upcoming: [(Course, Date)] = []
            for offset in 0..<7 {
                guard let day = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: now)) else { continue }
                for c in store.displayedCourses where c.weekday == Course.today(day) {
                    if store.term.name.isEmpty { guard c.detail?.term.isEmpty ?? true else { continue } }
                    else { guard let week = store.term.currentWeek(on: day), store.term.includes(c, week: week) else { continue } }
                    guard let start = cal.date(byAdding: .minute, value: c.start, to: day) else { continue }
                    let fire = start.addingTimeInterval(-Double(lead * 60)); if fire > now { upcoming.append((c, fire)) }
                }
            }
            var count = 0
            for (course, fire) in upcoming.sorted(by: { $0.1 < $1.1 }).prefix(limit) {
                let content = UNMutableNotificationContent(); content.title = "课程即将开始"; content.body = "请打开工贸助手核对本地课表。"; content.sound = .default
                let id = prefix + course.id.uuidString + "." + String(Int(fire.timeIntervalSince1970))
                try await center.add(UNNotificationRequest(identifier: id, content: content, trigger: UNTimeIntervalNotificationTrigger(timeInterval: max(1, fire.timeIntervalSinceNow), repeats: false)))
                count += 1
            }
            return "已安排 \(count) 条未来七天的本地提醒。课表变化后请重新安排。"
        } catch { return "通知安排未全部成功，请检查系统权限后重试。" }
    }
}
struct CourseReminderSettings: View {
    @EnvironmentObject private var store: CampusStore
    @AppStorage("courseReminderLead") private var lead = 10
    @State private var message = ""
    @State private var busy = false
    var body: some View {
        List {
            Section {
                Stepper("提前 \(lead) 分钟", value: $lead, in: 5...60, step: 5)
                Button("安排未来七天课程提醒") { busy = true; Task { message = await CampusCourseReminders.schedule(store, lead: lead); busy = false } }.disabled(busy)
                Button("取消课程提醒", role: .destructive) { busy = true; Task { await CampusCourseReminders.cancel(); message = "已取消课程提醒。"; busy = false } }.disabled(busy)
                if !message.isEmpty { Text(message).font(.footnote).foregroundStyle(.secondary) }
            } header: { Text("提醒时间") }  footer: { Text("本地通知不包含课程名称或个人账号。不会从学校获取调课消息；课表或学期改变后重新安排，以免提醒过时。") }
        }.navigationTitle("课程提醒")
    }
}

struct CampusBackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(data: Data = Data()) { self.data = data }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents, data.count <= 2_000_000 else { throw CocoaError(.fileReadCorruptFile) }; self.data = data
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}
struct CampusBackupView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var exportFile = CampusBackupDocument()
    @State private var exporting = false
    @State private var importing = false
    @State private var pending: CampusLocalBackup?
    @State private var confirm = false
    @State private var status = ""
    var body: some View {
        List {
            Section {
                Button("导出本地记录", action: export)
                Button("导入并恢复记录") { importing = true }
                if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(.secondary) }
            } header: { Text("本地备份") }  footer: { Text("包含手动课表、学期、设备收藏及手动消费记录。文件未加密，请妥善保存；不含账号凭证、网页登录状态、在线课表缓存、网站配置或计时器。") }
        }.navigationTitle("备份与恢复")
            .fileExporter(isPresented: $exporting, document: exportFile, contentType: .json, defaultFilename: "Gongmao-Local-Backup") { result in
                switch result { case .success: status = "备份已导出。"; case .failure: status = "导出失败。" }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                do {
                    let url = try result.get(), access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? Int.max
                    guard size <= 2_000_000 else { throw CocoaError(.fileReadCorruptFile) }
                    let data = try Data(contentsOf: url); guard data.count <= 2_000_000 else { throw CocoaError(.fileReadCorruptFile) }
                    let backup = try JSONDecoder().decode(CampusLocalBackup.self, from: data)
                    guard backup.valid(serviceIDs: Set(store.services.map(\.id))) else { throw CocoaError(.fileReadCorruptFile) }
                    pending = backup; confirm = true
                } catch { status = "备份不可读取、不兼容或包含未配置的服务；原有数据未改变。" }
            }
            .confirmationDialog("替换当前本地记录？", isPresented: $confirm, titleVisibility: .visible) {
                Button("恢复并替换", role: .destructive) { if let backup = pending { store.term = backup.term; store.courses = backup.courses; store.devices = backup.devices; store.expenses = backup.expenses; Task { await CampusCourseReminders.cancel() }; status = "已恢复本地记录；请重新安排课程提醒。" }; pending = nil }
                Button("取消", role: .cancel) { pending = nil }
            } message: { Text("将替换手动课表、学期、设备收藏和手动消费记录。在线缓存及账号不受影响。") }
    }
    private func export() {
        do { let data = try JSONEncoder().encode(CampusLocalBackup(term: store.term, courses: store.courses, devices: store.devices, expenses: store.expenses)); guard data.count <= 2_000_000 else { status = "数据过大。"; return }; exportFile = .init(data: data); exporting = true }
        catch { status = "备份编码失败。" }
    }
}
