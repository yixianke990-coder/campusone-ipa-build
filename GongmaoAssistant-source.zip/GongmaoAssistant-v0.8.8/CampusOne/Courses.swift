import SwiftUI

struct CourseRow: View {
    let course: Course
    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) { Text(Course.time(course.start)).font(.headline.monospacedDigit()); Text(Course.time(course.end)).font(.caption.monospacedDigit()).foregroundStyle(.secondary) }.frame(width: 57, alignment: .leading)
            Capsule().fill(course.displayColor).frame(width: 4, height: 46)
            VStack(alignment: .leading, spacing: 4) { Text(course.name).font(.headline); if !course.location.isEmpty { Label(course.location, systemImage: "mappin").font(.caption).foregroundStyle(.secondary) }; if let teacher = course.detail?.teacher, !teacher.isEmpty { Label(teacher, systemImage: "person").font(.caption).foregroundStyle(.secondary) } }
            Spacer()
        }.padding(.vertical, 5)
    }
}
struct CoursesView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var day = Course.today()
    @State private var editing: Course?
    @State private var week = 1
    @State private var weekly = true
    private func visible(_ course: Course) -> Bool { store.term.name.isEmpty ? (course.detail?.term.isEmpty ?? true) : store.term.includes(course, week: week) }
    var body: some View {
        List {
            Section("学期与教学周") {
                NavigationLink { TermSettings() } label: { Label(store.term.name.isEmpty ? "设置学期（未配置）" : store.term.name, systemImage: "calendar.badge.clock") }
                if !store.term.name.isEmpty {
                    HStack {
                        Button { week = max(1, week - 1) } label: { Image(systemName: "chevron.left").frame(minWidth: 44, minHeight: 44) }.buttonStyle(.borderless).disabled(week <= 1).accessibilityLabel("上一教学周")
                        Spacer(); VStack(spacing: 3) { Text("第 \(week) 周").font(.title3.bold()); if week == store.term.currentWeek() { Text("本周").font(.caption).foregroundStyle(.secondary) } }; Spacer()
                        Button { week = min(store.term.weeks, week + 1) } label: { Image(systemName: "chevron.right").frame(minWidth: 44, minHeight: 44) }.buttonStyle(.borderless).disabled(week >= store.term.weeks).accessibilityLabel("下一教学周")
                    }
                    Button("回到本周") { if let current = store.term.currentWeek() { week = current } }.disabled(store.term.currentWeek() == nil)
                }
                Picker("课表视图", selection: $weekly) { Text("周课表").tag(true); Text("日课表").tag(false) }.pickerStyle(.segmented)
                if weekly { WeekSchedule(courses: store.displayedCourses.filter(visible), term: store.term, week: week) }
                Picker("星期", selection: $day) { ForEach(1...7, id: \.self) { Text(Course.days[$0-1]).tag($0) } }.pickerStyle(.segmented)
            }
            Section("在线课表") {
                if store.onlineEndpoint.isEmpty {
                    FeatureRow(title: "尚未连接在线课表", subtitle: "仍可查看手动课程，原生同步待授权")
                    Text("尚未配置授权课表接口；喜鹊儿原生登录未接入。").font(.footnote).foregroundStyle(.secondary)
                } else {
                    if let snapshot = store.onlineSnapshot {
                        CampusValueRow("最近成功同步", value: snapshot.syncedAt.formatted(date: .abbreviated, time: .shortened))
                        Text("已缓存 \(snapshot.courses.count) 条在线课程。即使离线也可以查看。").font(.caption).foregroundStyle(.secondary)
                    } else { Text("尚无成功同步记录").foregroundStyle(.secondary) }
                    if let error = store.syncError { Text(error).font(.footnote).foregroundStyle(.red) }
                    Button { Task { await store.refreshOnline() } } label: {
                        if store.refreshing { HStack { ProgressView(); Text("正在同步") } }
                        else { Label("立即刷新在线课表", systemImage: "arrow.clockwise") }
                    }.disabled(store.refreshing)
                }
                NavigationLink { OnlineCourseSettings() } label: { Label("在线同步设置", systemImage: "gearshape") }
            }
            Section("\(Course.days[day-1]) · 本地课表") {
                let courses = store.courses.filter { $0.weekday == day && visible($0) }.sorted { $0.start < $1.start }
                if courses.isEmpty { CampusEmptyState("暂无本地课程", systemImage: "calendar", description: Text("点击右上角添加个人课程；在线缓存单独显示。")) }
                ForEach(courses) { course in Button { editing = course } label: { CourseRow(course: course) }.buttonStyle(.plain) }
                    .onDelete { offsets in let ids = Set(offsets.map { courses[$0].id }); store.courses.removeAll { ids.contains($0.id) } }
            }
            if let snapshot = store.onlineSnapshot {
                Section("\(Course.days[day-1]) · 在线缓存（只读）") {
                    let online = snapshot.courses.filter { $0.weekday == day && visible($0) }.sorted { $0.start < $1.start }
                    if online.isEmpty { Text("当天没有在线课程").foregroundStyle(.secondary) }
                    ForEach(online) { course in NavigationLink { CourseInspection(course: course) } label: { CourseRow(course: course) } }
                }
            }
            Section {
                NavigationLink { CourseReminderSettings() } label: { Label("课程提醒", systemImage: "bell.badge") }
                NavigationLink { CourseImportView() } label: { Label("批量导入本地课表", systemImage: "square.and.arrow.down") }
                if let service = store.services.first(where: { $0.storeID == "1152127141" }) {
                    NavigationLink { AccountAccessView(service: service) } label: { Label("喜鹊儿原生账号与授权", systemImage: "person.crop.circle") }
                    NavigationLink { ServiceDetail(id: service.id) } label: { Label("喜鹊儿教务中心", systemImage: "arrow.up.forward.app") }
                }
                Text("已配置学期时按周次筛选；无周次元数据的课程默认每周显示。节假日调课需以官方课表为准。在线同步需要授权 JSON 接口，并非喜鹊儿原生接口。") .font(.footnote).foregroundStyle(.secondary)
            }
        }.listStyle(.insetGrouped).navigationTitle("课表").toolbar {
            Button("刷新", campusIcon: "arrow.clockwise") { Task { await store.refreshOnline() } }.disabled(store.refreshing || store.onlineEndpoint.isEmpty)
            Button("添加课程", campusIcon: "plus") { editing = Course(name: "", location: "", weekday: day, start: 480, end: 570) }
        }
            .refreshable { await store.refreshOnline() }
            .onAppear { week = store.term.currentWeek() ?? 1 }
            .onChange(of: store.term) { _ in week = store.term.currentWeek() ?? 1 }
            .task { if store.refreshOnOpen { await store.refreshOnline() } }
            .sheet(item: $editing) { course in CampusNavigation { CourseEditor(course: course) } }
    }
}
struct CourseEditor: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State var course: Course
    @State private var detail = CourseDetail()
    private func date(_ minutes: Int) -> Date { Calendar.current.date(from: DateComponents(year: 2024, month: 1, day: 1, hour: minutes / 60, minute: minutes % 60)) ?? Date() }
    private func minutes(_ date: Date) -> Int { Calendar.current.component(.hour, from: date) * 60 + Calendar.current.component(.minute, from: date) }
    var body: some View {
        Form {
            TextField("课程名称", text: $course.name)
            TextField("上课地点", text: $course.location)
            Picker("星期", selection: $course.weekday) { ForEach(1...7, id: \.self) { Text(Course.days[$0-1]).tag($0) } }
            DatePicker("开始时间", selection: Binding(get: { date(course.start) }, set: { course.start = minutes($0) }), displayedComponents: .hourAndMinute)
            DatePicker("结束时间", selection: Binding(get: { date(course.end) }, set: { course.end = minutes($0) }), displayedComponents: .hourAndMinute)
            Section("课程详情与教学周") {
                TextField("教师（可选）", text: $detail.teacher)
                CampusMultiline(title: "备注", text: $detail.note)
                TextField("所属学期（留空为通用）", text: $detail.term)
                Stepper("开始周：\(detail.firstWeek)", value: $detail.firstWeek, in: 1...30)
                Stepper("结束周：\(detail.lastWeek)", value: $detail.lastWeek, in: 1...30)
                Picker("单双周", selection: $detail.parity) { Text("每周").tag("all"); Text("单周").tag("odd"); Text("双周").tag("even") }
                if !detail.isValid { Text("请检查周次及文字长度。").foregroundStyle(.red) }
            }
            if course.end <= course.start { Text("结束时间必须晚于开始时间。") .foregroundStyle(.red) }
        }.navigationTitle("编辑课程").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("保存") { course.name = course.name.trimmingCharacters(in: .whitespacesAndNewlines); course.detail = detail; store.save(course); dismiss() }.disabled(course.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || course.end <= course.start || !detail.isValid) } }
            .onAppear { detail = course.detail ?? CourseDetail(term: store.term.name) }
    }
}

struct OnlineCourseSettings: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State private var endpoint = ""
    @State private var token = ""
    @State private var auto = false
    @State private var failed = false
    var body: some View {
        Form {
            Section("已授权的课表接口") {
                TextField("HTTPS JSON 接口地址", text: $endpoint).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                SecureField("只读接口令牌（可选）", text: $token).textInputAutocapitalization(.never).autocorrectionDisabled()
                Toggle("进入课表自动刷新", isOn: $auto)
                Text("仅填写你有权访问、信任的课表接口。此处不是喜鹊儿账号密码登录。令牌只发送到填写的 HTTPS 地址，并保存在本机 Keychain。更换地址或令牌会清除旧在线缓存，不影响手动课程。").font(.footnote).foregroundStyle(.secondary)
            }
            Section {
                Button("保存配置") {
                    if store.configureOnline(endpoint, token: token, auto: auto) { dismiss() } else { failed = true }
                }
                Button("断开在线同步并清除缓存", role: .destructive) {
                    if store.configureOnline("", token: "", auto: false) { dismiss() } else { failed = true }
                }
            }
            Section("接口说明") {
                Text("需要 schemaVersion=1 的 工贸助手 JSON 课表接口。原始喜鹊儿 API 暂未适配；请勿直接填入登录页面地址。无接口时仍可导入本地课表。").font(.footnote).foregroundStyle(.secondary)
            }
        }.navigationTitle("在线同步设置")
            .onAppear { endpoint = store.onlineEndpoint; token = CourseFeedVault.read(); auto = store.refreshOnOpen }
            .alert("无法保存配置", isPresented: $failed) { Button("确定", role: .cancel) {} } message: { Text("检查 HTTPS 地址、令牌格式和本机凭证存储。") }
    }
}

struct TermSettings: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft = AcademicTerm()
    var body: some View {
        Form {
            Section("当前学期") {
                TextField("例如 2026–2027 第一学期", text: $draft.name)
                DatePicker("第一教学周所在日期", selection: $draft.start, displayedComponents: .date)
                Stepper("教学周数：\(draft.weeks)", value: $draft.weeks, in: 1...30)
                CampusValueRow("第一周周一", value: draft.monday().formatted(date: .abbreviated, time: .omitted))
                Text("学期名称需与课程所属学期一致。按学校校历手动配置，不是官方自动获取。切换学期不会删除旧课程。") .font(.footnote).foregroundStyle(.secondary)
            }
            Button("保存") { draft.name = draft.name.trimmingCharacters(in: .whitespacesAndNewlines); store.term = draft; dismiss() }.disabled(draft.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || draft.name.count > 80)
            Button("取消学期筛选", role: .destructive) { store.term = AcademicTerm(); dismiss() }
        }.navigationTitle("学期设置").onAppear { draft = store.term }
    }
}

// Seven columns, horizontal scroll to retain readable Chinese labels on small phones.
struct WeekSchedule: View {
    let courses: [Course]
    let term: AcademicTerm
    let week: Int
    private var starts: [Int] { Array(Set(courses.map(\.start))).sorted() }
    var body: some View {
        if courses.isEmpty {
            CampusEmptyState("本周暂无课程", systemImage: "calendar", description: Text("可添加课程、切换教学周或同步授权课表。"))
        } else {
            ScrollView(.horizontal) {
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .top, spacing: 6) {
                        Text("时间").font(.caption2).foregroundStyle(.secondary).frame(width: 42)
                        ForEach(1...7, id: \.self) { day in
                            VStack(spacing: 4) {
                                Text(Course.days[day - 1]).font(.subheadline.weight(.semibold))
                                if !term.name.isEmpty, let date = term.date(week: week, day: day) { Text(date.formatted(.dateTime.month().day())).font(.caption2).foregroundStyle(.secondary) }
                            }.frame(width: 108).padding(.vertical, 8).background((day == Course.today() && term.currentWeek() == week) ? Color.accentColor.opacity(0.14) : Color.secondary.opacity(0.06), in: RoundedRectangle(cornerRadius: 10))
                        }
                    }
                    ForEach(starts, id: \.self) { start in
                        HStack(alignment: .top, spacing: 6) {
                            Text(Course.time(start)).font(.caption2.monospacedDigit()).foregroundStyle(.secondary).frame(width: 42, alignment: .leading).padding(.top, 8)
                            ForEach(1...7, id: \.self) { day in
                                let items = courses.filter { $0.weekday == day && $0.start == start }.sorted { $0.end < $1.end }
                                VStack(alignment: .leading, spacing: 5) {
                                    if items.isEmpty { RoundedRectangle(cornerRadius: 10).fill(Color.secondary.opacity(0.035)).frame(height: 54).accessibilityHidden(true) }
                                    ForEach(items) { course in
                                        NavigationLink { CourseInspection(course: course) } label: {
                                            VStack(alignment: .leading, spacing: 5) {
                                                Text(course.name).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                                                Text(Course.time(course.start) + "–" + Course.time(course.end)).font(.caption2.monospacedDigit())
                                                if !course.location.isEmpty { Text(course.location).font(.caption2) }
                                            }.frame(maxWidth: .infinity, alignment: .leading).padding(8).background(course.displayColor.opacity(0.13), in: RoundedRectangle(cornerRadius: 10)).overlay(alignment: .leading) { RoundedRectangle(cornerRadius: 2).fill(course.displayColor).frame(width: 3).padding(.vertical, 6).accessibilityHidden(true) }
                                        }.buttonStyle(.plain)
                                    }
                                }.frame(width: 108, alignment: .topLeading)
                            }
                        }
                    }
                }.padding(.vertical, 5)
            }.accessibilityLabel("周课表，按开始时间分行，左右滑动查看七天")
            Text("左右滑动查看七天 · 点击课程查看详情").font(.caption2).foregroundStyle(.secondary)
        }
    }
}

extension Course {
    var displayColor: Color {
        let palette: [Color] = [.blue, .indigo, .teal, .orange, .purple, .pink, .green]
        return palette[name.utf8.reduce(0) { ($0 + Int($1)) % palette.count }]
    }
}
struct CourseInspection: View {
    let course: Course
    var body: some View {
        List {
            Section { HStack(spacing: 14) { FeatureIcon(symbol: "book.closed", color: course.displayColor, size: 56); Text(course.name).font(.title2.bold()) } }
            Section("上课信息") {
                CampusValueRow("星期", value: (1...7).contains(course.weekday) ? Course.days[course.weekday - 1] : "未设置")
                CampusValueRow("时间", value: Course.time(course.start) + " – " + Course.time(course.end))
                CampusValueRow("教室", value: course.location.isEmpty ? "未设置" : course.location)
                CampusValueRow("教师", value: course.detail?.teacher.isEmpty == false ? (course.detail?.teacher ?? "") : "未设置")
            }
            Section("教学周") {
                if let detail = course.detail {
                    CampusValueRow("学期", value: detail.term.isEmpty ? "通用" : detail.term)
                    CampusValueRow("周次", value: "第 \(detail.firstWeek) – \(detail.lastWeek) 周")
                    CampusValueRow("单双周", value: detail.parity == "odd" ? "单周" : detail.parity == "even" ? "双周" : "每周")
                    if !detail.note.isEmpty { Text(detail.note).textSelection(.enabled) }
                } else { Text("未设置周次与备注") }
            }
            Section { Text("这里显示本地课程或上次成功同步的数据，请以学校最新安排为准。").font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("课程详情").navigationBarTitleDisplayMode(.inline)
    }
}
