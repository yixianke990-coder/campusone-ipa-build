import SwiftUI
import AVFoundation
import UIKit
import PhotosUI
import Vision
import ImageIO
import UniformTypeIdentifiers

struct ScanView: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State private var raw = ""
    @State private var picking = false
    @State private var scanning = false
    @State private var status = ""
    @State private var selected: UUID?
    @State private var copied = false
    @State private var photoLoading = false
    var classification: QRClassification { .resolve(raw) }
    var matches: [Service] {
        if classification == .sensitive || classification == .ambiguousNumber { return [] }
        let configured = Routing.matches(raw, services: store.services)
        guard case .candidate(let provider) = classification else { return configured }
        let ids = Set(configured.map(\.id))
        return configured + store.services.filter { $0.enabled && $0.nativeProvider == provider && !ids.contains($0.id) }
    }
    var choices: [Service] { classification == .sensitive ? [] : (matches.isEmpty ? store.services.filter { $0.enabled } : matches) }
    var body: some View {
        List {
            Section {
                Button { requestCamera() } label: {
                    VStack(alignment: .center, spacing: 12) {
                        Image(systemName: "qrcode.viewfinder").font(.system(size: 46, weight: .light)).foregroundStyle(CampusDesign.gold).accessibilityHidden(true)
                        Text("扫一扫").font(.title2.bold()).foregroundStyle(.white)
                        Text("识别设备二维码 · 自动匹配候选平台").font(.subheadline).foregroundStyle(.white.opacity(0.9)).multilineTextAlignment(.center)
                        Label("打开相机", systemImage: "camera.fill").font(.headline).foregroundStyle(.white)
                            .padding(.horizontal, 18).padding(.vertical, 10).background(.white.opacity(0.15), in: Capsule())
                    }.frame(maxWidth: .infinity).padding(22)
                    .background(LinearGradient(colors: [CampusDesign.navy, CampusDesign.blue], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                }.buttonStyle(.plain).listRowInsets(EdgeInsets()).listRowBackground(Color.clear).accessibilityLabel("打开相机扫描设备二维码")
                if photoLoading { ProgressView("正在识别图片…") }
                Button { picking = true } label: { HStack { FeatureIcon(symbol: "photo.on.rectangle", size: 40); Text("从相册识别"); Spacer(); Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary) } }.disabled(photoLoading)
                if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(.secondary) }
                CampusMultiline(title: "或粘贴设备二维码内容", text: $raw).textInputAutocapitalization(.never).autocorrectionDisabled()
                if !raw.isEmpty { Button("清空") { raw = ""; selected = nil; copied = false } }
            } footer: { Text("只支持标准二维码；专有小程序码、蓝牙设备码等需要各平台支持。相机不可用时可手动粘贴。") }
            if !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Section("识别结果") {
                    if classification == .sensitive { Label("可能是付款码或临时验证码，已阻止设备分流", systemImage: "lock.shield") }
                    else if matches.count == 1 { HStack { ServiceIcon(service: matches[0], size: 42); VStack(alignment: .leading) { Text(matches[0].name).font(.headline); Text("候选平台 · 请确认").font(.caption).foregroundStyle(.secondary) } } }
                    else if matches.count > 1 { Label("多个服务匹配，请手动确认", systemImage: "exclamationmark.triangle").foregroundStyle(.orange) }
                    else { Label("无法确定服务商", systemImage: "questionmark.circle").foregroundStyle(.secondary) }
                    if NativeQR.ujingCandidate(raw) { Text("符合第三阶段报告中的 U净二维码候选格式，仅本地识别，尚未验证实际设备。") .font(.footnote).foregroundStyle(.secondary) }
                    else if case .candidate = classification { Text("根据第四阶段静态报告的域名匹配候选平台；不代表真实设备已验证。") .font(.footnote).foregroundStyle(.secondary) }
                    else if let host = Routing.httpsURL(raw)?.host { CampusValueRow("二维码域名", value: host) }
                    else { Text("非标准 HTTPS 链接，不自动解析设备信息。") .font(.footnote).foregroundStyle(.secondary) }
                    if classification == .sensitive { Text("请不要扫描个人付款码或登录验证码。") }
                    else if choices.isEmpty { Text("没有可用的服务，请先启用服务。") }
                    else {
                        Picker("选择服务", selection: $selected) {
                            Text("请选择").tag(nil as UUID?)
                            ForEach(choices) { service in Label(service.name, systemImage: service.symbol).tag(Optional(service.id)) }
                        }
                        if let id = selected ?? (matches.count == 1 ? matches[0].id : nil), choices.contains(where: { $0.id == id }) {
                            if let service = choices.first(where: { $0.id == id }) {
                                NavigationLink { ServiceDetail(id: id) } label: {
                                    HStack { ServiceIcon(service: service, size: 36); VStack(alignment: .leading) { Text("确认并打开原生服务"); Text(service.name).font(.caption).foregroundStyle(.secondary) } }
                                }
                            }
                        }
                    }
                    Button(copied ? "已复制" : "复制二维码原文", campusIcon: "doc.on.doc") {
                        UIPasteboard.general.setItems([["public.utf8-plain-text": raw]], options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(120)]); copied = true
                    }.disabled(classification == .sensitive)
                    Text("打开服务入口不会自动传入设备编号、启动设备或付款。设备身份须由授权接口进一步确认。二维码原文不写入历史。") .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }.listStyle(.insetGrouped).navigationTitle("扫一扫").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
            .sheet(isPresented: $picking) {
                CampusPhotoPicker { data in
                    picking = false
                    if let data = data { Task { await readPhoto(data) } }
                }
            }
            .onChange(of: raw) { _ in selected = nil; copied = false }
            .fullScreenCover(isPresented: $scanning) {
                CampusNavigation {
                    CameraScanner(onCode: { code in raw = code; scanning = false }, onError: { text in status = text; scanning = false })
                        .ignoresSafeArea(edges: .bottom).navigationTitle("扫描设备二维码").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { scanning = false } } }
                }
            }
    }
    @MainActor private func readPhoto(_ data: Data) async {
        photoLoading = true; defer { photoLoading = false }
        do {
            guard data.count <= 30_000_000 else { status = "图片超过大小限制。"; return }
            let codes = try await Task.detached(priority: .userInitiated) { () throws -> [String] in
                let request = VNDetectBarcodesRequest(); request.symbologies = [.qr]
                try VNImageRequestHandler(data: data).perform([request])
                return Array(Set((request.results ?? []).compactMap(\.payloadStringValue)))
            }.value
            if codes.count == 1 { raw = codes[0]; status = "已识别相册二维码。" }
            else { raw = ""; status = codes.isEmpty ? "图片中未识别到标准二维码。" : "图片中存在多个二维码，请裁剪后重试。" }
        } catch { status = "图片识别失败。" }
    }
    private func requestCamera() {
        guard AVCaptureDevice.default(for: .video) != nil else { status = "当前设备没有可用相机，可从相册识别或粘贴。"; return }
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: startIfAvailable()
        case .notDetermined:
            Task { if await AVCaptureDevice.requestAccess(for: .video) { startIfAvailable() } else { status = "未授权相机，可在系统设置开启。" } }
        default: status = "相机权限不可用，请前往系统设置，或粘贴原文。"
        }
    }
    private func startIfAvailable() {
        guard AVCaptureDevice.authorizationStatus(for: .video) == .authorized else { status = "相机当前不可用。"; return }
        status = ""; scanning = true
    }
}

// PHPicker grants access only to the selected photo, available since iOS 14.
struct CampusPhotoPicker: UIViewControllerRepresentable {
    let onResult: (Data?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onResult) }
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration(); config.filter = .images; config.selectionLimit = 1
        let picker = PHPickerViewController(configuration: config); picker.delegate = context.coordinator; return picker
    }
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let onResult: (Data?) -> Void
        init(_ onResult: @escaping (Data?) -> Void) { self.onResult = onResult }
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            guard let provider = results.first?.itemProvider else { onResult(nil); return }
            provider.loadDataRepresentation(forTypeIdentifier: UTType.image.identifier) { data, _ in
                DispatchQueue.main.async { self.onResult(data) }
            }
        }
    }
}

struct CameraScanner: UIViewControllerRepresentable {
    let onCode: (String) -> Void
    let onError: (String) -> Void
    func makeUIViewController(context: Context) -> CampusCameraController { CampusCameraController(onCode: onCode, onError: onError) }
    func updateUIViewController(_ uiViewController: CampusCameraController, context: Context) {}
    static func dismantleUIViewController(_ uiViewController: CampusCameraController, coordinator: ()) { uiViewController.stop() }
}
final class CampusCameraController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    private let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "gongmao.qr.camera")
    private var preview: AVCaptureVideoPreviewLayer?
    private var delivered = false
    private var configured = false
    private let onCode: (String) -> Void
    private let onError: (String) -> Void
    private let guide = UIView()
    private let torchButton = UIButton(type: .system)
    private var torchRequested = false
    init(onCode: @escaping (String) -> Void, onError: @escaping (String) -> Void) { self.onCode = onCode; self.onError = onError; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) not supported") }
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = .black
        guide.layer.borderColor = UIColor.white.withAlphaComponent(0.9).cgColor; guide.layer.borderWidth = 2; guide.layer.cornerRadius = 22
        guide.isUserInteractionEnabled = false; view.addSubview(guide)
        let layer = AVCaptureVideoPreviewLayer(session: session); layer.videoGravity = .resizeAspectFill; view.layer.insertSublayer(layer, at: 0); preview = layer
        torchButton.setImage(UIImage(systemName: "flashlight.off.fill"), for: .normal)
        torchButton.tintColor = .white; torchButton.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        torchButton.layer.cornerRadius = 27; torchButton.isEnabled = false
        torchButton.accessibilityLabel = "打开手电筒"
        torchButton.addTarget(self, action: #selector(toggleTorch), for: .touchUpInside)
        view.addSubview(torchButton)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews(); preview?.frame = view.bounds
        let side = min(view.bounds.width * 0.70, view.bounds.height * 0.55); guide.frame = CGRect(x: (view.bounds.width-side)/2, y: (view.bounds.height-side)/2, width: side, height: side)
        torchButton.frame = CGRect(x: (view.bounds.width - 54) / 2, y: min(guide.frame.maxY + 24, view.bounds.height - view.safeAreaInsets.bottom - 66), width: 54, height: 54)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        queue.async { [weak self] in
            guard let self = self else { return }
            if !self.configured {
                guard let camera = AVCaptureDevice.default(for: .video), let input = try? AVCaptureDeviceInput(device: camera) else { self.fail(); return }
                self.session.beginConfiguration()
                let output = AVCaptureMetadataOutput()
                guard self.session.canAddInput(input), self.session.canAddOutput(output) else { self.session.commitConfiguration(); self.fail(); return }
                self.session.addInput(input); self.session.addOutput(output)
                guard output.availableMetadataObjectTypes.contains(.qr) else { self.session.commitConfiguration(); self.fail(); return }
                output.setMetadataObjectsDelegate(self, queue: .main); output.metadataObjectTypes = [.qr]
                self.session.commitConfiguration(); self.configured = true
            }
            if !self.session.isRunning { self.session.startRunning() }
            let available = (self.session.inputs.first as? AVCaptureDeviceInput)?.device.hasTorch == true
            DispatchQueue.main.async { [weak self] in self?.torchButton.isEnabled = available }
        }
    }
    override func viewWillDisappear(_ animated: Bool) { super.viewWillDisappear(animated); stop() }
    @objc private func toggleTorch() {
        torchRequested.toggle()
        let requested = torchRequested
        torchButton.isEnabled = false
        queue.async { [weak self] in
            guard let self else { return }
            let device = (self.session.inputs.first as? AVCaptureDeviceInput)?.device
            var enabled = false
            if let device, self.session.isRunning, device.hasTorch, device.isTorchAvailable {
                do {
                    try device.lockForConfiguration()
                    defer { device.unlockForConfiguration() }
                    device.torchMode = requested ? .on : .off
                    enabled = device.torchMode == .on
                } catch { enabled = device.torchMode == .on }
            }
            DispatchQueue.main.async { [weak self] in
                guard let self, !self.delivered, self.viewIfLoaded?.window != nil else { return }
                self.torchRequested = enabled
                self.torchButton.setImage(UIImage(systemName: enabled ? "flashlight.on.fill" : "flashlight.off.fill"), for: .normal)
                self.torchButton.accessibilityLabel = enabled ? "关闭手电筒" : "打开手电筒"
                self.torchButton.isEnabled = device?.hasTorch == true
            }
        }
    }
    func stop() {
        torchRequested = false
        torchButton.isEnabled = false
        torchButton.setImage(UIImage(systemName: "flashlight.off.fill"), for: .normal)
        torchButton.accessibilityLabel = "打开手电筒"
        queue.async { [session] in
            if let device = (session.inputs.first as? AVCaptureDeviceInput)?.device, device.hasTorch, device.torchMode == .on {
                if (try? device.lockForConfiguration()) != nil { device.torchMode = .off; device.unlockForConfiguration() }
            }
            if session.isRunning { session.stopRunning() }
        }
    }
    private func fail() { DispatchQueue.main.async { [weak self] in guard let self = self, !self.delivered else { return }; self.delivered = true; self.onError("相机启动失败，请重试或从相册识别。") } }
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard !delivered, let code = (metadataObjects.first as? AVMetadataMachineReadableCodeObject)?.stringValue, !code.isEmpty else { return }
        delivered = true; stop(); UISelectionFeedbackGenerator().selectionChanged(); onCode(code)
    }
}
