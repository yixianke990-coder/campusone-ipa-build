import SwiftUI
import WebKit

extension Service {
    var nativeProvider: NativeProvider? {
        switch storeID {
        case "1490809012": return .life798
        case "1152127141": return .xiqueer
        case "1142157881": return .ujing
        case "1264484428": return .quzhi
        default: return nil
        }
    }
}

@MainActor struct AccountAccessView: View {
    let service: Service
    var body: some View {
        if let provider = service.nativeProvider { NativeAccountsView(service: service, provider: provider) }
        else if !service.isBuiltIn { WebAccountsView(service: service) }
        else { CampusEmptyState("未配置原生适配器", systemImage: "lock.shield") }
    }
}

@MainActor struct NativeAccountsView: View {
    @EnvironmentObject private var store: CampusStore
    let service: Service
    let provider: NativeProvider
    @AppStorage("native.account.metadata.v1") private var metadata = Data()
    @AppStorage("native.account.selection.v1") private var selection = Data()
    @State private var alias = ""
    @State private var pending: NativeAccount?
    @State private var legacyPending: WebAccount?
    @State private var clearing = false
    @State private var message = ""
    private var accounts: [NativeAccount] { (try? JSONDecoder().decode([NativeAccount].self, from: metadata)) ?? [] }
    private var selected: [String: UUID] { (try? JSONDecoder().decode([String: UUID].self, from: selection)) ?? [:] }
    var body: some View {
        List {
            Section {
                CampusProviderHeader(service: service, subtitle: provider.loginMethod, status: NativeRegistry.service(for: provider).isAuthorized ? "可发起认证" : "在线登录暂不可用")
            }
            Section("账号登录") {
                let adapter = NativeRegistry.service(for: provider)
                if adapter.isAuthorized, let account = accounts.first(where: { $0.provider == provider && selected[provider.rawValue] == $0.id }) {
                    NativeLoginForm(account: account, adapter: adapter).id(account.id)
                } else if adapter.isAuthorized {
                    Label("请先添加或选择账号", systemImage: "person.crop.circle.badge.plus")
                } else {
                    Label("暂不能在线登录", systemImage: "exclamationmark.circle")
                        .font(.headline)
                    Text("当前版本没有可用的在线认证连接。不会收集你的账号或验证码。")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }
            Section {
                DisclosureGroup("接入诊断") {
                    Text(provider.blocker).font(.footnote).foregroundStyle(.secondary)
                    Phase6StatusRows(provider: provider)
                }
            }
            Section {
                ForEach(accounts.filter { $0.provider == provider }) { account in
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text(account.alias).font(.headline); Spacer()
                            if selected[provider.rawValue] == account.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(service.color).accessibilityLabel("当前配置") }
                        }
                        Text("未登录 · 仅本地备注").font(.caption).foregroundStyle(.secondary)
                        Button("选择此账号配置") { choose(account) }.disabled(selected[provider.rawValue] == account.id)
                        Button("删除本地配置", role: .destructive) { pending = account }
                    }
                }
                TextField("账号备注，例如 主账号", text: $alias).autocorrectionDisabled()
                Button("添加独立账号配置", campusIcon: "person.badge.plus") { add() }.disabled(!NativeAccount.validAlias(alias))
            } header: { Text("本地账号配置") }  footer: { Text("备注不是账号密码。各平台及各账号使用不同的本地标识与 Keychain 存储命名空间；当前没有真实登录会话。") }
            let legacy = store.webAccounts.filter { $0.serviceID == service.id }
            if !legacy.isEmpty {
                Section("旧版网页会话清理") {
                    ForEach(legacy) { profile in
                        Button("清除旧网页配置：\(profile.name)", role: .destructive) { legacyPending = profile }.disabled(clearing)
                    }
                    Text("旧版网页登录入口已停用，可主动清除对应网站数据。不会影响自定义网页服务。") .font(.footnote).foregroundStyle(.secondary)
                }
            }
            if clearing { ProgressView("正在清理…") }
            if !message.isEmpty { Text(message).font(.footnote).foregroundStyle(.secondary) }
        }.listStyle(.insetGrouped).navigationTitle("账号登录")
         .navigationBarTitleDisplayMode(.inline)
         .confirmationDialog("删除本地账号配置？", isPresented: Binding(get: { pending != nil }, set: { if !$0 { pending = nil } }), titleVisibility: .visible) {
             Button("删除", role: .destructive) { if let account = pending { remove(account) }; pending = nil }
         } message: { Text("清除本地凭证及备注，不会注销服务商账号。") }
         .confirmationDialog("清除旧网页登录数据？", isPresented: Binding(get: { legacyPending != nil }, set: { if !$0 { legacyPending = nil } }), titleVisibility: .visible) {
             Button("确认清除", role: .destructive) {
                 guard let profile = legacyPending else { return }; legacyPending = nil; clearing = true
                 Task { @MainActor in
                     defer { clearing = false }
                     do {
                         if #available(iOS 17.0, *) { try await WKWebsiteDataStore.remove(forIdentifier: profile.id) }
                         store.webAccounts.removeAll { $0.id == profile.id }; message = "旧版网页配置已清除。"
                     } catch { message = "清除失败，请重试。" }
                 }
             }
         } message: { Text("不会删除原平台账号。") }
    }
    private func add() {
        guard NativeAccount.validAlias(alias) else { return }
        let account = NativeAccount(provider: provider, alias: alias.trimmingCharacters(in: .whitespacesAndNewlines))
        if let data = try? JSONEncoder().encode(accounts + [account]) { metadata = data; choose(account); alias = "" }
        else { message = "保存账号配置失败。" }
    }
    private func choose(_ account: NativeAccount) {
        var values = selected; values[provider.rawValue] = account.id
        if let data = try? JSONEncoder().encode(values) { selection = data }
    }
    private func remove(_ account: NativeAccount) {
        do {
            try KeychainStore().remove(account: account)
            metadata = try JSONEncoder().encode(accounts.filter { $0.id != account.id })
            if selected[provider.rawValue] == account.id {
                var values = selected; values.removeValue(forKey: provider.rawValue); selection = try JSONEncoder().encode(values)
            }
            message = "本地账号配置已删除。"
        } catch { message = "安全存储清理失败，账号配置未确认删除。" }
    }
}

// Only instantiated for an available adapter. Challenge contents and timing are
// adapter-specific; this generic input does not implement a provider captcha SDK.
@MainActor private struct NativeLoginForm: View {
    let account: NativeAccount
    let adapter: any PlatformService
    @State private var school = ""
    @State private var username = ""
    @State private var password = ""
    @State private var phone = ""
    @State private var response = ""
    @State private var reference: String?
    @State private var busy = false
    @State private var authenticated = false
    @State private var status = ""
    @State private var work: Task<Void, Never>?
    var body: some View {
        Group {
            if authenticated {
                Label("会话已确认", systemImage: "checkmark.circle")
            } else if reference != nil {
                TextField("输入平台要求的验证码", text: $response).textContentType(.oneTimeCode).autocorrectionDisabled()
                Button("验证并登录") { submit() }.disabled(busy || response.isEmpty)
                Button("取消本次验证") { reference = nil; response = ""; status = "" }.disabled(busy)
            } else {
                if account.provider == .xiqueer {
                    TextField("学校标识", text: $school).autocorrectionDisabled()
                    TextField("学号", text: $username).textContentType(.username).autocorrectionDisabled()
                    SecureField("密码", text: $password).textContentType(.password)
                } else {
                    TextField("手机号码", text: $phone).keyboardType(.phonePad).textContentType(.telephoneNumber)
                }
                Button(account.provider == .xiqueer ? "登录" : "发起验证码验证") { submit() }
                    .disabled(busy || (account.provider == .xiqueer ? school.isEmpty || username.isEmpty || password.isEmpty : phone.isEmpty))
            }
            if busy { ProgressView("正在验证…") }
            if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(.secondary) }
        }.onDisappear { work?.cancel(); password = ""; response = ""; reference = nil; phone = ""; username = ""; school = "" }
    }
    private func submit() {
        guard !busy else { return }
        busy = true; status = ""
        let flow = NativeLoginFlow(service: adapter, account: account)
        let currentReference = reference
        let currentResponse = response
        let input: NativeLoginInput = account.provider == .xiqueer ? .schoolAccount(schoolReference: school, account: username, password: password) : .phoneChallenge(phone: phone)
        password = ""; response = ""
        work = Task { @MainActor in
            defer { busy = false; work = nil }
            do {
                let result: NativeLoginOutcome
                if let currentReference { result = try await flow.complete(reference: currentReference, response: currentResponse) }
                else { result = try await flow.begin(input) }
                try Task.checkCancellation()
                switch result {
                case .challengeRequired(let next): reference = next; status = "请完成平台验证。"
                case .authenticated: reference = nil; authenticated = true; status = ""
                }
            } catch is CancellationError {} catch {
                if !Task.isCancelled { status = "验证未完成，请稍后重试。" }
            }
        }
    }
}
