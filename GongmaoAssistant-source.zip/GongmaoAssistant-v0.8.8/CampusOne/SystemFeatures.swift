import SwiftUI
import LocalAuthentication
import WidgetKit
import ActivityKit
import AppIntents

@available(iOS 16.0, *)
struct CampusShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: OpenCampusSchedule(), phrases: ["查看\(.applicationName)课表"], shortTitle: "查看课表", systemImageName: "calendar")
        AppShortcut(intent: OpenCampusScanner(), phrases: ["打开\(.applicationName)扫一扫"], shortTitle: "校园扫一扫", systemImageName: "qrcode.viewfinder")
    }
}

@MainActor enum CampusWidgetBridge {
    static func publish(_ store: CampusStore) {
        guard let shared = CampusShared.defaults else { return }
        guard UserDefaults.standard.bool(forKey: "widgetShare") && !UserDefaults.standard.bool(forKey: "appLock") else {
            shared.removeObject(forKey: CampusShared.snapshotKey); WidgetCenter.shared.reloadAllTimelines(); return
        }
        let cal = Calendar.current, now = Date()
        var lessons: [CampusWidgetLesson] = []
        for offset in 0..<7 {
            guard let day = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: now)) else { continue }
            for course in store.displayedCourses where course.weekday == Course.today(day) {
                if store.term.name.isEmpty { guard course.detail?.term.isEmpty ?? true else { continue } }
                else { guard let week = store.term.currentWeek(on: day), store.term.includes(course, week: week) else { continue } }
                guard (0..<1440).contains(course.start), course.end > course.start, course.end <= 1440,
                      let start = cal.date(byAdding: .minute, value: course.start, to: day), let end = cal.date(byAdding: .minute, value: course.end, to: day), end > now else { continue }
                lessons.append(.init(title: String(course.name.prefix(100)), start: start, end: end))
            }
        }
        let snap = CampusWidgetSnapshot(generated: now, lessons: Array(lessons.sorted { $0.start < $1.start }.prefix(100)))
        if let data = try? JSONEncoder().encode(snap) { shared.set(data, forKey: CampusShared.snapshotKey); WidgetCenter.shared.reloadAllTimelines() }
    }
}

@MainActor enum CampusLiveTimer {
    static func begin(_ timer: LocalTimer) -> String? {
        guard #available(iOS 16.1, *) else { return "此系统不支持实时活动。" }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return "系统未启用实时活动。" }
        let attributes = CampusTimerAttributes(timerID: timer.id)
        let state = CampusTimerAttributes.ContentState(started: Date(), end: timer.end, finished: false)
        do {
            if #available(iOS 16.2, *) { _ = try Activity.request(attributes: attributes, content: .init(state: state, staleDate: timer.end), pushType: nil) }
            else { _ = try Activity.request(attributes: attributes, contentState: state, pushType: nil) }
            return nil
        } catch { return "实时活动启动失败，本地计时仍可使用。" }
    }
    static func finish(_ id: UUID) async {
        guard #available(iOS 16.1, *) else { return }
        for activity in Activity<CampusTimerAttributes>.activities where activity.attributes.timerID == id {
            if #available(iOS 16.2, *) { var state = activity.content.state; state.finished = true; await activity.end(.init(state: state, staleDate: nil), dismissalPolicy: .immediate) }
            else { var state = activity.contentState; state.finished = true; await activity.end(using: state, dismissalPolicy: .immediate) }
        }
    }
    static func reconcile(_ timers: [LocalTimer]) async {
        guard #available(iOS 16.1, *) else { return }
        for activity in Activity<CampusTimerAttributes>.activities {
            if !timers.contains(where: { $0.id == activity.attributes.timerID && $0.end > Date() }) { await finish(activity.attributes.timerID) }
        }
    }
}

struct CampusPrivacyGate<Content: View>: View {
    @AppStorage("appLock") private var enabled = false
    @Environment(\.scenePhase) private var phase
    @State private var unlocked = false
    @State private var authenticating = false
    @State private var error = ""
    @State private var epoch = UUID()
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        ZStack {
            if !enabled || (unlocked && phase == .active) { content }
            if enabled && (!unlocked || phase != .active) {
                Color(uiColor: .systemBackground).ignoresSafeArea()
                VStack(spacing: 20) {
                    FeatureIcon(symbol: "lock.shield", size: 84)
                    Text("工贸助手已锁定").font(.title2.bold())
                    Text("使用设备认证保护课表、账号和本地记录。").font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    Button("解锁", action: authenticate).buttonStyle(.borderedProminent).disabled(authenticating || phase != .active)
                    if !error.isEmpty { Text(error).font(.footnote).foregroundStyle(.secondary) }
                }.padding(32)
            }
        }
        .onChange(of: phase) { value in if value == .background { epoch = UUID(); unlocked = false; authenticating = false } }
        .onChange(of: enabled) { value in unlocked = value; error = "" }
        .onOpenURL { url in if let route = CampusSystemRoute.parse(url) { CampusShared.request(route) } }
    }
    private func authenticate() {
        let context = LAContext(); var reason: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &reason) else { error = "设备认证不可用，请在系统设置中恢复设备密码。"; return }
        authenticating = true; error = ""; let attempt = epoch
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "解锁工贸助手") { success, _ in
            DispatchQueue.main.async { guard attempt == epoch else { return }; authenticating = false; unlocked = success; if !success { error = "认证未通过，请重试。" } }
        }
    }
}

struct CampusSystemSettings: View {
    @EnvironmentObject private var store: CampusStore
    @AppStorage("appLock") private var locked = false
    @AppStorage("widgetShare") private var sharing = false
    @State private var error = ""
    var body: some View {
        List {
            Section("设备认证") {
                Toggle("Face ID / Touch ID / 设备密码", isOn: Binding(get: { locked }, set: { changeLock($0) }))
                Text("启用后，应用重新进入前台需要认证。不会改变第三方平台的登录状态。未认证时隐藏内容。") .font(.footnote).foregroundStyle(.secondary)
                if !error.isEmpty { Text(error).font(.footnote).foregroundStyle(.red) }
            }
            Section("桌面与锁屏") {
                Toggle("允许小组件显示课程名称", isOn: $sharing).disabled(locked || CampusShared.defaults == nil)
                if CampusShared.defaults == nil { Text("共享容器未配置：请在编译工具中设置 App Group。") .font(.footnote).foregroundStyle(.secondary) }
                Text("默认不共享课程。启用应用锁会清除小组件课表缓存。小组件仅显示已保存的课表，不会自动登录喜鹊儿。") .font(.footnote).foregroundStyle(.secondary)
                Button("更新小组件") { CampusWidgetBridge.publish(store) }
            }
            Section("系统快捷入口") {
                Text("iOS 16+：在快捷指令中搜索工贸助手。iOS 18+：在控制中心添加校园扫一扫或查看课表。iOS 16.1+：在本地计时页面选择显示实时活动。") .font(.subheadline)
            }
        }.navigationTitle("安全与系统集成").onChange(of: sharing) { _ in CampusWidgetBridge.publish(store) }
    }
    private func changeLock(_ value: Bool) {
        let context = LAContext(); var reason: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &reason) else { error = "请先在系统设置启用设备密码。"; return }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: value ? "启用工贸助手应用锁" : "关闭工贸助手应用锁") { ok, _ in
            DispatchQueue.main.async { if ok { locked = value; if value { sharing = false }; CampusWidgetBridge.publish(store); error = "" } else { error = "认证未通过，未更改设置。" } }
        }
    }
}
