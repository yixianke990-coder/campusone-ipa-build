import SwiftUI
import UIKit

@main struct CampusOneApp: App {
    @StateObject private var store = CampusStore()
    @AppStorage("appearance") private var appearance = "system"
    var body: some Scene {
        WindowGroup { CampusPrivacyGate { RootView() }.environmentObject(store).tint(Color(uiColor: UIColor { traits in traits.userInterfaceStyle == .dark ? UIColor(red: 0.55, green: 0.74, blue: 0.99, alpha: 1) : UIColor(red: 0.10, green: 0.29, blue: 0.48, alpha: 1) })).preferredColorScheme(appearance == "light" ? .light : appearance == "dark" ? .dark : nil) }
    }
}

enum MainTab: Hashable { case home, courses, services, settings, search }

struct RootView: View {
    @State private var tab: MainTab = .home
    @State private var systemScan = false
    @Environment(\.scenePhase) private var phase
    @EnvironmentObject private var store: CampusStore
    var body: some View {
        Group {
            if #available(iOS 26, *) { modernTabs.tabBarMinimizeBehavior(.onScrollDown) }
            else if #available(iOS 18, *) { modernTabs }
            else { legacyTabs }
        }
        .sheet(isPresented: $systemScan) { CampusNavigation { ScanView() } }
        .onReceive(NotificationCenter.default.publisher(for: CampusShared.routeNotification)) { _ in consumeRoute() }
        .onChange(of: phase) { value in if value == .active { consumeRoute(); CampusWidgetBridge.publish(store); Task { await CampusLiveTimer.reconcile(store.timers) } } }
        .onChange(of: store.courses) { _ in CampusWidgetBridge.publish(store); Task { await CampusCourseReminders.cancel() } }
        .onChange(of: store.onlineSnapshot) { _ in CampusWidgetBridge.publish(store); Task { await CampusCourseReminders.cancel() } }
        .onChange(of: store.term) { _ in CampusWidgetBridge.publish(store); Task { await CampusCourseReminders.cancel() } }
        .task { consumeRoute(); CampusWidgetBridge.publish(store); await CampusLiveTimer.reconcile(store.timers) }
        .alert("保存失败", isPresented: Binding(get: { store.storageError != nil }, set: { if !$0 { store.storageError = nil } })) {
            Button("确定", role: .cancel) { store.storageError = nil }
        } message: { Text(store.storageError ?? "") }
    }
    private func consumeRoute() { if let route = CampusShared.consume() { navigate(route) } }
    private func navigate(_ route: CampusSystemRoute) {
        switch route { case .home: tab = .home; case .courses: tab = .courses; case .services: tab = .services; case .settings: tab = .settings; case .scan: tab = .home; systemScan = true }
    }
    @available(iOS 18.0, *)
    private var modernTabs: some View {
        TabView(selection: $tab) {
            Tab("首页", systemImage: "house", value: MainTab.home) { CampusNavigation { HomeView(tab: $tab) } }
            Tab("课表", systemImage: "calendar", value: MainTab.courses) { CampusNavigation { CoursesView() } }
            Tab("服务", systemImage: "square.grid.2x2", value: MainTab.services) { CampusNavigation { ServicesView() } }
            Tab("设置", systemImage: "gearshape", value: MainTab.settings) { CampusNavigation { SettingsView() } }
            Tab(value: MainTab.search, role: .search) { CampusNavigation { SearchView() } }
        }
    }
    private var legacyTabs: some View {
        TabView(selection: $tab) {
            CampusNavigation { HomeView(tab: $tab) }.tabItem { Label("首页", systemImage: "house") }.tag(MainTab.home)
            CampusNavigation { CoursesView() }.tabItem { Label("课表", systemImage: "calendar") }.tag(MainTab.courses)
            CampusNavigation { ServicesView() }.tabItem { Label("服务", systemImage: "square.grid.2x2") }.tag(MainTab.services)
            CampusNavigation { SettingsView() }.tabItem { Label("设置", systemImage: "gearshape") }.tag(MainTab.settings)
            CampusNavigation { SearchView() }.tabItem { Label("搜索", systemImage: "magnifyingglass") }.tag(MainTab.search)
        }
    }

}

extension Service {
    var color: Color {
        switch tint { case "blue": .blue; case "orange": .orange; case "indigo": .indigo; case "teal": .teal; default: .green }
    }
}
struct ServiceIcon: View {
    let service: Service
    var size: CGFloat = 50
    var body: some View {
        if let name = service.brandAssetName, let image = UIImage(named: name) {
            Image(uiImage: image).resizable().scaledToFit()
                .frame(width: size, height: size)
                .clipShape(RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
                .accessibilityHidden(true)
        } else {
            FeatureIcon(symbol: service.symbol, color: service.color, size: size)
        }
    }
}
struct ServiceRow: View {
    let service: Service
    var body: some View {
        HStack(spacing: 12) {
            ServiceIcon(service: service)
            VStack(alignment: .leading, spacing: 4) {
                Text(service.name).font(.headline)
                Text(service.category).font(.subheadline).foregroundStyle(.secondary)
                if service.isBuiltIn { CampusStatusLabel(text: "业务待接入", symbol: "clock", color: .secondary) }
            }
            Spacer()
        }
    }
}
struct HomeView: View {
    @EnvironmentObject private var store: CampusStore
    @Binding var tab: MainTab
    @Environment(\.dynamicTypeSize) private var typeSize
    @State private var scan = false
    var today: [Course] { store.displayedCourses.filter { course in
        guard course.weekday == Course.today() else { return false }
        if store.term.name.isEmpty { return course.detail?.term.isEmpty ?? true }
        guard let week = store.term.currentWeek() else { return false }
        return store.term.includes(course, week: week)
    }.sorted { $0.start < $1.start } }
    private var visibleServices: [Service] { store.services.filter { $0.enabled && $0.showOnHome } }
    private var columns: [GridItem] { Array(repeating: GridItem(.flexible(), spacing: 12), count: typeSize.isAccessibilitySize ? 1 : 2) }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                overview
                quickActions
                courseCard
                CampusSectionHeading(title: "校园服务", action: "管理") { tab = .services }
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(visibleServices) { service in
                        NavigationLink { ServiceDetail(id: service.id) } label: {
                            VStack(alignment: .leading, spacing: 10) {
                                HStack { ServiceIcon(service: service, size: 48); Spacer(minLength: 0); Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary) }
                                Text(service.name).font(.headline).foregroundStyle(.primary)
                                Text(service.category).font(.subheadline).foregroundStyle(.secondary)
                                if service.isBuiltIn { CampusStatusLabel(text: "业务待接入", symbol: "clock", color: .secondary) }
                                else { CampusStatusLabel(text: "网页服务", symbol: "globe", color: .secondary) }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding(15).campusCard(radius: 22)
                        }.buttonStyle(.plain)
                    }
                    Button { tab = .services } label: {
                        VStack(alignment: .leading, spacing: 10) {
                            FeatureIcon(symbol: "plus", color: .secondary, size: 48)
                            Text("添加服务").font(.headline).foregroundStyle(.primary)
                            Text("自定义网页").font(.subheadline).foregroundStyle(.secondary)
                            CampusStatusLabel(text: "管理入口", symbol: "slider.horizontal.3", color: .secondary)
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(15).campusCard(radius: 22)
                    }.buttonStyle(.plain)
                }
            }.padding(.horizontal, 18).padding(.vertical, 14).frame(maxWidth: 760)
                .frame(maxWidth: .infinity)
        }.background(Color(uiColor: .systemGroupedBackground)).navigationTitle("工贸助手")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $scan) { CampusNavigation { ScanView() } }
    }
    private var overview: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 6) {
                    Label("工贸 · 校园生活", systemImage: "graduationcap.fill")
                        .font(.footnote.weight(.semibold)).foregroundStyle(CampusDesign.gold)
                    Text("今日校园").font(.largeTitle.bold()).foregroundStyle(.white)
                    Text(Date.now.formatted(.dateTime.month().day().weekday(.wide)))
                        .font(.subheadline).foregroundStyle(.white.opacity(0.9))
                }
                Spacer(minLength: 8)
                Image(systemName: "graduationcap.fill").font(.system(size: 36, weight: .light)).foregroundStyle(CampusDesign.gold).accessibilityHidden(true)
            }
            Divider().overlay(.white.opacity(0.20))
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("今日课程").font(.caption).foregroundStyle(.white.opacity(0.85))
                    Text(store.displayedCourses.isEmpty ? "未导入" : "\(today.count) 节").font(.title2.bold().monospacedDigit()).foregroundStyle(.white)
                }.frame(maxWidth: .infinity, alignment: .leading)
                VStack(alignment: .leading, spacing: 4) {
                    Text("首页服务").font(.caption).foregroundStyle(.white.opacity(0.85))
                    Text("\(visibleServices.count) 项").font(.title2.bold().monospacedDigit()).foregroundStyle(.white)
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
        }.padding(20).background {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(LinearGradient(colors: [CampusDesign.navy, CampusDesign.blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(alignment: .topTrailing) {
                    Circle().strokeBorder(.white.opacity(0.08), lineWidth: 24).frame(width: 220, height: 220).offset(x: 90, y: -95)
                }.clipped()
        }.clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .accessibilityElement(children: .combine)
    }
    private var quickActions: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: typeSize.isAccessibilitySize ? 1 : 3), spacing: 10) {
            Button { scan = true } label: { CampusQuickAction(title: "扫一扫", symbol: "qrcode.viewfinder", color: .accentColor, prominent: true) }.buttonStyle(.plain)
            Button { tab = .courses } label: { CampusQuickAction(title: "课表", symbol: "calendar", color: .blue) }.buttonStyle(.plain)
            Button { tab = .search } label: { CampusQuickAction(title: "搜索", symbol: "magnifyingglass", color: .indigo) }.buttonStyle(.plain)
        }
    }
    private var courseCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            CampusSectionHeading(title: "今日课程", action: "完整课表") { tab = .courses }
            if today.isEmpty {
                CampusEmptyState(store.displayedCourses.isEmpty ? "尚未导入课表" : "今日暂无课程", systemImage: "calendar", description: Text(store.displayedCourses.isEmpty ? "同步或添加课程后在这里查看。" : "请以学校最新安排为准。"))
            } else {
                ForEach(today) { course in
                    NavigationLink { CourseInspection(course: course) } label: { CourseRow(course: course) }.buttonStyle(.plain)
                    if course.id != today.last?.id { Divider() }
                }
            }
            if let snapshot = store.onlineSnapshot { CampusStatusLabel(text: "缓存更新 " + snapshot.syncedAt.formatted(date: .abbreviated, time: .shortened), symbol: "clock", color: .secondary) }
            else { CampusStatusLabel(text: "本地课表 · 未连接在线数据", symbol: "internaldrive", color: .secondary) }
        }.padding(16).campusCard(radius: 24)
    }
}

struct SearchView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var query = ""
    private var keyword: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var services: [Service] { store.services.filter { $0.enabled && (keyword.isEmpty || ($0.name + $0.category).localizedCaseInsensitiveContains(keyword)) } }
    private var courses: [Course] { store.displayedCourses.filter { !keyword.isEmpty && ($0.name + $0.location + ($0.detail?.teacher ?? "")).localizedCaseInsensitiveContains(keyword) } }
    private var features: [(Service, String)] {
        guard !keyword.isEmpty else { return [] }
        return store.services.filter(\.enabled).flatMap { service in
            let groups = service.storeID == "1152127141" ? AcademicCenter.groups : (ProviderEvidence.forService(service)?.groups ?? [])
            return groups.flatMap { $0.1 }.filter { $0.localizedCaseInsensitiveContains(keyword) }.map { (service, $0) }
        }
    }
    var body: some View {
        List {
            if keyword.isEmpty { Section { Label("搜索课程、老师、教室或服务功能", systemImage: "magnifyingglass").foregroundStyle(.secondary) } }
            if !services.isEmpty { Section("服务") { ForEach(services) { service in NavigationLink { ServiceDetail(id: service.id) } label: { ServiceRow(service: service) } } } }
            if !courses.isEmpty { Section("课程") { ForEach(courses) { course in NavigationLink { CourseInspection(course: course) } label: { CourseRow(course: course) } } } }
            if !features.isEmpty { Section("平台功能") { ForEach(features.indices, id: \.self) { index in
                let item = features[index]
                NavigationLink { OfficialFeature(service: item.0, title: item.1) } label: { FeatureRow(title: item.1, subtitle: item.0.name + " · 原生待授权", color: item.0.color) }
            } } }
            if !keyword.isEmpty && services.isEmpty && courses.isEmpty && features.isEmpty { CampusEmptyState.search(text: keyword) }
        }.listStyle(.insetGrouped).navigationTitle("搜索").searchable(text: $query, prompt: "搜索课程、教师、服务")
    }
}

// Native SF Symbols in a consistent, accessible two-tone icon tile.
struct FeatureIcon: View {
    let symbol: String
    var color: Color = .accentColor
    var size: CGFloat = 42
    var body: some View {
        Image(systemName: UIImage(systemName: symbol) == nil ? "doc.text" : symbol).font(.system(size: size * 0.46, weight: .semibold))
            .symbolRenderingMode(.hierarchical).foregroundStyle(color)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: [color.opacity(0.17), color.opacity(0.07)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: size * 0.27, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: size * 0.29, style: .continuous).strokeBorder(color.opacity(0.10), lineWidth: 1))
            .accessibilityHidden(true)
    }
}
struct FeatureRow: View {
    let title: String
    var subtitle: String = ""
    var color: Color = .accentColor
    var body: some View {
        HStack(spacing: 12) {
            FeatureIcon(symbol: FeatureSymbols.icon(title), color: color)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.body.weight(.medium))
                if !subtitle.isEmpty { Text(subtitle).font(.caption).foregroundStyle(.secondary) }
            }
        }.padding(.vertical, 3)
    }
}


// Compatible navigation, value rows and empty states shared by all screens.
struct CampusNavigation<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        if #available(iOS 16, *) { NavigationStack { content } }
        else { NavigationView { content }.navigationViewStyle(.stack) }
    }
}
struct CampusValueRow: View {
    let title: String; let value: String
    init(_ title: String, value: String) { self.title = title; self.value = value }
    var body: some View {
        HStack(alignment: .firstTextBaseline) { Text(title); Spacer(minLength: 12); Text(value).foregroundStyle(.secondary).multilineTextAlignment(.trailing) }.accessibilityElement(children: .combine)
    }
}
struct CampusEmptyState: View {
    let title: String; let systemImage: String; var description: Text?
    init(_ title: String, systemImage: String, description: Text? = nil) { self.title = title; self.systemImage = systemImage; self.description = description }
    static func search(text: String) -> Self { .init("没有搜索结果", systemImage: "magnifyingglass", description: Text("试试其他课程、教师或服务名称。")) }
    var body: some View {
        VStack(spacing: 10) {
            FeatureIcon(symbol: systemImage, color: .accentColor, size: 52)
            Text(title).font(.headline)
            if let description = description { description.font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center) }
        }.frame(maxWidth: .infinity).padding(.vertical, 22).accessibilityElement(children: .combine)
    }
}
struct CampusMultiline: View {
    let title: String; @Binding var text: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            TextEditor(text: $text).frame(minHeight: 72).accessibilityLabel(title)
        }
    }
}
// Shared visual system. Native tab bar and navigation remain system-owned.
enum CampusDesign {
    static let navy = Color(red: 0.08, green: 0.19, blue: 0.34)
    static let blue = Color(red: 0.16, green: 0.34, blue: 0.55)
    static let gold = Color(red: 0.96, green: 0.84, blue: 0.61)
}
extension View {
    func campusCard(radius: CGFloat = 22) -> some View {
        self.background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).strokeBorder(Color.primary.opacity(0.055), lineWidth: 1))
    }
}
struct CampusStatusLabel: View {
    let text: String; let symbol: String; var color: Color = .secondary
    var body: some View {
        Label(text, systemImage: symbol).font(.caption.weight(.medium)).foregroundStyle(color)
            .fixedSize(horizontal: false, vertical: true)
    }
}
struct CampusSectionHeading: View {
    let title: String; let action: String; let onAction: () -> Void
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.title3.bold()).accessibilityAddTraits(.isHeader)
            Spacer(minLength: 8)
            Button(action: onAction) { Text(action).font(.subheadline.weight(.medium)) }.buttonStyle(.borderless)
        }
    }
}
struct CampusProviderHeader: View {
    let service: Service; let subtitle: String; let status: String
    var body: some View {
        HStack(alignment: .center, spacing: 14) {
            ServiceIcon(service: service, size: 64)
            VStack(alignment: .leading, spacing: 6) {
                Text(service.name).font(.title2.bold())
                Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
                CampusStatusLabel(text: status, symbol: service.isBuiltIn ? "clock" : "globe")
            }
            Spacer(minLength: 0)
        }.padding(.vertical, 10).accessibilityElement(children: .combine)
    }
}
struct CampusQuickAction: View {
    let title: String; let symbol: String; let color: Color; var prominent = false
    var body: some View {
        VStack(spacing: 8) {
            if prominent {
                Image(systemName: symbol).font(.system(size: 24, weight: .semibold)).foregroundStyle(.white).frame(width: 44, height: 44).accessibilityHidden(true)
            } else { FeatureIcon(symbol: symbol, color: color, size: 44) }
            Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(prominent ? Color.white : Color.primary)
        }.frame(maxWidth: .infinity).padding(.vertical, 14)
            .background {
                if prominent { RoundedRectangle(cornerRadius: 20, style: .continuous).fill(LinearGradient(colors: [CampusDesign.navy, CampusDesign.blue], startPoint: .topLeading, endPoint: .bottomTrailing)) }
                else { RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color(uiColor: .secondarySystemGroupedBackground)) }
            }
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(Color.primary.opacity(0.055), lineWidth: 1))
    }
}
extension Button where Label == SwiftUI.Label<Text, Image> {
    init(_ title: String, campusIcon: String, action: @escaping () -> Void) {
        self.init(action: action) { SwiftUI.Label(title, systemImage: campusIcon) }
    }
}
