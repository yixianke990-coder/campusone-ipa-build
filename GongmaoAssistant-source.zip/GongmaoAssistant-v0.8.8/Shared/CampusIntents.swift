import Foundation
import AppIntents

@available(iOS 16.0, *)
struct OpenCampusSchedule: AppIntent {
    static var title: LocalizedStringResource = "查看课表"
    static var description = IntentDescription("打开工贸助手的本地课表。")
    static var openAppWhenRun = true
    @MainActor func perform() async throws -> some IntentResult { CampusShared.request(.courses); return .result() }
}
@available(iOS 16.0, *)
struct OpenCampusScanner: AppIntent {
    static var title: LocalizedStringResource = "校园扫一扫"
    static var description = IntentDescription("打开扫码页，由用户确认服务商；不启动设备。")
    static var openAppWhenRun = true
    @MainActor func perform() async throws -> some IntentResult { CampusShared.request(.scan); return .result() }
}
