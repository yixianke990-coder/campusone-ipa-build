import Foundation

// Only user-approved, local schedule summaries are shared with the extension.
struct CampusWidgetLesson: Codable, Equatable {
    let title: String
    let start: Date
    let end: Date
}
struct CampusWidgetSnapshot: Codable, Equatable {
    let generated: Date
    let lessons: [CampusWidgetLesson]
    func upcoming(at date: Date) -> [CampusWidgetLesson] {
        let age = date.timeIntervalSince(generated)
        guard age >= 0, age < 8 * 86400 else { return [] }
        return lessons.filter { $0.end > date }.sorted { $0.start < $1.start }
    }
}
enum CampusSystemRoute: String, CaseIterable {
    case home, courses, scan, services, settings
    static func parse(_ url: URL) -> Self? {
        guard url.scheme == "gongmaoassistant", url.path.isEmpty || url.path == "/", url.query == nil, url.fragment == nil, url.user == nil, url.password == nil, url.port == nil else { return nil }
        return url.host.flatMap(Self.init(rawValue:))
    }
    var url: URL { URL(string: "gongmaoassistant://" + rawValue)! }
}
enum CampusShared {
    static var defaults: UserDefaults? {
        #if os(iOS)
        guard let group = Bundle.main.object(forInfoDictionaryKey: "CampusAppGroup") as? String, !group.isEmpty,
              FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) != nil else { return nil }
        return UserDefaults(suiteName: group)
        #else
        return nil
        #endif
    }
    static let snapshotKey = "widget.snapshot.v1"
    static let commandKey = "widget.route.v1"
    static let routeNotification = Notification.Name("CampusRouteRequested")
    static func snapshot() -> CampusWidgetSnapshot? {
        defaults?.data(forKey: snapshotKey).flatMap { try? JSONDecoder().decode(CampusWidgetSnapshot.self, from: $0) }
    }
    static func request(_ route: CampusSystemRoute) {
        (defaults ?? .standard).set(route.rawValue, forKey: commandKey)
        NotificationCenter.default.post(name: routeNotification, object: nil)
    }
    static func consume() -> CampusSystemRoute? {
        let d = defaults ?? .standard
        let result = d.string(forKey: commandKey).flatMap(CampusSystemRoute.init(rawValue:))
        d.removeObject(forKey: commandKey)
        return result
    }
}
#if canImport(ActivityKit)
import ActivityKit
@available(iOS 16.1, *)
struct CampusTimerAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable { var started: Date; var end: Date; var finished: Bool }
    var timerID: UUID
}
#endif
