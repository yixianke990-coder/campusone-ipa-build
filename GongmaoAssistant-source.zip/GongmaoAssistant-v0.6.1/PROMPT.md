# Muse / Xcode 交接
保留工贸助手 v0.5.0 原生 iOS UI（非 Material），使用 Xcode 26 SDK，iOS 18+，保留四平台及自定义网页。检查真实编译、权限、签名和真机。参见 README.md 与 Documentation/APK_REVIEW.md。不得把静态报告里的路径、Android scheme 或协议线索当成可用接口；不模拟真实登录、余额、订单、设备状态。真实业务接入必须使用服务商授权文档或 SDK。
