import SwiftUI
import UserNotifications

struct ProviderTools: View {
    let service: Service
    var body: some View {
        Section("本地辅助功能") {
            if service.storeID != "1152127141" {
                NavigationLink { DeviceList(service: service) } label: { Label("常用设备", systemImage: "star") }
                NavigationLink { ExpensesView(service: service) } label: { Label("消费记录与统计", systemImage: "chart.bar") }
                NavigationLink { TimerList(service: service) } label: { Label("使用计时与提醒", systemImage: "timer") }
            } else {
                NavigationLink { CourseImportView() } label: { Label("批量导入本地课表", systemImage: "square.and.arrow.down") }
            }
            NavigationLink { AccountProfilesView(service: service) } label: { Label("多账号备注", systemImage: "person.2") }
        }
    }
}

struct DeviceList: View {
    @EnvironmentObject private var store: CampusStore
    let service: Service
    @State private var editing: FavoriteDevice?
    var items: [FavoriteDevice] { store.devices.filter { $0.serviceID == service.id } }
    var body: some View {
        List {
            Section {
                if items.isEmpty { ContentUnavailableView("暂无收藏", systemImage: "star", description: Text("添加常用设备名称与公开编号")) }
                ForEach(items) { item in
                    Button { editing = item } label: {
                        VStack(alignment: .leading) { Text(item.name); if !item.reference.isEmpty { Text(item.reference).font(.caption).foregroundStyle(.secondary) } }
                    }.buttonStyle(.plain)
                }.onDelete { offsets in
                    let ids = Set(offsets.map { items[$0].id }); store.devices.removeAll { ids.contains($0.id) }
                }.onMove { source, target in
                    var updated = items; updated.move(fromOffsets: source, toOffset: target)
                    store.devices = store.devices.filter { $0.serviceID != service.id } + updated
                }
            } footer: { Text("仅本机收藏，不代表设备已绑定、在线或可控制。不要保存登录码、支付码或私有设备令牌。") }
        }.navigationTitle("常用设备").toolbar { EditButton(); Button("添加", systemImage: "plus") { editing = FavoriteDevice(serviceID: service.id, name: "") } }
            .sheet(item: $editing) { item in NavigationStack { DeviceEditor(device: item) } }
    }
}
struct DeviceEditor: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State var device: FavoriteDevice
    var valid: Bool { !device.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && device.name.count <= 80 && LocalTools.publicReference(device.reference) }
    var body: some View {
        Form {
            TextField("设备别名", text: $device.name)
            TextField("公开设备编号（可选）", text: $device.reference).textInputAutocapitalization(.never).autocorrectionDisabled()
            Text("编号只接受英文字母、数字、短横线和下划线。不要填二维码原文。").font(.footnote)
        }.navigationTitle("编辑设备").toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("保存") {
                device.name = device.name.trimmingCharacters(in: .whitespacesAndNewlines)
                if let i = store.devices.firstIndex(where: { $0.id == device.id }) { store.devices[i] = device } else { store.devices.append(device) }
                dismiss()
            }.disabled(!valid) }
        }
    }
}

struct ExpensesView: View {
    @EnvironmentObject private var store: CampusStore
    let service: Service
    @State private var amount = ""
    @State private var note = ""
    @State private var date = Date()
    var entries: [ExpenseEntry] { store.expenses.filter { $0.serviceID == service.id }.sorted { $0.date > $1.date } }
    func total(_ component: Calendar.Component) -> String {
        guard let interval = Calendar.current.dateInterval(of: component, for: .now) else { return "—" }
        return LocalTools.currency(LocalTools.total(entries, serviceID: service.id, interval: interval))
    }
    var body: some View {
        List {
            Section("手动记录统计") {
                LabeledContent("今日", value: total(.day)); LabeledContent("本月", value: total(.month)); LabeledContent("本年", value: total(.year))
            }
            Section("新增记录") {
                TextField("金额（元）", text: $amount).keyboardType(.decimalPad)
                TextField("备注（可选）", text: $note)
                DatePicker("日期", selection: $date, in: ...Date(), displayedComponents: .date)
                Button("保存记录") {
                    guard let cents = LocalTools.cents(amount), note.count <= 120 else { return }
                    store.expenses.append(ExpenseEntry(serviceID: service.id, cents: cents, date: date, note: note)); amount = ""; note = ""
                }.disabled(LocalTools.cents(amount) == nil || note.count > 120)
            }
            Section {
                ForEach(entries) { entry in
                    HStack { VStack(alignment: .leading) { Text(entry.note.isEmpty ? "消费" : entry.note); Text(entry.date.formatted(date: .abbreviated, time: .omitted)).font(.caption).foregroundStyle(.secondary) }; Spacer(); Text(LocalTools.currency(entry.cents)).monospacedDigit() }
                }.onDelete { offsets in let ids = Set(offsets.map { entries[$0].id }); store.expenses.removeAll { ids.contains($0.id) } }
            } header: { Text("本地记录") } footer: { Text("仅统计手动录入的数据，不是官方账单、钱包余额或支付凭证。") }
        }.navigationTitle("消费统计")
    }
}

struct TimerList: View {
    @EnvironmentObject private var store: CampusStore
    let service: Service
    @State private var minutes = 30
    @State private var label = ""
    @State private var message = ""
    @State private var busy = false
    var body: some View {
        List {
            Section("新建本地提醒") {
                TextField("提醒名称（可选）", text: $label)
                Stepper("\(minutes) 分钟", value: $minutes, in: 1...180)
                Button("开始计时") { Task { await start() } }.disabled(busy || label.count > 80)
                if !message.isEmpty { Text(message).font(.footnote).foregroundStyle(.secondary) }
            }
            Section {
                ForEach(store.timers.filter { $0.serviceID == service.id }) { timer in
                    TimelineView(.periodic(from: .now, by: 1)) { context in
                        VStack(alignment: .leading) {
                            Text(timer.label)
                            let seconds = max(0, Int(ceil(timer.end.timeIntervalSince(context.date))))
                            Text(seconds == 0 ? "计时已结束" : String(format: "%02d:%02d", seconds / 60, seconds % 60)).monospacedDigit().foregroundStyle(.secondary)
                        }
                    }.swipeActions { Button("删除", role: .destructive) {
                        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [timer.notificationID]); UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [timer.notificationID]); store.timers.removeAll { $0.id == timer.id }
                    } }
                }
            } header: { Text("本地计时") } footer: { Text("手动启动的计时器，不连接设备，也不会自动停水、结算或确认洗衣结束。") }
        }.navigationTitle("计时与提醒")
    }
    @MainActor private func start() async {
        guard !busy else { return }; busy = true; defer { busy = false }
        let title = label.trimmingCharacters(in: .whitespacesAndNewlines)
        let timer = LocalTimer(serviceID: service.id, label: title.isEmpty ? service.name + "提醒" : title, end: Date().addingTimeInterval(Double(minutes * 60)))
        store.timers.append(timer)
        do {
            let center = UNUserNotificationCenter.current()
            guard try await center.requestAuthorization(options: [.alert, .sound]) else { message = "计时已开始；通知未授权。"; return }
            let content = UNMutableNotificationContent(); content.title = timer.label; content.body = "本地计时已结束，请在官方平台核实设备状态。"; content.sound = .default
            let delay = max(1, timer.end.timeIntervalSinceNow)
            try await center.add(UNNotificationRequest(identifier: timer.notificationID, content: content, trigger: UNTimeIntervalNotificationTrigger(timeInterval: delay, repeats: false)))
            message = "计时已开始，已安排本地通知。"
        } catch { message = "计时已开始，但通知安排失败。" }
    }
}

struct AccountProfilesView: View {
    @EnvironmentObject private var store: CampusStore
    let service: Service
    @State private var label = ""
    @State private var error = ""
    var body: some View {
        List {
            Section {
                ForEach(store.profiles.filter { $0.serviceID == service.id }) { profile in
                    Text(AccountVault.read(profile.id).isEmpty ? "未读取到备注" : AccountVault.read(profile.id))
                        .swipeActions { Button("删除", role: .destructive) {
                            if AccountVault.write("", id: profile.id) { store.profiles.removeAll { $0.id == profile.id } } else { error = "清除备注失败" }
                        } }
                }
                TextField("账号备注，例如手机尾号", text: $label)
                Button("新增备注") {
                    let profile = AccountProfile(serviceID: service.id)
                    if AccountVault.write(label.trimmingCharacters(in: .whitespacesAndNewlines), id: profile.id) { store.profiles.append(profile); label = ""; error = "" } else { error = "保存失败" }
                }.disabled(label.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || label.count > 80)
                if !error.isEmpty { Text(error).foregroundStyle(.red) }
            } header: { Text("独立账号备注") } footer: { Text("每个平台可保留多条 Keychain 备注，不能切换或建立真实第三方登录会话。不要输入密码或验证码。") }
        }.navigationTitle("多账号管理")
    }
}

struct CourseImportView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var json = ""
    @State private var message = ""
    var body: some View {
        Form {
            Section("粘贴课表 JSON") {
                TextEditor(text: $json).frame(minHeight: 160).font(.system(.body, design: .monospaced)).autocorrectionDisabled()
                Button("导入并去重") {
                    do {
                        let courses = try LocalTools.importCourses(Data(json.utf8)); let before = store.courses.count
                        store.courses = LocalTools.mergeCourses(store.courses, courses); message = "新增 \(store.courses.count - before) 门课程记录。"
                    } catch { message = "格式有误，未修改课表。" }
                }.disabled(json.isEmpty)
                if !message.isEmpty { Text(message) }
            }
            Section("格式示例") {
                Text("[{\"name\":\"课程\",\"location\":\"教室\",\"weekday\":1,\"start\":480,\"end\":570}]").font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                Text("weekday 为 1（周一）至 7（周日），start/end 为午夜起的分钟数。本格式为 工贸助手 自定义导入格式，并非喜鹊儿原始接口格式。")
            }
        }.navigationTitle("导入课表")
    }
}
