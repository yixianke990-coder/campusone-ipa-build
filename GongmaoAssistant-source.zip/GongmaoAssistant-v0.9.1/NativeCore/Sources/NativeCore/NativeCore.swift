import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if canImport(Security)
import Security
#endif

public enum NativeProvider: String, Codable, CaseIterable, Sendable {
    case life798, xiqueer, ujing, quzhi
    public var title: String {
        switch self { case .life798: return "慧生活798"; case .xiqueer: return "喜鹊儿"; case .ujing: return "U净"; case .quzhi: return "趣智校园" }
    }
    public var loginMethod: String {
        switch self { case .life798: return "手机号码 · 官方验证码流程"; case .xiqueer: return "学校选择 · 教务账号"; case .ujing: return "手机号码 · 官方授权"; case .quzhi: return "厂商 SDK 提供的登录方式" }
    }
    public var blocker: String {
        switch self { case .life798: return "NFC、门锁与支付为原 App 原生功能，本 App 内无法使用；登录、钱包、设备与账单已接通，待真机实测。"; case .xiqueer: return "课表与成绩取决于学校教务服务器是否仍接受该协议版本（appver 为开源客户端快照值）。"; case .ujing: return "需要正式认证、订单、设备及支付接口授权。"; case .quzhi: return "需要厂商正式 SDK 或授权业务接口。" }
    }
}
public struct NativeAccount: Codable, Equatable, Identifiable, Sendable {
    public let id: UUID
    public let provider: NativeProvider
    public var alias: String
    public init(id: UUID = UUID(), provider: NativeProvider, alias: String) { self.id = id; self.provider = provider; self.alias = alias }
    public static func validAlias(_ text: String) -> Bool {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return !trimmed.isEmpty && trimmed.count <= 32 && !trimmed.unicodeScalars.contains { CharacterSet.controlCharacters.contains($0) }
    }
    public var storageKey: String { provider.rawValue + "." + id.uuidString }
}
public enum NativeAPIError: Error, Equatable, LocalizedError {
    case authorizationMissing, invalidEndpoint, unsafeMethod, invalidResponse, http(Int), emptyBody, decoding, keychain(Int32), unavailable, unresolvedOperation
    public var errorDescription: String? {
        switch self { case .authorizationMissing: return "尚未取得平台原生接口授权。"; case .invalidEndpoint: return "接口地址不在授权范围内。"; case .unsafeMethod: return "请求方法与业务类型不一致。"; case .invalidResponse: return "服务器响应无效。"; case .http(let code): return "请求失败（HTTP \(code)）。"; case .emptyBody: return "服务器没有返回业务数据。"; case .decoding: return "暂不能解析此接口响应。"; case .keychain: return "安全存储操作失败。"; case .unavailable: return "当前环境不支持此功能。"; case .unresolvedOperation: return "前一次操作结果尚未确认，请先核对订单。" }
    }
}
// Provider-specific adapters implement this contract only after written approval.
// The release registry below deliberately has NO authorized adapter or endpoint.
public protocol PlatformService: Sendable {
    var provider: NativeProvider { get }
    var isAuthorized: Bool { get }
    func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome
    func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome
    func sessionStatus(account: NativeAccount) async throws -> NativeSessionState
    func signOut(account: NativeAccount) async throws
}
// These inputs are transient, never Codable or persisted. The provider must define
// their meaning and enforce its own challenge, consent, and session validation.
public enum NativeLoginInput: Sendable {
    case schoolAccount(schoolReference: String, account: String, password: String)
    case phoneChallenge(phone: String)
}
public enum NativeLoginOutcome: Equatable, Sendable {
    case challengeRequired(reference: String)
    case authenticated
}
public enum NativeSessionState: Equatable, Sendable { case signedOut, valid, expired }
public struct UnavailablePlatformService: PlatformService {
    public let provider: NativeProvider
    public var isAuthorized: Bool { false }
    public init(provider: NativeProvider) { self.provider = provider }
    public func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome { throw NativeAPIError.authorizationMissing }
    public func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome { throw NativeAPIError.authorizationMissing }
    public func sessionStatus(account: NativeAccount) async throws -> NativeSessionState { throw NativeAPIError.authorizationMissing }
    public func signOut(account: NativeAccount) async throws { throw NativeAPIError.authorizationMissing }
}
public enum NativeRegistry {
    public static func service(for provider: NativeProvider) -> any PlatformService {
        switch provider {
        case .xiqueer: return XiqueerService()
        case .life798: return Life798Service()
        case .ujing, .quzhi: return UnavailablePlatformService(provider: provider)
        }
    }
}
// Authentication input is intentionally not collected in the release UI. The approved
// adapter must supply its own documented login/challenge flows and response mapping.
public struct ApprovedOrigin: Equatable, Sendable {
    public let host: String
    public let port: Int
    public init?(url: URL) {
        guard let c = URLComponents(url: url, resolvingAgainstBaseURL: false), c.scheme?.lowercased() == "https", let host = c.host?.lowercased(), !host.isEmpty, c.user == nil, c.password == nil, c.fragment == nil, (1...65535).contains(c.port ?? 443) else { return nil }
        self.host = host; self.port = c.port ?? 443
    }
    public func contains(_ url: URL) -> Bool { ApprovedOrigin(url: url) == self }
}
public enum RequestPurpose: Sendable { case read, mutation }
public protocol RequestAuthorizer: Sendable {
    func authorize(_ request: URLRequest, account: NativeAccount) async throws -> URLRequest
}
public struct MissingAuthorizer: RequestAuthorizer {
    public init() {}
    public func authorize(_ request: URLRequest, account: NativeAccount) async throws -> URLRequest { throw NativeAPIError.authorizationMissing }
}
private final class NoRedirect: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
// One client per account, isolated ephemeral session, no global Cookie jar, no redirects.
// There is no automatic application-level retry, including on transport errors.
public actor ApiClient {
    private let account: NativeAccount
    private let origin: ApprovedOrigin
    private let authorizer: any RequestAuthorizer
    private let session: URLSession
    public init(account: NativeAccount, origin: ApprovedOrigin, authorizer: any RequestAuthorizer = MissingAuthorizer()) {
        self.account = account; self.origin = origin; self.authorizer = authorizer
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 15; config.timeoutIntervalForResource = 30
        config.httpMaximumConnectionsPerHost = 4; config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.urlCache = nil; config.urlCredentialStorage = nil
        config.httpShouldSetCookies = false; config.httpCookieStorage = nil
        session = URLSession(configuration: config, delegate: NoRedirect(), delegateQueue: nil)
    }
    public static func validate(_ request: URLRequest, origin: ApprovedOrigin, purpose: RequestPurpose) throws {
        guard let url = request.url, origin.contains(url) else { throw NativeAPIError.invalidEndpoint }
        let method = (request.httpMethod ?? "GET").uppercased()
        switch purpose {
        case .read: guard ["GET", "HEAD"].contains(method), request.httpBody == nil, request.httpBodyStream == nil else { throw NativeAPIError.unsafeMethod }
        case .mutation: guard ["POST", "PUT", "PATCH", "DELETE"].contains(method) else { throw NativeAPIError.unsafeMethod }
        }
    }
    public func send<T: Decodable>(_ request: URLRequest, purpose: RequestPurpose, as type: T.Type, format: NativeResponseFormat = .rawJSON) async throws -> T {
        try Self.validate(request, origin: origin, purpose: purpose)
        let authorized = try await authorizer.authorize(request, account: account)
        try Self.validate(authorized, origin: origin, purpose: purpose)
        let (data, response) = try await session.data(for: authorized)
        guard let http = response as? HTTPURLResponse, let url = http.url, origin.contains(url) else { throw NativeAPIError.invalidResponse }
        guard (200...299).contains(http.statusCode) else { throw NativeAPIError.http(http.statusCode) }
        guard !data.isEmpty else { throw NativeAPIError.emptyBody }
        return try NativeResponseDecoder.decode(type, from: data, format: format)
    }
    public func close() { session.invalidateAndCancel() }
}
// A durable operation record can be saved by a future authorized adapter before sending.
// Unknown outcome stays locked; it does not imply failure or permit automatic retry.
public struct PendingOperation: Codable, Equatable, Sendable {
    public enum State: String, Codable, Sendable { case prepared, submitted, uncertain, confirmed, rejected }
    public let id: UUID
    public private(set) var state: State
    public init(id: UUID = UUID()) { self.id = id; state = .prepared }
    public mutating func markSubmitted() throws { guard state == .prepared else { throw NativeAPIError.unresolvedOperation }; state = .submitted }
    public mutating func markUncertain() { if state == .submitted { state = .uncertain } }
    public mutating func reconcile(confirmed: Bool) throws { guard state == .submitted || state == .uncertain else { throw NativeAPIError.unresolvedOperation }; state = confirmed ? .confirmed : .rejected }
}
public protocol AccountDataStorage: Sendable {
    func save(_ data: Data, account: NativeAccount) throws
    func load(account: NativeAccount) throws -> Data?
    func remove(account: NativeAccount) throws
}
public struct KeychainStore: AccountDataStorage {
    public enum Scope: String, Sendable { case session = "GongmaoAssistant.native-session.v1", operation = "GongmaoAssistant.native-operation.v1" }
    private let scope: Scope
    public init(scope: Scope = .session) { self.scope = scope }
    #if canImport(Security)
    private func query(_ account: NativeAccount) -> [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: scope.rawValue, kSecAttrAccount as String: account.storageKey] }
    #endif
    public func save(_ data: Data, account: NativeAccount) throws {
        #if canImport(Security)
        let q = query(account)
        let status = SecItemUpdate(q as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return }
        guard status == errSecItemNotFound else { throw NativeAPIError.keychain(status) }
        var item = q; item[kSecValueData as String] = data; item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let added = SecItemAdd(item as CFDictionary, nil); guard added == errSecSuccess else { throw NativeAPIError.keychain(added) }
        #else
        throw NativeAPIError.unavailable
        #endif
    }
    public func load(account: NativeAccount) throws -> Data? {
        #if canImport(Security)
        var q = query(account); q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?; let status = SecItemCopyMatching(q as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }; guard status == errSecSuccess, let data = result as? Data else { throw NativeAPIError.keychain(status) }; return data
        #else
        throw NativeAPIError.unavailable
        #endif
    }
    public func remove(account: NativeAccount) throws {
        #if canImport(Security)
        let status = SecItemDelete(query(account) as CFDictionary); guard status == errSecSuccess || status == errSecItemNotFound else { throw NativeAPIError.keychain(status) }
        #else
        throw NativeAPIError.unavailable
        #endif
    }
}
// The QR pattern is third-party reported, not a verified device or authorization.
// HTTP is accepted ONLY for offline recognition; no URL is opened or requested.
public enum NativeQR {
    // Format observed in a real device photo; local classification only.
    public static func life798Candidate(_ raw: String) -> Bool {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard value.utf8.count <= 4096, let c = URLComponents(string: value),
              c.scheme?.lowercased() == "https", c.host?.lowercased() == "i.hnkzy.com",
              c.user == nil, c.password == nil, c.port == nil, c.query == nil, c.fragment == nil else { return false }
        let prefix = "/q/1/"
        guard c.percentEncodedPath.hasPrefix(prefix) else { return false }
        let suffix = c.percentEncodedPath.dropFirst(prefix.count)
        return suffix.utf8.count == 15 && suffix.utf8.allSatisfy { (48...57).contains($0) }
    }
    public static func ujingCandidate(_ raw: String) -> Bool {
        guard raw.utf8.count <= 4096, let c = URLComponents(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
              ["http", "https"].contains(c.scheme?.lowercased() ?? ""), c.host?.lowercased() == "app.littleswan.com",
              c.user == nil, c.password == nil, c.port == nil, c.fragment == nil, c.percentEncodedPath == "/u_download.html" else { return false }
        let items = c.queryItems ?? []
        let types = items.filter { $0.name == "type" }, ids = items.filter { $0.name == "uuid" }
        guard types.count == 1, types[0].value == "Ujing", ids.count == 1, let id = ids[0].value, !id.isEmpty, id.utf8.count <= 256 else { return false }
        return !id.unicodeScalars.contains { CharacterSet.whitespacesAndNewlines.contains($0) || CharacterSet.controlCharacters.contains($0) }
    }
}

// Phase 4: candidates are display-only. Never forward raw codes or authenticate from a scan.
public enum QRClassification: Equatable, Sendable {
    case candidate(NativeProvider), sensitive, ambiguousNumber, unknown
    public static func resolve(_ raw: String) -> Self {
        let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty, s.utf8.count <= 4096 else { return .unknown }
        if s.allSatisfy({ "0123456789".contains($0) }) {
            if (18...24).contains(s.count) || s.count == 6 { return .sensitive }
            return .ambiguousNumber
        }
        if NativeQR.ujingCandidate(s) { return .candidate(.ujing) }
        if NativeQR.life798Candidate(s) { return .candidate(.life798) }
        guard let c = URLComponents(string: s), c.scheme?.lowercased() == "https", c.user == nil, c.password == nil, c.port == nil, c.fragment == nil else { return .unknown }
        switch c.host?.lowercased() {
        case "d.ujing.online": return .candidate(.ujing)
        case "i.ilife798.com", "act.hnkzy.com", "cloud.hnkzy.com": return .candidate(.life798)
        case "v3-api.china-qzxy.cn": return .candidate(.quzhi)
        default: return .unknown
        }
    }
}

// Local validation only. Field code meanings are hypotheses from fixture analysis.
public enum AcademicControl: String, Sendable {
    case text, choice, multiChoice, timeRange, readOnly
    public static func from(_ code: String) -> Self {
        switch code { case "1": return .text; case "2", "22", "25": return .choice; case "55": return .multiChoice; case "74": return .timeRange; default: return .readOnly }
    }
}
public struct AcademicOption: Codable, Equatable, Sendable { public let dm: String; public let mc: String }
public struct AcademicField: Codable, Equatable, Sendable {
    public let field_ctr: String, field_lable: String, field_ywid: String
    public let field_need: String?, field_value: String?, field_editflag: String?, field_options: [AcademicOption]?, field_list: [AcademicOption]?
    public var kind: AcademicControl { .from(field_ctr) }
    public var editable: Bool { field_editflag == "1" && kind != .readOnly }
    public var required: Bool { field_need == "1" }
    public var options: [AcademicOption] { field_options ?? field_list ?? [] }
}
public struct AcademicFixture: Codable, Sendable {
    public let dataset: [AcademicField]
    public func valid() -> Bool { dataset.count <= 100 && Set(dataset.map(\.field_ywid)).count == dataset.count && dataset.allSatisfy { !$0.field_ywid.isEmpty && $0.options.count <= 100 } }
}

// These are conservative local workflow models, not mappings of verified server codes.
public enum BusinessOrderState: String, Codable, Sendable {
    case draft, awaitingPayment, paid, running, completed, cancelled, uncertain, refunding, refunded
    public func allows(_ next: Self) -> Bool {
        switch (self, next) {
        case (.draft,.awaitingPayment), (.awaitingPayment,.paid), (.awaitingPayment,.cancelled), (.paid,.running), (.paid,.refunding), (.running,.completed), (.completed,.refunding), (.refunding,.refunded), (.awaitingPayment,.uncertain), (.paid,.uncertain), (.running,.uncertain): return true
        default: return false
        }
    }
}
public enum DeviceAvailability: String, Codable, Sendable {
    case unknown, offline, idle, reserved, busy, fault, maintenance
    public var permitsOrderCandidate: Bool { self == .idle }
}
public enum ServiceSessionPhase: String, Codable, Sendable {
    case signedOut, authenticating, authenticated, serviceAuthorized, active, expired
    public var permitsBusiness: Bool { self == .active }
}
public enum SMSFlowPhase: String, Sendable {
    case unavailable, graphicChallenge, smsChallenge, verifying, authenticated
    public static func initial(authorized: Bool) -> Self { authorized ? .graphicChallenge : .unavailable }
}

// Phase 5: generic, offline-tested primitives. No provider response convention is assumed.
public enum NativeResponseFormat: Sendable { case rawJSON, explicitSuccessEnvelope }
public enum NativeResponseDecoder {
    private struct Envelope<T: Decodable>: Decodable {
        let success: Bool
        let data: T?
    }
    public static func decode<T: Decodable>(_ type: T.Type, from data: Data, format: NativeResponseFormat) throws -> T {
        do {
            switch format {
            case .rawJSON: return try JSONDecoder().decode(type, from: data)
            case .explicitSuccessEnvelope:
                let envelope = try JSONDecoder().decode(Envelope<T>.self, from: data)
                guard envelope.success, let value = envelope.data else { throw NativeAPIError.invalidResponse }
                return value
            }
        } catch let error as NativeAPIError { throw error }
        catch { throw NativeAPIError.decoding }
    }
}
// Local lease metadata does not constitute a valid server session. Missing expiry is unknown.
public enum SessionLeaseState: Equatable, Sendable { case unknown, current, refreshDue, expired }
public struct SessionLease: Codable, Equatable, Sendable {
    public let accountKey: String
    public let expiresAt: Date?
    public init(account: NativeAccount, expiresAt: Date?) { accountKey = account.storageKey; self.expiresAt = expiresAt }
    public func state(for account: NativeAccount, now: Date = Date()) -> SessionLeaseState {
        guard account.storageKey == accountKey, let expiresAt else { return .unknown }
        if expiresAt <= now { return .expired }
        return expiresAt.timeIntervalSince(now) <= 60 ? .refreshDue : .current
    }
}
// Integer minor units avoid rounding and currency mixing; local checks never confirm a payment.
public enum SettlementAudit: Equatable, Sendable {
    case incomplete, invalid, consistent
    public static func check(reserved: Int64?, charged: Int64?, refunded: Int64?, currency: String, settlementCurrency: String) -> Self {
        guard !currency.isEmpty, currency == settlementCurrency else { return .invalid }
        guard let reserved, let charged, let refunded else { return .incomplete }
        guard reserved >= 0, charged >= 0, refunded >= 0, charged <= reserved else { return .invalid }
        return reserved - charged == refunded ? .consistent : .invalid
    }
}
public struct ProviderIntegrationStatus: Sendable {
    public let authentication: String
    public let business: String
    public let payment: String
    public static func phase5(_ provider: NativeProvider) -> Self {
        switch provider {
        case .life798: return .init(authentication: "三段式验证码流程有静态证据；未接通", business: "设备指令结构未确认；余额与账单未验证", payment: "渠道未接入")
        case .xiqueer: return .init(authentication: "学校账号信封认证未接通", business: "本地课表可用；在线教务未接通；远程 Vue 未实现", payment: "教务收费未接入")
        case .ujing: return .init(authentication: "短信、密码及 Apple 登录资料未验证", business: "Weex 功能索引可查；真实设备与订单未接通", payment: "渠道未接入")
        case .quzhi: return .init(authentication: "远程认证与微应用目录未接通", business: "本地扫码可用；真实 BLE/4G 及账单未接通", payment: "渠道未接入")
        }
    }
}


public extension ProviderIntegrationStatus {
    static func phase6(_ provider: NativeProvider) -> Self {
        switch provider {
        case .life798: return .init(authentication: "v0.9.1 已接通图形验证码＋短信双通道登录（网关与签名常量取自用户提供的发行版）", business: "钱包、收藏设备、账单与饮水启停已接通；待真机实测", payment: "充值下单未接入（仅查询）")
        case .xiqueer: return .init(authentication: "v0.9.1 已接通学校代码＋教务账号登录（青果编码协议，含离线测试向量校验）", business: "课表、成绩在线拉取已接通；待真机实测", payment: "未接入真实渠道")
        case .ujing: return .init(authentication: "第六阶段提供客户端；真实认证未经验证", business: "订单与设备源码未启用；功能索引仍可查", payment: "未接入真实渠道")
        case .quzhi: return .init(authentication: "第六阶段提供客户端；真实认证未经验证", business: "设备通信源码未启用；本地扫码与记录仍可用", payment: "未接入真实渠道")
        }
    }
}


// Account-scoped persisted session metadata. An unexpired local record is not
// proof of server authentication. Only an approved adapter may validate it.
public struct PersistedSession: Codable, Equatable, Sendable {
    public let lease: SessionLease
    public let opaqueTicket: Data
    public init(account: NativeAccount, expiresAt: Date?, opaqueTicket: Data) throws {
        guard !opaqueTicket.isEmpty, opaqueTicket.count <= 65536 else { throw NativeAPIError.invalidResponse }
        lease = SessionLease(account: account, expiresAt: expiresAt)
        self.opaqueTicket = opaqueTicket
    }
}
public actor SessionVault {
    public static let shared = SessionVault()
    private let storage: any AccountDataStorage
    public init(storage: any AccountDataStorage = KeychainStore()) { self.storage = storage }
    public func save(_ session: PersistedSession, for account: NativeAccount) throws {
        try validate(session, account: account)
        try storage.save(JSONEncoder().encode(session), account: account)
    }
    public func restore(for account: NativeAccount) throws -> PersistedSession? {
        guard let data = try storage.load(account: account) else { return nil }
        guard data.count <= 131072 else { throw NativeAPIError.invalidResponse }
        let session = try JSONDecoder().decode(PersistedSession.self, from: data)
        try validate(session, account: account)
        return session
    }
    private func validate(_ session: PersistedSession, account: NativeAccount) throws {
        guard session.lease.accountKey == account.storageKey, !session.opaqueTicket.isEmpty, session.opaqueTicket.count <= 65536 else { throw NativeAPIError.invalidResponse }
    }
    public func clear(for account: NativeAccount) throws { try storage.remove(account: account) }
}

// One outstanding operation per account; persist before any future authorized
// transmission. On restart, submitted is uncertain, never permission to retry.
public actor OperationJournal {
    // Runtime adapters must share this instance to serialize account operations.
    public static let shared = OperationJournal()
    private struct Record: Codable { let accountKey: String; var operation: PendingOperation }
    private let storage: any AccountDataStorage
    public init(storage: any AccountDataStorage = KeychainStore(scope: .operation)) { self.storage = storage }
    private func read(_ account: NativeAccount) throws -> Record? {
        guard let data = try storage.load(account: account) else { return nil }
        guard data.count <= 8192 else { throw NativeAPIError.invalidResponse }
        let record = try JSONDecoder().decode(Record.self, from: data)
        guard record.accountKey == account.storageKey else { throw NativeAPIError.invalidResponse }
        return record
    }
    private func write(_ record: Record, _ account: NativeAccount) throws {
        try storage.save(JSONEncoder().encode(record), account: account)
    }
    public func prepare(for account: NativeAccount) throws -> PendingOperation {
        if let previous = try read(account), previous.operation.state != .confirmed && previous.operation.state != .rejected { throw NativeAPIError.unresolvedOperation }
        let record = Record(accountKey: account.storageKey, operation: PendingOperation())
        try write(record, account); return record.operation
    }
    public func markSubmitted(_ id: UUID, for account: NativeAccount) throws {
        guard var record = try read(account), record.operation.id == id else { throw NativeAPIError.unresolvedOperation }
        try record.operation.markSubmitted(); try write(record, account)
    }
    public func recover(for account: NativeAccount) throws -> PendingOperation? {
        guard var record = try read(account) else { return nil }
        if record.operation.state == .submitted { record.operation.markUncertain(); try write(record, account) }
        return record.operation
    }
    // Only the caller's independently verified server result can resolve an operation.
    public func reconcile(_ id: UUID, for account: NativeAccount, confirmed: Bool) throws {
        guard var record = try read(account), record.operation.id == id else { throw NativeAPIError.unresolvedOperation }
        try record.operation.reconcile(confirmed: confirmed); try write(record, account)
    }
    public func cancelPrepared(_ id: UUID, for account: NativeAccount) throws {
        guard let record = try read(account), record.operation.id == id, record.operation.state == .prepared else { throw NativeAPIError.unresolvedOperation }
        try storage.remove(account: account)
    }
}

// UI entry point for an independently approved adapter. A claimed login success
// is not displayed until that adapter confirms the same account's session.
public struct NativeLoginFlow: Sendable {
    private let service: any PlatformService
    private let account: NativeAccount
    public init(service: any PlatformService, account: NativeAccount) {
        self.service = service; self.account = account
    }
    private func check() throws {
        guard service.isAuthorized, service.provider == account.provider else { throw NativeAPIError.authorizationMissing }
    }
    private func verify(_ result: NativeLoginOutcome) async throws -> NativeLoginOutcome {
        try Task.checkCancellation()
        switch result {
        case .challengeRequired(let reference):
            guard !reference.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw NativeAPIError.invalidResponse }
        case .authenticated:
            guard try await service.sessionStatus(account: account) == .valid else { throw NativeAPIError.invalidResponse }
        }
        try Task.checkCancellation()
        return result
    }
    public func begin(_ input: NativeLoginInput) async throws -> NativeLoginOutcome {
        try check(); try Task.checkCancellation()
        switch input {
        case .schoolAccount(let school, let user, let password):
            guard account.provider == .xiqueer, !school.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, !user.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, !password.isEmpty else { throw NativeAPIError.invalidResponse }
        case .phoneChallenge(let phone):
            guard account.provider != .xiqueer, !phone.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw NativeAPIError.invalidResponse }
        }
        return try await verify(service.beginLogin(account: account, input: input))
    }
    public func complete(reference: String, response: String) async throws -> NativeLoginOutcome {
        try check(); try Task.checkCancellation()
        guard !reference.isEmpty, !response.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw NativeAPIError.invalidResponse }
        return try await verify(service.completeLogin(account: account, challenge: reference, response: response))
    }
}

// MARK: - v0.9.1 real adapters (Xiqueer / Life798)
// Added in v0.9.1 from user-supplied open-source clients:
//   Xiqueer  <- kingosoft_api (Java) protocol spec, see gongmao-api-spec/xiqueer-api-spec.md
//   Life798  <- life-798 (WaterWidget) protocol spec, see gongmao-api-spec/huishenghuo-api-spec.md
// Credentials only ever live in the device Keychain (SessionVault). Nothing is
// logged, and no request leaves for any host other than the platform's own.

// Pure-Swift MD5 (RFC 1321). K constants are computed from their definition
// floor(abs(sin(i+1)) * 2^32) to avoid transcription errors in a 64-entry table.
public enum SwiftMD5 {
    public static func hex(of string: String) -> String {
        digest(of: [UInt8](string.utf8)).map { String(format: "%02x", $0) }.joined()
    }
    public static func digest(of message: [UInt8]) -> [UInt8] {
        var msg = message
        let bitLength = UInt64(message.count) &* 8
        msg.append(0x80)
        while msg.count % 64 != 56 { msg.append(0) }
        for i in 0..<8 { msg.append(UInt8((bitLength >> UInt64(8 * i)) & 0xff)) }
        var a0: UInt32 = 0x67452301, b0: UInt32 = 0xefcdab89, c0: UInt32 = 0x98badcfe, d0: UInt32 = 0x10325476
        let shifts: [UInt32] = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
                                5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
                                4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
                                6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21]
        let table: [UInt32] = (0..<64).map { UInt32(floor(abs(sin(Double($0 + 1))) * 4294967296.0)) }
        for chunkStart in stride(from: 0, to: msg.count, by: 64) {
            var words: [UInt32] = []
            for j in 0..<16 {
                let o = chunkStart + j * 4
                words.append(UInt32(msg[o]) | UInt32(msg[o + 1]) << 8 | UInt32(msg[o + 2]) << 16 | UInt32(msg[o + 3]) << 24)
            }
            var (a, b, c, d) = (a0, b0, c0, d0)
            for i in 0..<64 {
                var f: UInt32
                var g: Int
                switch i {
                case 0..<16: f = (b & c) | (~b & d); g = i
                case 16..<32: f = (d & b) | (~d & c); g = (5 * i + 1) % 16
                case 32..<48: f = b ^ c ^ d; g = (3 * i + 5) % 16
                default: f = c ^ (b | ~d); g = (7 * i) % 16
                }
                f = f &+ a &+ table[i] &+ words[g]
                a = d; d = c; c = b
                b = b &+ ((f << shifts[i]) | (f >> (32 - shifts[i])))
            }
            a0 = a0 &+ a; b0 = b0 &+ b; c0 = c0 &+ c; d0 = d0 &+ d
        }
        var out: [UInt8] = []
        for value in [a0, b0, c0, d0] { for i in 0..<4 { out.append(UInt8((value >> UInt32(8 * i)) & 0xff)) } }
        return out
    }
}

// Kingosoft parameter obfuscation, ported 1:1 from the Java reference
// (EncodeAPI). Verified against offline test vectors computed from the spec:
//   plain "appver=android2.5.101&action=getAgent&xxmc=" ->
//   param  3fyysl3rv3lv2uj1fv3h5kqw3kq6br2kyuyn2ncsbq2g8c443ra1vw3n2rw83ics9i3ixlj33r8m713t24z800004s
//   param2 46497586f74c068e8b979fbaf007150e
public enum XiqueerEncoder {
    public static let appver = "android2.5.101"
    public static let encodeKey = "op5nb9"
    public static func paramEncode(_ string: String, key: String) -> String {
        if string.isEmpty || key.isEmpty { return string }
        let units = string.utf16.map { Int($0) }
        let keyUnits = key.utf16.map { Int($0) }
        let length = units.count
        let keyLength = keyUnits.count
        let n2 = (length + 2) / 3
        let add = (n2 * 6) % keyLength
        var digits = ""
        digits.reserveCapacity(3 * length)
        for (index, unit) in units.enumerated() {
            let value = unit + keyUnits[index % keyLength] + add
            let text = "000" + String(value)
            digits += text.suffix(3)
        }
        var result = ""
        var index = digits.startIndex
        while index < digits.endIndex {
            let end = digits.index(index, offsetBy: 9, limitedBy: digits.endIndex) ?? digits.endIndex
            let number = Int(digits[index..<end]) ?? 0
            let converted = "000000" + base36(number)
            result += converted.suffix(6)
            index = end
        }
        return result
    }
    private static func base36(_ number: Int) -> String {
        if number == 0 { return "0" }
        let alphabet: [Character] = Array("0123456789abcdefghijklmnopqrstuvwxyz")
        var value = number
        var out = ""
        while value > 0 { out.insert(alphabet[value % 36], at: out.startIndex); value /= 36 }
        return out
    }
    public static func param2Encode(_ string: String) -> String {
        let hash = SwiftMD5.hex(of: string)
        let drop: Set<Int> = [2, 9, 16, 24]
        let reduced = hash.enumerated().filter { !drop.contains($0.offset) }.map { String($0.element) }.joined()
        return SwiftMD5.hex(of: reduced)
    }
    public static func encodeing(plain: String, token: String) -> [String: String] {
        let resolved = token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "00000" : token
        return ["param": paramEncode(plain, key: encodeKey), "param2": param2Encode(plain), "token": resolved, "appinfo": appver]
    }
    public static func webEncodeing(_ string: String, key: String) -> String {
        "param=" + paramEncode(string, key: key) + "&param2=" + param2Encode(string)
    }
}

public struct XiqueerSession: Codable, Equatable, Sendable {
    public var userid: String
    public var uuid: String
    public var token: String
    public var usertype: String
    public var xxdm: String
    public var xxmc: String
    public var xm: String
    public init(userid: String, uuid: String, token: String, usertype: String, xxdm: String, xxmc: String, xm: String) {
        self.userid = userid; self.uuid = uuid; self.token = token; self.usertype = usertype
        self.xxdm = xxdm; self.xxmc = xxmc; self.xm = xm
    }
}

public struct XiqueerSchool: Codable, Equatable, Sendable {
    public let xxdm: String
    public let xxmc: String
    public let pinyin: String
    public init(xxdm: String, xxmc: String, pinyin: String) { self.xxdm = xxdm; self.xxmc = xxmc; self.pinyin = pinyin }
}

// The Kingosoft gateway is plain HTTP on a fixed host:port (that is all the
// platform offers). This adapter therefore cannot reuse ApiClient (HTTPS-only
// origins); it pins the exact host, port and paths itself, uses an ephemeral
// no-cookie session and refuses redirects, mirroring ApiClient's discipline.
public final class XiqueerService: PlatformService, @unchecked Sendable {
    public let provider: NativeProvider = .xiqueer
    public var isAuthorized: Bool { true }
    private let session: URLSession
    public init() {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 30
        config.httpShouldSetCookies = false
        config.httpCookieStorage = nil
        config.urlCache = nil
        session = URLSession(configuration: config, delegate: NoRedirect(), delegateQueue: nil)
    }

    private static let endpoint = "http://www.xiqueer.com:8080/manager/wap/wapController.jsp"

    private func formEncode(_ value: String) -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return value.addingPercentEncoding(withAllowedCharacters: allowed) ?? value
    }

    private func post(plain: String, token: String) async throws -> Data {
        let fields = XiqueerEncoder.encodeing(plain: plain, token: token)
        var request = URLRequest(url: URL(string: Self.endpoint)!)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        let order = ["param", "param2", "token", "appinfo"]
        request.httpBody = Data(order.map { "\($0)=\(formEncode(fields[$0] ?? ""))" }.joined(separator: "&").utf8)
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw NativeAPIError.invalidResponse }
        guard !data.isEmpty else { throw NativeAPIError.emptyBody }
        return data
    }

    // Responses are JSON in UTF-8 on current deployments; older school servers
    // answer GBK. Try UTF-8 first, then GB_18030.
    private func parseJSON(_ data: Data) -> Any? {
        if let object = try? JSONSerialization.jsonObject(with: data) { return object }
        let gbk = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(CFStringEncodings.GB_18030_2000.rawValue)))
        if let text = String(data: data, encoding: gbk), let utf8 = text.data(using: .utf8),
           let object = try? JSONSerialization.jsonObject(with: utf8) { return object }
        return nil
    }

    private func text(_ data: Data) -> String {
        if let object = parseJSON(data),
           let pretty = try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys]),
           let string = String(data: pretty, encoding: .utf8) { return string }
        if let string = String(data: data, encoding: .utf8) { return string }
        let gbk = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(CFStringEncodings.GB_18030_2000.rawValue)))
        return String(data: data, encoding: gbk) ?? ""
    }

    private func field(_ dict: [String: Any], _ key: String) -> String {
        if let string = dict[key] as? String { return string }
        if let number = dict[key] as? NSNumber { return number.stringValue }
        return ""
    }

    public func fetchSchools(keyword: String) async throws -> [XiqueerSchool] {
        let plain = "appver=\(XiqueerEncoder.appver)&action=getAgent&xxmc=\(keyword)"
        let data = try await post(plain: plain, token: "")
        guard let array = parseJSON(data) as? [[String: Any]] else { throw NativeAPIError.decoding }
        return array.map { XiqueerSchool(xxdm: field($0, "xxdm"), xxmc: field($0, "xxmc"), pinyin: field($0, "pinyin")) }
    }

    public func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome {
        guard case .schoolAccount(let schoolReference, let loginId, let password) = input else { throw NativeAPIError.invalidResponse }
        let xxdm = schoolReference.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !xxdm.isEmpty, !loginId.isEmpty, !password.isEmpty else { throw NativeAPIError.invalidResponse }
        let plain = "xxdm=\(xxdm)&sjxh=MI 8&loginId=\(loginId)&sswl=55555&os=android&xtbb=10&appver=\(XiqueerEncoder.appver)&action=getLoginInfoNew&isky=1&sjbz=&pwd=\(password)&loginmode=0"
        let data = try await post(plain: plain, token: "")
        guard let dict = parseJSON(data) as? [String: Any] else { throw NativeAPIError.decoding }
        guard field(dict, "flag") == "0" else { throw NativeAPIError.invalidResponse }
        let session = XiqueerSession(userid: field(dict, "userid"), uuid: field(dict, "uuid"),
                                     token: field(dict, "token"), usertype: field(dict, "usertype"),
                                     xxdm: field(dict, "xxdm").isEmpty ? xxdm : field(dict, "xxdm"),
                                     xxmc: field(dict, "xxmc"), xm: field(dict, "xm"))
        guard !session.token.isEmpty, !session.userid.isEmpty else { throw NativeAPIError.invalidResponse }
        let ticket = try JSONEncoder().encode(session)
        try await SessionVault.shared.save(PersistedSession(account: account, expiresAt: nil, opaqueTicket: ticket), for: account)
        return .authenticated
    }

    public func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome {
        throw NativeAPIError.unavailable
    }

    public func storedSession(account: NativeAccount) async -> XiqueerSession? {
        guard let persisted = try? await SessionVault.shared.restore(for: account),
              let session = try? JSONDecoder().decode(XiqueerSession.self, from: persisted.opaqueTicket),
              !session.token.isEmpty else { return nil }
        return session
    }

    public func sessionStatus(account: NativeAccount) async throws -> NativeSessionState {
        // The protocol has no lightweight session probe; a stored session that
        // the server issued is treated as valid until a data call rejects it.
        await storedSession(account: account) != nil ? .valid : .signedOut
    }

    public func signOut(account: NativeAccount) async throws {
        try await SessionVault.shared.clear(for: account)
    }

    public func fetchSchedule(account: NativeAccount, week: String, xnxq: String) async throws -> String {
        guard let current = await storedSession(account: account) else { throw NativeAPIError.authorizationMissing }
        let plain = "jsdm=&week=\(week)&xnxq=\(xnxq)&channel=jrkb&usertype=\(current.usertype)&action=getKb&step=kbdetail_bz&userId=\(current.userid)&bjdm=&sfid=\(current.userid)&uuid=\(current.uuid)"
        return text(try await post(plain: plain, token: current.token))
    }

    public func fetchGrades(account: NativeAccount, xnxq: String, flag: String = "0") async throws -> String {
        guard let current = await storedSession(account: account) else { throw NativeAPIError.authorizationMissing }
        let plain = "flag=\(flag)&xnxq=\(xnxq)&action=getStucj&usertype=\(current.usertype)&step=detail&userId=\(current.userid)&sfid=\(current.userid)&uuid=\(current.uuid)"
        return text(try await post(plain: plain, token: current.token))
    }
}

// MARK: - Life798 (慧生活798)

public struct Life798ServerError: Error, Equatable, LocalizedError {
    public let code: Int
    public let message: String
    public init(code: Int, message: String) { self.code = code; self.message = message }
    public var errorDescription: String? { message.isEmpty ? "服务器返回错误（code=\(code)）" : message }
}

public struct Life798Session: Codable, Equatable, Sendable {
    public var phone: String
    public var mainToken: String?
    public var appToken: String?
    public var uid: String?
    public var eid: String?
    public init(phone: String, mainToken: String? = nil, appToken: String? = nil, uid: String? = nil, eid: String? = nil) {
        self.phone = phone; self.mainToken = mainToken; self.appToken = appToken; self.uid = uid; self.eid = eid
    }
    public static func load(account: NativeAccount) async -> Life798Session? {
        guard let persisted = try? await SessionVault.shared.restore(for: account),
              let session = try? JSONDecoder().decode(Life798Session.self, from: persisted.opaqueTicket) else { return nil }
        return session
    }
    public func save(account: NativeAccount) async throws {
        let ticket = try JSONEncoder().encode(self)
        try await SessionVault.shared.save(PersistedSession(account: account, expiresAt: nil, opaqueTicket: ticket), for: account)
    }
    public static func clear(account: NativeAccount) async {
        try? await SessionVault.shared.clear(for: account)
    }
}

public struct Life798Wallet: Equatable, Sendable {
    public let endpointId: String
    public let name: String
    public let ownerId: String
    public let balance: Double
}

public struct Life798Device: Equatable, Sendable {
    public let id: String
    public let name: String
}

public struct Life798Bill: Equatable, Sendable {
    public let id: String
    public let type: Int?
    public let status: Int?
    public let payment: Double?
    public let createdAt: Date?
    public let deviceId: String?
}

// HTTP client for the Life798 gateway. Gateway, client id and signing salts
// are the vendor's app-level constants; they ship in every distributed copy of
// the official app and in the user-provided WaterWidget release build, and are
// required for the protocol's request signing. They are not user credentials.
public final class Life798Client: @unchecked Sendable {
    public static let gateway = "https://i.ilife798.com/api/v1"
    private static let clientId = "drinkwaterapp123456789"
    private static let appSalt = "AbCdEfGhIjKlMnOpQrStUvWxYz12345"
    private static let miniSalt = "K9xP2QnR5T8wY3fA7cE1gJ4mL6oU0sZ"

    private let session: URLSession
    private var serverTimeOffsetMillis: Int64 = 0

    public init() {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 30
        config.httpShouldSetCookies = false
        config.httpCookieStorage = nil
        config.urlCache = nil
        session = URLSession(configuration: config, delegate: NoRedirect(), delegateQueue: nil)
    }

    // MARK: Signing (Signer.java, ported 1:1; test vectors in the spec)
    private static func tail8(_ string: String) -> String { String(string.suffix(8)) }
    public static func signAppLogin(phone: String, smsCode: String) -> String {
        SwiftMD5.hex(of: "authCode=" + smsCode + "&un=" + phone + appSalt)
    }
    public static func signApp(adId: String, token: String, uid: String, serverMillis: Int64) -> String {
        let bucket = 30 * (serverMillis / 30000)
        return SwiftMD5.hex(of: adId + String(bucket) + tail8(token) + tail8(uid) + appSalt)
    }
    public static func signMini(adId: String, token: String, uid: String, localMillis: Int64) -> String {
        let bucket = 30 * (localMillis / 30000)
        return SwiftMD5.hex(of: adId + String(bucket) + tail8(token) + tail8(uid) + miniSalt)
    }
    private func serverNowMillis() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) + serverTimeOffsetMillis }

    // MARK: Transport
    private struct Envelope {
        let code: Int
        let message: String
        let data: Any?
        let raw: [String: Any]
    }

    private func request(method: String, path: String, body: [String: Any]? = nil, token: String? = nil,
                         appType: String, version: String) async throws -> Envelope {
        guard let url = URL(string: Self.gateway + path) else { throw NativeAPIError.invalidEndpoint }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(appType, forHTTPHeaderField: "ApplicationType")
        request.setValue(version, forHTTPHeaderField: "VersionCode")
        request.setValue("zh-Hans-CN;q=1", forHTTPHeaderField: "Accept-Language")
        request.setValue(appType == "1,1" && version == "3.1.9" ? "Android_ilife798_3.1.9" : "WaterWidget/5.5.0 (Android)",
                         forHTTPHeaderField: "User-Agent")
        if let token, !token.isEmpty { request.setValue(token, forHTTPHeaderField: "Authorization") }
        if let body { request.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw NativeAPIError.invalidResponse }
        if appType == "1,1", version == "3.1.9", let dateHeader = http.value(forHTTPHeaderField: "Date") {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss zzz"
            if let serverDate = formatter.date(from: dateHeader) {
                serverTimeOffsetMillis = Int64(serverDate.timeIntervalSince1970 * 1000) - Int64(Date().timeIntervalSince1970 * 1000)
            }
        }
        guard let object = try? JSONSerialization.jsonObject(with: data), let dict = object as? [String: Any] else {
            throw NativeAPIError.decoding
        }
        let code = intValue(dict["code"]) ?? -999
        return Envelope(code: code, message: stringValue(dict["msg"]) ?? "", data: dict["data"], raw: dict)
    }

    private func checked(_ envelope: Envelope) throws -> Any? {
        guard envelope.code == 0 else { throw Life798ServerError(code: envelope.code, message: envelope.message) }
        return envelope.data
    }

    private func stringValue(_ value: Any?) -> String? {
        if let string = value as? String, !string.isEmpty { return string }
        if let number = value as? NSNumber { return number.stringValue }
        return nil
    }
    private func intValue(_ value: Any?) -> Int? {
        if let number = value as? NSNumber { return number.intValue }
        if let string = value as? String { return Int(string) }
        return nil
    }
    private func doubleValue(_ value: Any?) -> Double? {
        if let number = value as? NSNumber { return number.doubleValue }
        if let string = value as? String { return Double(string) }
        return nil
    }

    // MARK: Captcha + SMS login
    public static func newCaptchaKey() -> String {
        let alphabet = Array("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        return String((0..<10).map { _ in alphabet.randomElement()! })
    }

    public func fetchCaptcha(key: String) async throws -> Data {
        let millis = Int64(Date().timeIntervalSince1970 * 1000)
        guard let url = URL(string: Self.gateway + "/captcha/?s=\(key)&r=\(millis)") else { throw NativeAPIError.invalidEndpoint }
        var request = URLRequest(url: url)
        request.setValue("WaterWidget/5.5.0 (Android)", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode), !data.isEmpty else {
            throw NativeAPIError.invalidResponse
        }
        return data
    }

    public func sendSmsCode(phone: String, graphicCode: String, key: String, asApp: Bool) async throws {
        let envelope = try await request(method: "POST", path: "/acc/login/code",
                                         body: ["un": phone, "authCode": graphicCode, "s": key],
                                         appType: asApp ? "1,1" : "1,5", version: asApp ? "3.1.9" : "2.0.83")
        _ = try checked(envelope)
    }

    public func login(phone: String, smsCode: String, asApp: Bool) async throws -> (token: String, uid: String?, eid: String?) {
        let envelope: Envelope
        if asApp {
            let sign = Self.signAppLogin(phone: phone, smsCode: smsCode)
            envelope = try await request(method: "POST", path: "/acc/login?sign=\(sign)",
                                         body: ["authCode": smsCode, "un": phone],
                                         appType: "1,1", version: "3.1.9")
        } else {
            envelope = try await request(method: "POST", path: "/acc/login",
                                         body: ["authCode": smsCode, "un": phone, "openCode": "", "cid": Self.clientId],
                                         appType: "1,5", version: "2.0.83")
        }
        let data = try checked(envelope)
        guard let dict = data as? [String: Any], let al = dict["al"] as? [String: Any],
              let token = stringValue(al["token"]) else { throw NativeAPIError.invalidResponse }
        return (token, stringValue(al["uid"]), stringValue(al["eid"]))
    }

    // MARK: Account / business (all read-only except device start/stop/favorite)
    public func viewInfo(token: String, asApp: Bool) async throws -> [String: Any] {
        let envelope = try await request(method: "GET", path: "/acc/view-info", token: token,
                                         appType: asApp ? "1,1" : "1,5", version: asApp ? "3.1.9" : "2.0.83")
        let data = try checked(envelope)
        guard let dict = data as? [String: Any] else { throw NativeAPIError.decoding }
        return dict
    }

    public static func uid(from info: [String: Any]) -> String? {
        for key in ["id", "uid"] { if let value = info[key] as? String, !value.isEmpty { return value } }
        if let number = info["id"] as? NSNumber { return number.stringValue }
        return nil
    }

    public func accountStat(appToken: String, uid: String) async throws -> Int {
        let sign = Self.signApp(adId: "", token: appToken, uid: uid, serverMillis: serverNowMillis())
        let envelope = try await request(method: "GET", path: "/acc/stat?sign=\(sign)", token: appToken,
                                         appType: "1,1", version: "3.1.9")
        return envelope.code
    }

    public func wallets(appToken: String) async throws -> [Life798Wallet] {
        let envelope = try await request(method: "GET", path: "/acc/wallet/owner", token: appToken,
                                         appType: "1,1", version: "3.1.9")
        let data = try checked(envelope)
        guard let dict = data as? [String: Any] else { throw NativeAPIError.decoding }
        var entries: [[String: Any]] = []
        if let main = dict["aw"] as? [String: Any] { entries.append(main) }
        if let eps = dict["eps"] as? [[String: Any]] { entries.append(contentsOf: eps) }
        var seen = Set<String>()
        return entries.compactMap { entry in
            guard let ep = entry["ep"] as? [String: Any], let owner = entry["owner"] as? [String: Any],
                  let endpointId = stringValue(ep["id"]), let ownerId = stringValue(owner["id"]) else { return nil }
            let balance = doubleValue(entry["total"]) ?? doubleValue(entry["olCash"]) ?? doubleValue(entry["balance"]) ?? 0
            let wallet = Life798Wallet(endpointId: endpointId, name: stringValue(ep["name"]) ?? "", ownerId: ownerId, balance: balance)
            return seen.insert(endpointId + "|" + ownerId).inserted ? wallet : nil
        }
    }

    public func devices(appToken: String) async throws -> [Life798Device] {
        let envelope = try await request(method: "GET", path: "/ui/app/master", token: appToken,
                                         appType: "1,1", version: "3.1.9")
        let data = try checked(envelope)
        guard let dict = data as? [String: Any], let favos = dict["favos"] as? [[String: Any]] else { return [] }
        return favos.compactMap { entry in
            guard let id = stringValue(entry["id"]) else { return nil }
            return Life798Device(id: id, name: stringValue(entry["name"]) ?? "")
        }
    }

    public func bills(appToken: String, page: Int = 0) async throws -> [Life798Bill] {
        let envelope = try await request(method: "GET", path: "/bill/lst-owner?page=\(page)&size=20", token: appToken,
                                         appType: "1,1", version: "3.1.9")
        let data = try checked(envelope)
        var records: [[String: Any]] = []
        if let array = data as? [[String: Any]] { records = array }
        else if let dict = data as? [String: Any] {
            for key in ["records", "items", "list", "content"] {
                if let array = dict[key] as? [[String: Any]] { records = array; break }
            }
        }
        return records.map { record in
            var created: Date?
            if let raw = doubleValue(record["ctime"]) ?? doubleValue(record["utime"]) {
                created = Date(timeIntervalSince1970: raw < 1e10 ? raw : raw / 1000)
            }
            var deviceId = stringValue(record["did"]) ?? stringValue(record["deviceId"])
            if let dev = record["dev"] as? [String: Any] { deviceId = deviceId ?? stringValue(dev["id"]) }
            return Life798Bill(id: stringValue(record["id"]) ?? stringValue(record["sn"]) ?? "",
                               type: intValue(record["type"]), status: intValue(record["status"]),
                               payment: doubleValue(record["payment"]), createdAt: created, deviceId: deviceId)
        }
    }

    public func deviceStart(appToken: String, did: String) async throws -> (code: Int, message: String) {
        let encoded = did.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? did
        let envelope = try await request(method: "GET", path: "/dev/start?did=\(encoded)&upgrade=true&ptype=91&rcp=false",
                                         token: appToken, appType: "1,1", version: "3.1.9")
        return (envelope.code, envelope.message)
    }

    public func deviceEnd(appToken: String, did: String) async throws -> (code: Int, message: String) {
        let encoded = did.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? did
        let envelope = try await request(method: "GET", path: "/dev/end?did=\(encoded)&rcp=false",
                                         token: appToken, appType: "1,1", version: "3.1.9")
        return (envelope.code, envelope.message)
    }

    public static func deviceMessage(code: Int, message: String) -> String {
        switch code {
        case 0: return "已启动，请在设备上按实体按钮选水温出水。"
        case -99: return "登录已失效，请重新登录。"
        case -21: return "设备登录信息未被接受，请确认已完成设备端登录。"
        case -88: return "未签约代扣协议，请先在原 App 完成签约。"
        case -87: return "签约已过期，请重新签约。"
        case -52: return "账户欠费，请充值后使用。"
        case -20: return "未绑定一卡通账号，请先完成账户绑定。"
        case -19: return "设备准备中，请稍后。"
        case -82: return "需要支付。"
        default: return message.isEmpty ? "服务器返回 code=\(code)" : message
        }
    }

    // DeviceIdParser.normalize, condensed port (spec section 6.1).
    public static func normalizeDeviceID(_ raw: String) -> String {
        var value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if let decoded = value.removingPercentEncoding { value = decoded }
        if let match = value.range(of: #"(?:did|deviceId|device_id|id)\s*[=:]\s*"?([A-Za-z0-9_-]{4,64})"#, options: .regularExpression) {
            let text = String(value[match])
            if let split = text.lastIndex(of: text.contains("=") ? "=" : ":") {
                return String(text[text.index(after: split)...]).trimmingCharacters(in: CharacterSet(charactersIn: "\"'"))
            }
        }
        if let components = URLComponents(string: value), let host = components.host?.lowercased() {
            let segments = components.path.split(separator: "/").map(String.init)
            if host == "hnkzy.com" || host.hasSuffix(".hnkzy.com") {
                for segment in segments.reversed() where segment.range(of: #"^\d{8,32}$"#, options: .regularExpression) != nil {
                    return segment
                }
            }
            if let last = segments.last { return last }
        }
        if value.lowercased().hasPrefix("did:") { value = String(value.dropFirst(4)) }
        return String(value.prefix(160))
    }
}

public final class Life798Service: PlatformService, @unchecked Sendable {
    public let provider: NativeProvider = .life798
    public var isAuthorized: Bool { true }
    public let client = Life798Client()
    private var pendingPhone: String?
    private var pendingKey: String?
    private var pendingStage = 0

    public init() {}

    public func beginLogin(account: NativeAccount, input: NativeLoginInput) async throws -> NativeLoginOutcome {
        guard case .phoneChallenge(let phone) = input else { throw NativeAPIError.invalidResponse }
        let trimmed = phone.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw NativeAPIError.invalidResponse }
        pendingPhone = trimmed
        pendingKey = Life798Client.newCaptchaKey()
        pendingStage = 1
        return .challengeRequired(reference: pendingKey!)
    }

    public func completeLogin(account: NativeAccount, challenge: String, response: String) async throws -> NativeLoginOutcome {
        guard let phone = pendingPhone, let key = pendingKey else { throw NativeAPIError.invalidResponse }
        if pendingStage == 1 {
            try await client.sendSmsCode(phone: phone, graphicCode: response, key: key, asApp: true)
            pendingStage = 2
            return .challengeRequired(reference: key + ":sms")
        }
        let app = try await client.login(phone: phone, smsCode: response, asApp: true)
        var session = Life798Session(phone: phone, mainToken: nil, appToken: app.token, uid: app.uid, eid: app.eid)
        if let main = try? await client.login(phone: phone, smsCode: response, asApp: false) {
            session.mainToken = main.token
            if session.uid == nil { session.uid = main.uid }
            if session.eid == nil { session.eid = main.eid }
        }
        if session.uid == nil, let token = session.appToken,
           let info = try? await client.viewInfo(token: token, asApp: true) {
            session.uid = Life798Client.uid(from: info)
        }
        try await session.save(account: account)
        pendingStage = 0
        return .authenticated
    }

    public func sessionStatus(account: NativeAccount) async throws -> NativeSessionState {
        guard let session = await Life798Session.load(account: account),
              session.mainToken != nil || session.appToken != nil else { return .signedOut }
        if let appToken = session.appToken {
            var uid = session.uid
            if uid == nil, let info = try? await client.viewInfo(token: appToken, asApp: true) {
                uid = Life798Client.uid(from: info)
            }
            if let uid {
                do { return try await client.accountStat(appToken: appToken, uid: uid) == -99 ? .expired : .valid }
                catch { return .valid }
            }
            return .valid
        }
        if let mainToken = session.mainToken {
            do {
                _ = try await client.viewInfo(token: mainToken, asApp: false)
                return .valid
            } catch let error as Life798ServerError {
                return error.code == -99 ? .expired : .valid
            } catch { return .valid }
        }
        return .signedOut
    }

    public func signOut(account: NativeAccount) async throws {
        await Life798Session.clear(account: account)
    }
}
