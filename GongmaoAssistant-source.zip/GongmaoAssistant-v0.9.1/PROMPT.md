# v0.8.9 Build 22 构建交接
先阅读 BUILD_HANDOFF.md。保持主 App 及 Widget 扩展，先进行实际 SDK 编译；当前在线认证仍不可用。

# Muse / Xcode 工程交接（v0.8.7）
导入 CampusOne.xcodeproj，不转换为网页套壳。保留工贸助手原版蓝金 iOS Liquid Glass UI、iOS 15 最低部署目标、iOS 27 待 SDK 验收、四个原生平台目录及独立自定义网页。原生平台不以 H5、小程序或外部 App 跳转代替登录。
NativeCore 是单独可测试 Swift Package；同一 Swift 文件已列入主 Target，不需另加同名 package 依赖。NativeRegistry 四家默认拒绝，当前无正式授权接口。只在获得文档和书面授权之后实现对应 adapter，禁止模拟认证、猜测私有签名、伪造身份/位置、模拟余额订单或设备状态。
依据 Documentation/RELEASE_080.md、RELEASE_070.md、UI_REVIEW.md 配置真实 bundle ID、App Group、主应用及 CampusWidgets 扩展签名；使用支持 iOS 26 API 的 SDK 编译，不删功能逃避错误。验证 iOS 15/16 回退、原生账号页面、独立自定义网页、扫码、课表、桌面/锁屏小组件、ActivityKit、控制中心、快捷指令、Face ID、提醒及备份恢复。真实第三方业务必须单独联调。通过编译签名才可生成 IPA；Muse 不支持原生工程或扩展时改用兼容 Xcode 环境。

先读 Documentation/RELEASE_081.md。原版平台图标须获使用与分发许可后方可通过 Tools/import_provider_icons.py 导入；不得复制厂商 AppID、支付商户号、Weex 源码。U净五类设备目录为待授权功能，不可宣称已接通。

第四阶段验收：校验二维码候选分流和敏感码拦截；教务表单仅合成示例，不提交；U净目录不等于功能接通；慧生活798验证码步骤仅展示。不得把待授权接口视为已完成。

第六阶段补充：先阅读 Documentation/RELEASE_086.md。验收新增教务字段离线导入，确认实际学校作息、学期、单双周、不连续周次及导入去重；检查四平台状态和 App/Widget Build 19。不得把离线导入视为原生在线登录或真实接口接通。

第七版增量：阅读 Documentation/RELEASE_087.md。App/Widget Build 20。真机验证扫码手电筒、离开页面关闭照明、前后台切换；验证 Keychain 账号隔离。会话和操作日志目前为待接入的通用组件，不能标记真实登录或支付通过。
