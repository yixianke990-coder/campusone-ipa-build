import SwiftUI
import WebKit

// Merged module added in v0.9.0: Xiqueer + Life798 in one in-app entry.
// Entry URLs are the public H5 entries recovered from the official Android
// packages on 2026-11-27:
//   Xiqueer  com.kingosoft.activity_kb_common  https://mobile.xiqueer.com/h5/menu?code=KINGO_TEA_2026
//   Life798  com.cloudora.android              https://cloud.hnkzy.com/h5/index.html (in-app H5, loaded after native login in the original app)
//            Device QR entries live on https://i.ilife798.com/q/... and need a real device code.
// Login happens on the official sites inside the web view. This app does not
// read form contents, passwords or verification codes. Native-only features
// (NFC, door locks, payments) still belong to the original apps / mini programs.

enum MergedEntry {
    static let xiqueer = URL(string: "https://mobile.xiqueer.com/h5/menu?code=KINGO_TEA_2026")!
    static let xiqueerSchool = URL(string: "https://www.xiqueer.com/wap/h5/index.html")!
    static let life798 = URL(string: "https://cloud.hnkzy.com/h5/index.html")!
}

struct MergedAppsView: View {
    @EnvironmentObject private var store: CampusStore
    private var xiqueerService: Service? { store.services.first { $0.storeID == "1152127141" } }
    private var lifeService: Service? { store.services.first { $0.storeID == "1490809012" } }
    var body: some View {
        List {
            Section("二合一 · 一个 App 两个平台") {
                Text("喜鹊儿（课表/教务）和慧生活798（生活/设备）已合并到本页，在 App 内直接打开，不用再装两个 App 来回切。登录在官方页面里完成，工贸助手不读取账号密码。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("喜鹊儿 · 教务") {
                NavigationLink { MergedWebPage(title: "喜鹊儿", url: MergedEntry.xiqueer) } label: {
                    Label("在 App 内打开喜鹊儿", systemImage: "calendar")
                }
                NavigationLink { MergedWebPage(title: "喜鹊儿 · 选学校", url: MergedEntry.xiqueerSchool) } label: {
                    Label("选学校 / 教务登录入口", systemImage: "building.2")
                }
                if let service = xiqueerService {
                    NavigationLink { AcademicCenter(service: service) } label: {
                        Label("教务中心（本地功能目录）", systemImage: "graduationcap")
                    }
                    NavigationLink { CoursesView() } label: {
                        Label("我的课表（本地）", systemImage: "list.bullet.rectangle")
                    }
                    if let storeURL = service.storeURL {
                        Link("原 App · 喜鹊儿（App Store）", destination: storeURL)
                    }
                }
            }
            Section("慧生活798 · 生活") {
                NavigationLink { MergedWebPage(title: "慧生活798", url: MergedEntry.life798) } label: {
                    Label("在 App 内打开慧生活798", systemImage: "shower")
                }
                if let service = lifeService {
                    NavigationLink { BathCenter(service: service) } label: {
                        Label("设备中心（本地功能）", systemImage: "square.grid.2x2")
                    }
                    if let storeURL = service.storeURL {
                        Link("原 App · 慧生活798（App Store）", destination: storeURL)
                    }
                }
                Text("提醒：慧生活这个 H5 在原 App 里是登录后才打开的，在这里可能要求先登录或跳回登录页；NFC、门锁、支付是原生功能，网页里用不了，这类操作请用原 App，或在支付宝搜索「慧生活798」小程序。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }.listStyle(.insetGrouped).navigationTitle("二合一")
    }
}

@MainActor private final class MergedBrowser: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    @Published var host: String
    @Published var loading = true
    @Published var canGoBack = false
    @Published var message = ""
    let webView: WKWebView
    init(url: URL) {
        host = url.host ?? ""
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.load(URLRequest(url: url))
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url, url.scheme?.lowercased() == "https" else {
            message = "已阻止非 HTTPS 或外部 App 链接。可返回上一页，或改用原 App。"
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url, url.scheme?.lowercased() == "https" {
            webView.load(navigationAction.request)
        }
        return nil
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { loading = true; message = "" }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) { host = webView.url?.host ?? ""; canGoBack = webView.canGoBack }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { loading = false; host = webView.url?.host ?? ""; canGoBack = webView.canGoBack }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { failed(error) }
    private func failed(_ error: Error) {
        loading = false
        if (error as NSError).code != NSURLErrorCancelled {
            message = "网页加载失败。请检查网络后刷新；若官方入口变更或要求原 App 登录，请改用原 App。"
        }
    }
}

private struct MergedWebContent: UIViewRepresentable {
    let view: WKWebView
    func makeUIView(context: Context) -> WKWebView { view }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

@MainActor struct MergedWebPage: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @StateObject private var browser: MergedBrowser
    let title: String
    let entry: URL
    init(title: String, url: URL) {
        self.title = title
        self.entry = url
        _browser = StateObject(wrappedValue: MergedBrowser(url: url))
    }
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: "lock.shield")
                Text(browser.host).font(.caption.monospaced()).textSelection(.enabled)
                Spacer()
            }.padding(12).background(.thinMaterial)
            if browser.loading { ProgressView("正在打开官方页面…").font(.caption).frame(maxWidth: .infinity).padding(8) }
            if !browser.message.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Label(browser.message, systemImage: "exclamationmark.circle").font(.footnote)
                    Button("重新加载") { browser.webView.reload() }.buttonStyle(.bordered)
                }.frame(maxWidth: .infinity, alignment: .leading).padding(12).background(Color.orange.opacity(0.10))
            }
            MergedWebContent(view: browser.webView)
        }.navigationTitle(title).navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .primaryAction) {
                    Button("后退", campusIcon: "chevron.backward") { browser.webView.goBack() }.disabled(!browser.canGoBack)
                    Button("刷新", campusIcon: "arrow.clockwise") { browser.webView.reload() }
                    Button("浏览器打开", campusIcon: "safari") { openURL(entry) }
                }
            }
    }
}
