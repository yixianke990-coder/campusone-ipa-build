import SwiftUI
import WebKit
import UIKit

struct ServicesView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var add = false
    var body: some View {
        List {
            Section { HStack { FeatureIcon(symbol: "square.grid.2x2", size: 50); VStack(alignment: .leading, spacing: 4) { Text("校园服务中心").font(.headline); Text("已启用 \(store.services.filter(\.enabled).count) 项服务").font(.caption).foregroundStyle(.secondary) }; Spacer() } }
            Section("二合一") {
                NavigationLink { MergedAppsView() } label: {
                    HStack { FeatureRow(title: "喜鹊儿 + 慧生活798", subtitle: "一个 App 内打开两个平台", color: .blue) }
                }
            }
            Section("我的服务") {
                ForEach(store.services) { service in
                    NavigationLink { ServiceDetail(id: service.id) } label: {
                        HStack { ServiceRow(service: service); if !service.enabled { Text("已停用").font(.caption).foregroundStyle(.secondary) } }
                    }
                }.onMove { store.services.move(fromOffsets: $0, toOffset: $1) }
            }
            Section { Button("添加自定义网页", campusIcon: "plus") { add = true } }
            Section { Text("内置四平台采用原生适配架构；未获授权的业务保持禁用。自定义网页独立运行。") .font(.footnote).foregroundStyle(.secondary) }
        }.listStyle(.insetGrouped).navigationTitle("服务").toolbar { EditButton(); Button("添加", campusIcon: "plus") { add = true } }
            .sheet(isPresented: $add) { CampusNavigation { ServiceEditor(service: Service(name: "", category: "网页", symbol: "globe", tint: "green")) } }
    }
}

struct ServiceDetail: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.openURL) private var openURL
    @Environment(\.dismiss) private var dismiss
    let id: UUID
    @State private var edit = false
    @State private var account = false
    @State private var remove = false
    @State private var scan = false
    @State private var message: String?
    var body: some View {
        Group {
            if let service = store.services.first(where: { $0.id == id }) {
                List {
                    Section { CampusProviderHeader(service: service, subtitle: service.category, status: !service.enabled ? "已停用" : service.isBuiltIn ? "业务待接入" : "网页服务 · 已启用") }
                    if service.isBuiltIn && service.storeID != "1152127141" {
                        Section("常用操作") {
                            Button { scan = true } label: { FeatureRow(title: "扫码设备", subtitle: "识别后确认平台", color: service.color) }
                            NavigationLink { DeviceList(service: service) } label: { FeatureRow(title: "常用设备", subtitle: "本地收藏", color: service.color) }
                            NavigationLink { TimerList(service: service) } label: { FeatureRow(title: "使用计时", subtitle: "本地提醒，不连接设备", color: service.color) }
                        }
                    }
                    if let provider = service.nativeProvider {
                        Section("账号登录") {
                            NavigationLink { AccountAccessView(service: service) } label: { FeatureRow(title: "登录与账号管理", subtitle: provider.loginMethod, color: service.color) }
                            DisclosureGroup("查看接入状态") { Text(provider.blocker).font(.footnote).foregroundStyle(.secondary); Phase6StatusRows(provider: provider) }
                        }
                    } else if !service.isBuiltIn {
                        Section("打开网页服务") {
                            if let url = WebLoginRules.entryURL(service.url) {
                                if !service.externalBrowser {
                                    NavigationLink { AccountAccessView(service: service) } label: { Label("应用内网页与登录", systemImage: "globe") }.disabled(!service.enabled)
                                }
                                Button("在系统浏览器打开", campusIcon: "arrow.up.forward.app") { openURL(url) { accepted in if !accepted { message = "无法打开该链接。" } } }.disabled(!service.enabled)
                            }
                        }
                    }
                    Section("独立账号") {
                        if !service.isBuiltIn { NavigationLink { AccountAccessView(service: service) } label: { Label("独立网页登录与会话", systemImage: "person.crop.circle") } }
                        Button("管理本地账号备注", campusIcon: "note.text") { account = true }
                        Text(service.isBuiltIn ? "原生接口未授权；本地账号配置不代表真实登录。" : "网页登录由原网站完成，各账号会话隔离。") .font(.footnote).foregroundStyle(.secondary)
                    }
                    if service.storeID == "1152127141" {
                        Section("教务中心") { NavigationLink { AcademicCenter(service: service) } label: { FeatureRow(title: "全部学业服务", subtitle: "成绩、考试、选课等", color: service.color) }; NavigationLink { CoursesView() } label: { FeatureRow(title: "我的课表", subtitle: "本地与授权在线课表", color: service.color) } }
                    }
                    if service.nativeProvider == .ujing {
                        Section("U净 · 业务规格") {
                            NavigationLink { UjingPhase4Catalog(service: service) } label: { Label("页面功能索引（待接入）", systemImage: "list.bullet.rectangle") }
                        }
                    }
                    if let evidence = ProviderEvidence.forService(service) {
                        Section("平台功能与接入情况") {
                            NavigationLink { EvidenceCenter(service: service, evidence: evidence) } label: { Label("功能中心与兼容性", systemImage: service.symbol) }
                        }
                    }
                    if service.isBuiltIn { ProviderTools(service: service) }
                    Section("服务设置") {
                        CampusValueRow("状态", value: service.enabled ? "已启用" : "已停用")
                        CampusValueRow("首页显示", value: service.showOnHome ? "是" : "否")
                        CampusValueRow("扫码规则", value: Routing.normalizedHosts(service.hosts).isEmpty ? "未配置" : "\(Routing.normalizedHosts(service.hosts).count) 个域名")
                        Button("编辑服务", campusIcon: "slider.horizontal.3") { edit = true }
                        if !service.isBuiltIn { Button("删除网页服务", role: .destructive) { remove = true } }
                    }
                }.listStyle(.insetGrouped).navigationTitle(service.name).navigationBarTitleDisplayMode(.inline)
                    .sheet(isPresented: $edit) { CampusNavigation { ServiceEditor(service: service) } }
                    .sheet(isPresented: $account) { CampusNavigation { AccountEditor(service: service) } }
                    .sheet(isPresented: $scan) { CampusNavigation { ScanView() } }
                    .confirmationDialog("删除本地服务及账号备注？", isPresented: $remove, titleVisibility: .visible) {
                        Button("删除", role: .destructive) {
                            if store.webAccounts.contains(where: { $0.serviceID == id }) { message = "请先在独立网页登录与会话中删除全部网页登录配置及数据。" }
                            else if AccountVault.write("", id: id) { store.remove(service); dismiss() }
                            else { message = "无法清除账号备注，服务未删除。" }
                        }
                    } message: { Text("不会删除原平台账号或网页浏览会话。") }
                    .alert("提示", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) { Button("确定") { message = nil } } message: { Text(message ?? "") }
            } else { CampusEmptyState("服务不存在", systemImage: "exclamationmark.circle") }
        }
    }
}

struct ServiceEditor: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State var service: Service
    @State private var error: String?
    private let icons = ["globe", "clipboard", "calendar", "book", "creditcard", "graduationcap", "building.2", "link"]
    var body: some View {
        Form {
            Section { HStack { ServiceIcon(service: service); VStack(alignment: .leading, spacing: 4) { Text(service.name.isEmpty ? "新服务" : service.name).font(.headline); Text(service.category).font(.caption).foregroundStyle(.secondary) } } }
            Section("基本信息") {
                TextField("服务名称", text: $service.name).disabled(service.isBuiltIn)
                TextField("服务分类", text: $service.category)
                if !service.isBuiltIn { Picker("图标", selection: $service.symbol) { ForEach(icons, id: \.self) { Label($0, systemImage: $0).tag($0) } } }
                Toggle("启用服务", isOn: $service.enabled)
                Toggle("显示在首页", isOn: $service.showOnHome)
            }
            if !service.isBuiltIn {
                Section {
                    TextField("https://…", text: $service.url).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Toggle("使用系统浏览器", isOn: $service.externalBrowser)
                } header: { Text("网页链接（必填）") } footer: { Text("仅接受稳定 HTTPS 链接，不包含登录码、票据、密码或令牌。") }
            } else {
                Section("接入模式") { Text("原生客户端 · 不使用网页套壳").foregroundStyle(.secondary) }
            }
            Section {
                CampusMultiline(title: "每行一个域名", text: $service.hosts).textInputAutocapitalization(.never).autocorrectionDisabled()
            } header: { Text("二维码域名规则（可选）") } footer: { Text("只填写已验证属于该服务商的设备二维码域名，可用空格或逗号分隔。不支持通配符；相同域名出现于多个服务时要求手动选择。") }
        }.navigationTitle("服务配置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("保存", action: save) } }
            .alert("配置有误", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("确定") { error = nil } } message: { Text(error ?? "") }
    }
    private func save() {
        service.name = service.name.trimmingCharacters(in: .whitespacesAndNewlines)
        service.category = service.category.trimmingCharacters(in: .whitespacesAndNewlines)
        service.url = service.url.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !service.name.isEmpty, !service.category.isEmpty else { error = "请填写名称和分类。"; return }
        if !service.isBuiltIn {
            guard let url = WebLoginRules.entryURL(service.url) else { error = "请填写稳定的 HTTPS 链接，不含临时认证参数或片段。"; return }
            let sensitive = ["code", "ticket", "token", "access_token", "id_token", "password", "session", "sessionid", "sso_ticket", "auth_code"]
            if URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.contains(where: { sensitive.contains($0.name.lowercased()) }) == true {
                error = "链接含可能用于登录的一次性参数，请填写稳定的服务入口。"; return
            }
        }
        let rawHosts = service.hosts.split(whereSeparator: { $0.isWhitespace || $0 == "," || $0 == "，" })
        let hosts = Routing.normalizedHosts(service.hosts)
        guard rawHosts.count == hosts.count else { error = "二维码规则只能填写完整域名，不可包含路径或通配符。"; return }
        service.hosts = hosts.joined(separator: ", ")
        store.save(service); dismiss()
    }
}

struct AccountEditor: View {
    @Environment(\.dismiss) private var dismiss
    let service: Service
    @State private var label = ""
    @State private var error = false
    var body: some View {
        Form {
            Section(service.name) {
                TextField("账号备注（如手机号后四位）", text: $label).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("清除本地备注", role: .destructive) { if AccountVault.write("", id: service.id) { label = ""; dismiss() } else { error = true } }
            }
            Section { Text("备注独立加密保存在本机 Keychain。请不要输入密码、验证码或令牌。备注不代表已登录；切换真实账号请前往原平台。") .foregroundStyle(.secondary) }
        }.navigationTitle("账号与授权").navigationBarTitleDisplayMode(.inline)
            .onAppear { label = AccountVault.read(service.id) }
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("保存") { if AccountVault.write(label.trimmingCharacters(in: .whitespacesAndNewlines), id: service.id) { dismiss() } else { error = true } } } }
            .alert("Keychain 保存失败", isPresented: $error) { Button("确定", role: .cancel) {} }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: CampusStore
    @AppStorage("appearance") private var appearance = "system"
    var body: some View {
        List {
            Section { HStack(spacing: 14) { FeatureIcon(symbol: "person.crop.circle.fill", size: 60); VStack(alignment: .leading, spacing: 5) { Text("我的工贸助手").font(.title3.bold()); Text("本地配置 · 各平台独立授权").font(.caption).foregroundStyle(.secondary) }; Spacer() } }
            Section("各平台独立账号") {
                ForEach(store.services) { service in
                    NavigationLink { AccountAccessView(service: service) } label: { ServiceRow(service: service) }
                }
            }
            Section("外观") { Picker("显示模式", selection: $appearance) { Text("跟随系统").tag("system"); Text("浅色").tag("light"); Text("深色").tag("dark") } }
            Section("服务与隐私") {
                NavigationLink("服务管理") { ServicesView() }
                NavigationLink("安全与系统集成") { CampusSystemSettings() }
                NavigationLink("备份与恢复") { CampusBackupView() }
                NavigationLink("隐私与使用说明") {
                    List {
                        Section("数据") { Text("服务配置、手动课表、设备收藏、手动消费及计时记录保存在本机；账号备注保存在 Keychain。内置平台使用独立原生账号备注，暂不保存真实登录凭证。自定义网页登录配置保存在本机；iOS 17+ 支持独立持久网站会话，iOS 15–16 仅临时会话。本版本不向 工贸助手 服务器上传数据，也不保存扫码历史。") }
                        Section("第三方服务") { Text("打开原服务时，其登录、支付、数据处理及网页会话遵循各服务商的规则。应用内 WebKit 按账号隔离网站数据；外部浏览器与原 App 的登录由对应应用管理。") }
                        Section("安全") { Text("二维码只做本地识别，不自动打开链接、不自动启动设备、不自动支付。请核对目标平台和设备。") }
                    }.navigationTitle("隐私与使用说明")
                }
            }
            Section("关于") { CampusValueRow("版本", value: "0.9.0 · 喜鹊儿+慧生活二合一"); CampusValueRow("系统", value: UIDevice.current.systemVersion); CampusValueRow("兼容目标", value: "iOS 15–27"); Text("独立校园服务聚合工具，非任何学校或服务商官方产品。无自有广告。") .font(.footnote).foregroundStyle(.secondary) }
        }.listStyle(.insetGrouped).navigationTitle("设置")
    }
}

// The catalog reflects the supplied screenshots; unsupported features never present fake results.
struct AcademicCenter: View {
    let service: Service
    @State private var search = ""
    static let groups: [(String, [String])] = [
        ("学籍", ["增改基本信息", "学期报到", "异动申请"]),
        ("培养方案", ["查看培养方案"]),
        ("选课", ["预选", "预选结果", "正选", "正选结果", "退选"]),
        ("重修", ["重修选", "重修选结果", "重修申请", "重修查询"]),
        ("考试", ["资格考试报名", "考试安排", "补考申请"]),
        ("评教", ["学生评教"]), ("成绩", ["学业成绩", "免修申请"]),
        ("学业", ["学业进展"]), ("教材", ["确认需要教材", "教材对账"]),
        ("课表", ["教室课表"]),
        ("其他", ["校历查询", "蹭课", "资格考试成绩", "空闲教室", "请假登记", "提交作业", "缺勤信息", "课堂表现", "班级课表", "学情警示", "上课签到", "课堂练习", "问卷调查", "校园卡", "消息通知", "报修", "个人信息", "账号安全"])
    ]
    var body: some View {
        List {
            Section("已编写的本地功能") {
                NavigationLink { CoursesView() } label: { Label("我的课表与在线同步", systemImage: "calendar") }
                NavigationLink { AcademicFormPreview() } label: { Label("教务动态表单 · 本地演示", systemImage: "list.bullet.rectangle") }
                NavigationLink { TermSettings() } label: { Label("学期及教学周设置", systemImage: "calendar.badge.clock") }
                NavigationLink { AccountAccessView(service: service) } label: { Label("原生账号与授权", systemImage: "person.crop.circle") }
            }
            Section { Text("以下是原平台功能目录。尚未接入原生教务 API，所有未授权在线操作保持禁用，不自动打开网页。") .font(.footnote).foregroundStyle(.secondary) }
            ForEach(Self.groups.indices, id: \.self) { index in
                let group = Self.groups[index]
                let items = group.1.filter { search.isEmpty || $0.localizedCaseInsensitiveContains(search) || group.0.contains(search) }
                if !items.isEmpty {
                    Section(group.0) { ForEach(items, id: \.self) { title in
                        NavigationLink { OfficialFeature(service: service, title: title) } label: { FeatureRow(title: title, subtitle: "原生业务 · 待授权", color: service.color) }
                    } }
                }
            }
        }.navigationTitle("喜鹊儿 · 教务中心").searchable(text: $search, prompt: "搜索学业服务")
    }
}
struct BathCenter: View {
    let service: Service
    @State private var scan = false
    private let official = ["钱包与余额", "充值", "卡包", "卡密激活", "卡券", "我的账单", "添加设备", "我的工单", "常见问题", "在线客服"]
    var body: some View {
        List {
            Section("澡堂") {
                Button("扫描设备二维码", campusIcon: "qrcode.viewfinder") { scan = true }
                NavigationLink { OfficialFeature(service: service, title: "淋浴设备启停") } label: { Label("淋浴设备启停（待授权）", systemImage: "shower") }
                NavigationLink { DeviceList(service: service) } label: { Label("常用设备收藏", systemImage: "star") }
                NavigationLink { TimerList(service: service) } label: { Label("洗澡计时及通知（本地）", systemImage: "timer") }
                Text("本地扫码不会自动启动设备或扣费，计时不等于官方订单。") .font(.footnote).foregroundStyle(.secondary)
            }
            Section("账户与账单") {
                NavigationLink { AccountAccessView(service: service) } label: { Label("原生账号与授权", systemImage: "person.crop.circle") }
                NavigationLink { ExpensesView(service: service) } label: { Label("手动消费记录与统计", systemImage: "chart.bar") }
                ForEach(official, id: \.self) { title in NavigationLink { OfficialFeature(service: service, title: title) } label: { Text(title) } }
            }
        }.navigationTitle("慧生活798 · 设备中心")
            .sheet(isPresented: $scan) { CampusNavigation { ScanView() } }
    }
}
struct OfficialFeature: View {
    let service: Service
    let title: String
    var body: some View {
        List {
            Section { HStack(spacing: 14) { FeatureIcon(symbol: FeatureSymbols.icon(title), color: service.color, size: 58); VStack(alignment: .leading, spacing: 5) { Text(title).font(.title2.bold()); Text(service.name).font(.subheadline).foregroundStyle(.secondary) }; Spacer(minLength: 0) }.padding(.vertical, 10) }
            Section("原生业务状态") {
                CampusStatusLabel(text: "业务待接入", symbol: "clock")
                if let provider = service.nativeProvider { Text(provider.blocker).font(.footnote).foregroundStyle(.secondary) }
                Text("该功能目前没有授权的业务适配器。不发送请求、不展示虚假数据，也不自动打开网页。") .font(.footnote).foregroundStyle(.secondary)
                Button("执行\(title)", campusIcon: "lock") {}.disabled(true)
                NavigationLink { AccountAccessView(service: service) } label: { Label("原生账号与授权", systemImage: "person.badge.key") }
            }
        }.navigationTitle(title)
    }
}

struct EvidenceCenter: View {
    let service: Service
    let evidence: ProviderEvidence
    @State private var search = ""
    @State private var scan = false
    var body: some View {
        List {
            Section("接入说明") {
                DisclosureGroup("查看技术依据") {
                CampusValueRow("Android 参考版本", value: evidence.version)
                if let version = service.iosEvidenceVersion { CampusValueRow("iOS 参考版本", value: version) }
                Text(evidence.summary)
                Text(evidence.blocker).font(.footnote).foregroundStyle(.secondary)
                Label("原生业务未接入 · 静态证据非运行验证", systemImage: "info.circle").font(.footnote)
                }
            }
            Section("本地功能") {
                NavigationLink { AccountAccessView(service: service) } label: { Label("原生账号与授权", systemImage: "person.crop.circle") }
                if service.storeID == "1152127141" {
                    NavigationLink { AcademicCenter(service: service) } label: { Label("教务功能目录", systemImage: "graduationcap") }
                    NavigationLink { CoursesView() } label: { Label("课表及授权在线同步", systemImage: "calendar") }
                } else {
                    Button("扫描设备二维码", campusIcon: "qrcode.viewfinder") { scan = true }
                    NavigationLink { DeviceList(service: service) } label: { Label("常用设备收藏", systemImage: "star") }
                    NavigationLink { TimerList(service: service) } label: { Label("本地计时及通知", systemImage: "timer") }
                    NavigationLink { ExpensesView(service: service) } label: { Label("手动消费统计", systemImage: "chart.bar") }
                }
            }
            ForEach(evidence.groups.indices, id: \.self) { index in
                let group = evidence.groups[index]
                let items = group.1.filter { search.isEmpty || $0.localizedCaseInsensitiveContains(search) || group.0.contains(search) }
                if !items.isEmpty {
                    Section(group.0) {
                        ForEach(items, id: \.self) { title in
                            NavigationLink { OfficialFeature(service: service, title: title) } label: {
                                FeatureRow(title: title, subtitle: title == "预约" && service.storeID == "1142157881" ? "是否支持待验证" : "原生业务 · 待授权", color: service.color)
                            }
                        }
                    }
                }
            }
        }.navigationTitle(service.name).searchable(text: $search, prompt: "搜索平台功能")
         .sheet(isPresented: $scan) { CampusNavigation { ScanView() } }
    }
}

struct OfficialContainerGuide: View {
    let service: Service
    @State private var copied = false
    var body: some View {
        if let keyword = service.miniProgramKeyword, let container = service.officialContainer {
            VStack(alignment: .leading, spacing: 10) {
                FeatureRow(title: "官方小程序", subtitle: "在\(container)内登录和使用设备", color: service.color)
                Text("打开\(container)，搜索「\(keyword)」，核对服务商后进入官方小程序。登录、支付及设备操作均由原平台处理。")
                    .font(.footnote).foregroundStyle(.secondary)
                Button { UIPasteboard.general.string = keyword; copied = true } label: {
                    Label(copied ? "已复制搜索名称" : "复制小程序名称", systemImage: copied ? "checkmark" : "doc.on.doc")
                }.buttonStyle(.bordered)
                Text("未配置正式 SDK 或经验证的跳转链接，本入口不直接拉起小程序。")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding(.vertical, 4)
        }
    }
}


// Synthetic fixture only, no student data or submissions. Unknown controls fail read-only.
struct AcademicFormPreview: View {
    @State private var values: [String: String] = [:]
    @State private var dates: [String: Date] = [:]
    @State private var selected = Set<String>()
    @State private var result = ""
    private static let fixture = #"{"dataset":[{"field_ctr":"1","field_lable":"申请原因","field_ywid":"reason","field_need":"1","field_editflag":"1"},{"field_ctr":"25","field_lable":"原因分类","field_ywid":"category","field_need":"1","field_editflag":"1","field_options":[{"dm":"a","mc":"个人原因"},{"dm":"b","mc":"课程冲突"},{"dm":"c","mc":"其他"}]},{"field_ctr":"74","field_lable":"申请时段","field_ywid":"range","field_editflag":"1"},{"field_ctr":"55","field_lable":"本地检查","field_ywid":"check","field_editflag":"1","field_options":[{"dm":"a","mc":"已了解规则"},{"dm":"b","mc":"已检查时间"}]},{"field_ctr":"10","field_lable":"证明材料（暂不支持）","field_ywid":"attachment","field_editflag":"0"}]}"#
    private var fields: [AcademicField] {
        guard let form = try? JSONDecoder().decode(AcademicFixture.self, from: Data(Self.fixture.utf8)), form.valid() else { return [] }
        return form.dataset
    }
    private func text(_ id: String) -> Binding<String> { Binding(get: { values[id] ?? "" }, set: { values[id] = $0 }) }
    private func date(_ id: String) -> Binding<Date> { Binding(get: { dates[id] ?? Date() }, set: { dates[id] = $0 }) }
    @ViewBuilder private func fieldView(_ field: AcademicField) -> some View {
        if !field.editable { Label(field.field_lable, systemImage: "lock.shield") }
        else {
            switch field.kind {
            case .text: TextField(field.field_lable + (field.required ? " *" : ""), text: text(field.field_ywid))
            case .choice:
                Picker(field.field_lable, selection: text(field.field_ywid)) {
                    Text("请选择").tag("")
                    ForEach(field.options, id: \.dm) { Text($0.mc).tag($0.dm) }
                }
            case .multiChoice:
                ForEach(field.options, id: \.dm) { option in
                    let key = field.field_ywid + ":" + option.dm
                    Toggle(option.mc, isOn: Binding(get: { selected.contains(key) }, set: { enabled in if enabled { selected.insert(key) } else { selected.remove(key) } }))
                }
            case .timeRange:
                DatePicker("开始时间", selection: date(field.field_ywid + ".start"))
                DatePicker("结束时间", selection: date(field.field_ywid + ".end"))
            case .readOnly: Label(field.field_lable, systemImage: "lock.shield")
            }
        }
    }
    var body: some View {
        Form {
            Section("本地演示 · 非学校实际表单") {
                Text("基于合成 JSON 字段渲染。仅演示输入和校验，不保存、不联网、不提交。") .font(.footnote).foregroundStyle(.secondary)
                ForEach(fields, id: \.field_ywid) { field in fieldView(field) }
            }
            Section {
                Button("检查本地表单") {
                    let missing = fields.contains { $0.required && (values[$0.field_ywid] ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
                    let reversed = fields.contains { field in
                        guard field.kind == .timeRange, let start = dates[field.field_ywid + ".start"], let end = dates[field.field_ywid + ".end"] else { return false }; return end < start
                    }
                    result = fields.isEmpty || missing || reversed ? "请补全必填项并检查时间。" : "本地校验通过，未向学校提交。"
                }
                Button("提交学校申请") {}.disabled(true)
                if !result.isEmpty { Text(result).font(.footnote) }
            }
        }.navigationTitle("动态表单演示")
    }
}


struct UjingPhase4Catalog: View {
    let service: Service
    @State private var search = ""
    private struct Item: Identifiable { let id: String; let category: String; let name: String; let evidence: String }
    private static let items: [Item] = [
        .init(id: "3", category: "洗衣", name: "发起退款申请", evidence: "语义推断"),
        .init(id: "4", category: "洗衣", name: "支付宝免密代扣签约（先享后付/自动续费）", evidence: "语义推断"),
        .init(id: "5", category: "洗衣", name: "蓝牙连接引导（搜索、配对、连接设备）", evidence: "静态页面名"),
        .init(id: "6", category: "洗衣", name: "下单/购买成功回执", evidence: "语义推断"),
        .init(id: "7", category: "洗衣", name: "购票/次卡/时长包购买（选择规格与数量）", evidence: "语义推断"),
        .init(id: "8", category: "洗衣", name: "H5 收银台", evidence: "静态页面名"),
        .init(id: "9", category: "洗衣", name: "收银台（新版）：聚合优惠、券、余额混合支付", evidence: "语义推断"),
        .init(id: "10", category: "洗衣", name: "优惠券列表与选择", evidence: "语义推断"),
        .init(id: "11", category: "洗衣", name: "券后收银（选券后重新计价）", evidence: "语义推断"),
        .init(id: "12", category: "洗衣", name: "第三方合作入口（页面名疑为驾校/校园合作）", evidence: "语义推断"),
        .init(id: "13", category: "洗衣", name: "权益卡（洗护套餐/会员权益）", evidence: "语义推断"),
        .init(id: "15", category: "洗衣", name: "设备/门店首页：附近设备、进行中订单、入口宫格", evidence: "语义推断"),
        .init(id: "16", category: "洗衣", name: "我的订单（按业务分类的聚合列表）", evidence: "语义推断"),
        .init(id: "18", category: "洗衣", name: "一卡通/校园卡绑定与余额", evidence: "语义推断"),
        .init(id: "19", category: "洗衣", name: "订单详情（含设备、时长、费用明细、退款/评价入口）", evidence: "语义推断"),
        .init(id: "21", category: "洗衣", name: "订单列表（分页/筛选/下拉刷新）", evidence: "语义推断"),
        .init(id: "22", category: "洗衣", name: "支付结果页（成功/失败/处理中，含轮询）", evidence: "语义推断"),
        .init(id: "23", category: "洗衣", name: "洗衣程序选择（水温/模式/时长/筒自洁）", evidence: "静态页面名"),
        .init(id: "24", category: "洗衣", name: "充值记录（余额/卡充值流水）", evidence: "语义推断"),
        .init(id: "25", category: "洗衣", name: "红包/现金奖励列表与提现入口", evidence: "语义推断"),
        .init(id: "26", category: "洗衣", name: "退款记录与进度（原路退回）", evidence: "语义推断"),
        .init(id: "27", category: "洗衣", name: "洗衣预约（占位/到点提醒）", evidence: "语义推断"),
        .init(id: "28", category: "洗衣", name: "扫码失败/无效码提示", evidence: "静态页面名"),
        .init(id: "29", category: "洗衣", name: "门店搜索（关键字/定位/城市）", evidence: "语义推断"),
        .init(id: "30", category: "洗衣", name: "门店详情（营业时间、设备数、导航）", evidence: "语义推断"),
        .init(id: "31", category: "洗衣", name: "待验证：疑为“三月未用/长期未用”名单（休眠卡或设备）", evidence: "语义推断"),
        .init(id: "32", category: "洗衣", name: "使用规则/计费说明", evidence: "语义推断"),
        .init(id: "34", category: "饮水", name: "发起退款申请", evidence: "语义推断"),
        .init(id: "35", category: "饮水", name: "余额不足引导充值", evidence: "语义推断"),
        .init(id: "36", category: "饮水", name: "绑定水卡（实体卡/虚拟卡）", evidence: "语义推断"),
        .init(id: "37", category: "饮水", name: "支付宝免密代扣签约（先享后付/自动续费）", evidence: "语义推断"),
        .init(id: "38", category: "饮水", name: "下单/购买成功回执", evidence: "语义推断"),
        .init(id: "39", category: "饮水", name: "购票/次卡/时长包购买（选择规格与数量）", evidence: "语义推断"),
        .init(id: "40", category: "饮水", name: "H5 收银台", evidence: "静态页面名"),
        .init(id: "41", category: "饮水", name: "收银台（新版）：聚合优惠、券、余额混合支付", evidence: "语义推断"),
        .init(id: "42", category: "饮水", name: "优惠券列表与选择", evidence: "语义推断"),
        .init(id: "43", category: "饮水", name: "券后收银（选券后重新计价）", evidence: "语义推断"),
        .init(id: "44", category: "饮水", name: "第三方合作入口（页面名疑为驾校/校园合作）", evidence: "语义推断"),
        .init(id: "45", category: "饮水", name: "修正水卡/设备编码（异常码修复）", evidence: "语义推断"),
        .init(id: "46", category: "饮水", name: "设备/门店首页：附近设备、进行中订单、入口宫格", evidence: "语义推断"),
        .init(id: "47", category: "饮水", name: "未支付订单找回与继续支付", evidence: "语义推断"),
        .init(id: "48", category: "饮水", name: "一卡通/校园卡绑定与余额", evidence: "语义推断"),
        .init(id: "49", category: "饮水", name: "订单详情（含设备、时长、费用明细、退款/评价入口）", evidence: "语义推断"),
        .init(id: "50", category: "饮水", name: "订单列表（分页/筛选/下拉刷新）", evidence: "语义推断"),
        .init(id: "51", category: "饮水", name: "支付结果页（成功/失败/处理中，含轮询）", evidence: "语义推断"),
        .init(id: "52", category: "饮水", name: "充值记录（余额/卡充值流水）", evidence: "语义推断"),
        .init(id: "53", category: "饮水", name: "用水记录（按次/按量的用水明细）", evidence: "语义推断"),
        .init(id: "54", category: "饮水", name: "单条用水记录详情", evidence: "语义推断"),
        .init(id: "55", category: "饮水", name: "红包/现金奖励列表与提现入口", evidence: "语义推断"),
        .init(id: "56", category: "饮水", name: "退款记录与进度（原路退回）", evidence: "语义推断"),
        .init(id: "57", category: "饮水", name: "服务主体/收款方公示（合规展示）", evidence: "语义推断"),
        .init(id: "58", category: "饮水", name: "设置/录入 8 位设备码（水表/水机编号）", evidence: "静态页面名"),
        .init(id: "59", category: "饮水", name: "重置/修正编码（管理端动作）", evidence: "语义推断"),
        .init(id: "60", category: "饮水", name: "待验证：疑为“三月未用/长期未用”名单（休眠卡或设备）", evidence: "语义推断"),
        .init(id: "61", category: "饮水", name: "解绑水卡", evidence: "语义推断"),
        .init(id: "62", category: "饮水", name: "使用规则/计费说明", evidence: "语义推断"),
        .init(id: "63", category: "饮水", name: "水卡管理（绑定/解绑/换卡/密码）", evidence: "语义推断"),
        .init(id: "64", category: "淋浴", name: "淋浴激活状态（设备预热/就绪/使用中）", evidence: "语义推断"),
        .init(id: "66", category: "淋浴", name: "发起退款申请", evidence: "语义推断"),
        .init(id: "67", category: "淋浴", name: "支付宝免密代扣签约（先享后付/自动续费）", evidence: "语义推断"),
        .init(id: "69", category: "淋浴", name: "下单/购买成功回执", evidence: "语义推断"),
        .init(id: "70", category: "淋浴", name: "购票/次卡/时长包购买（选择规格与数量）", evidence: "语义推断"),
        .init(id: "71", category: "淋浴", name: "H5 收银台", evidence: "静态页面名"),
        .init(id: "72", category: "淋浴", name: "收银台（新版）：聚合优惠、券、余额混合支付", evidence: "语义推断"),
        .init(id: "73", category: "淋浴", name: "选择浴室/淋浴间（含空闲状态与门密码）", evidence: "语义推断"),
        .init(id: "74", category: "淋浴", name: "优惠券列表与选择", evidence: "语义推断"),
        .init(id: "75", category: "淋浴", name: "券后收银（选券后重新计价）", evidence: "语义推断"),
        .init(id: "76", category: "淋浴", name: "第三方合作入口（页面名疑为驾校/校园合作）", evidence: "语义推断"),
        .init(id: "77", category: "淋浴", name: "设备/门店首页：附近设备、进行中订单、入口宫格", evidence: "语义推断"),
        .init(id: "78", category: "淋浴", name: "一卡通/校园卡绑定与余额", evidence: "语义推断"),
        .init(id: "79", category: "淋浴", name: "订单详情（含设备、时长、费用明细、退款/评价入口）", evidence: "语义推断"),
        .init(id: "80", category: "淋浴", name: "订单列表（分页/筛选/下拉刷新）", evidence: "语义推断"),
        .init(id: "81", category: "淋浴", name: "订单列表（淋浴场景变体，含进行中/已完成分段）", evidence: "语义推断"),
        .init(id: "82", category: "淋浴", name: "支付结果页（成功/失败/处理中，含轮询）", evidence: "语义推断"),
        .init(id: "83", category: "淋浴", name: "充值记录（余额/卡充值流水）", evidence: "语义推断"),
        .init(id: "84", category: "淋浴", name: "红包/现金奖励列表与提现入口", evidence: "语义推断"),
        .init(id: "85", category: "淋浴", name: "退款记录与进度（原路退回）", evidence: "语义推断"),
        .init(id: "86", category: "淋浴", name: "服务主体/收款方公示（合规展示）", evidence: "语义推断"),
        .init(id: "87", category: "淋浴", name: "设置淋浴使用码（临时密码/绑定手环）", evidence: "语义推断"),
        .init(id: "88", category: "淋浴", name: "待验证：疑为“三月未用/长期未用”名单（休眠卡或设备）", evidence: "语义推断"),
        .init(id: "89", category: "淋浴", name: "使用规则/计费说明", evidence: "语义推断"),
        .init(id: "92", category: "吹风", name: "发起退款申请", evidence: "语义推断"),
        .init(id: "93", category: "吹风", name: "支付宝免密代扣签约（先享后付/自动续费）", evidence: "语义推断"),
        .init(id: "95", category: "吹风", name: "下单/购买成功回执", evidence: "语义推断"),
        .init(id: "96", category: "吹风", name: "购票/次卡/时长包购买（选择规格与数量）", evidence: "语义推断"),
        .init(id: "97", category: "吹风", name: "H5 收银台", evidence: "静态页面名"),
        .init(id: "98", category: "吹风", name: "收银台（新版）：聚合优惠、券、余额混合支付", evidence: "语义推断"),
        .init(id: "99", category: "吹风", name: "优惠券列表与选择", evidence: "语义推断"),
        .init(id: "100", category: "吹风", name: "券后收银（选券后重新计价）", evidence: "语义推断"),
        .init(id: "101", category: "吹风", name: "吹风机设备选择（楼层/机位）", evidence: "语义推断"),
        .init(id: "102", category: "吹风", name: "第三方合作入口（页面名疑为驾校/校园合作）", evidence: "语义推断"),
        .init(id: "104", category: "吹风", name: "设备/门店首页：附近设备、进行中订单、入口宫格", evidence: "语义推断"),
        .init(id: "105", category: "吹风", name: "我的订单（按业务分类的聚合列表）", evidence: "语义推断"),
        .init(id: "106", category: "吹风", name: "一卡通/校园卡绑定与余额", evidence: "语义推断"),
        .init(id: "107", category: "吹风", name: "订单详情（含设备、时长、费用明细、退款/评价入口）", evidence: "语义推断"),
        .init(id: "108", category: "吹风", name: "订单列表（分页/筛选/下拉刷新）", evidence: "语义推断"),
        .init(id: "109", category: "吹风", name: "支付结果页（成功/失败/处理中，含轮询）", evidence: "语义推断"),
        .init(id: "110", category: "吹风", name: "直接下单（无购物车，按设备+时长计价）", evidence: "语义推断"),
        .init(id: "111", category: "吹风", name: "充值记录（余额/卡充值流水）", evidence: "语义推断"),
        .init(id: "112", category: "吹风", name: "红包/现金奖励列表与提现入口", evidence: "语义推断"),
        .init(id: "113", category: "吹风", name: "退款记录与进度（原路退回）", evidence: "语义推断"),
        .init(id: "114", category: "吹风", name: "待验证：疑为“三月未用/长期未用”名单（休眠卡或设备）", evidence: "语义推断"),
        .init(id: "115", category: "吹风", name: "使用规则/计费说明", evidence: "语义推断"),
        .init(id: "117", category: "空调", name: "用户协议/服务条款正文", evidence: "语义推断"),
        .init(id: "118", category: "空调", name: "发起退款申请", evidence: "语义推断"),
        .init(id: "119", category: "空调", name: "支付宝免密代扣签约（先享后付/自动续费）", evidence: "语义推断"),
        .init(id: "120", category: "空调", name: "下单/购买成功回执", evidence: "语义推断"),
        .init(id: "121", category: "空调", name: "购票/次卡/时长包购买（选择规格与数量）", evidence: "语义推断"),
        .init(id: "122", category: "空调", name: "H5 收银台", evidence: "静态页面名"),
        .init(id: "123", category: "空调", name: "收银台（新版）：聚合优惠、券、余额混合支付", evidence: "语义推断"),
        .init(id: "124", category: "空调", name: "优惠券列表与选择", evidence: "语义推断"),
        .init(id: "125", category: "空调", name: "券后收银（选券后重新计价）", evidence: "语义推断"),
        .init(id: "126", category: "空调", name: "空调设备连接（Wi-Fi/蓝牙配网与绑定）", evidence: "语义推断"),
        .init(id: "127", category: "空调", name: "空调控制面板（开关、温度、模式、风速、定时）", evidence: "语义推断"),
        .init(id: "128", category: "空调", name: "设备共享给家人/室友", evidence: "语义推断"),
        .init(id: "129", category: "空调", name: "第三方合作入口（页面名疑为驾校/校园合作）", evidence: "语义推断"),
        .init(id: "130", category: "空调", name: "设备/门店首页：附近设备、进行中订单、入口宫格", evidence: "语义推断"),
        .init(id: "131", category: "空调", name: "我的订单（按业务分类的聚合列表）", evidence: "语义推断"),
        .init(id: "132", category: "空调", name: "一卡通/校园卡绑定与余额", evidence: "语义推断"),
        .init(id: "133", category: "空调", name: "订单详情（含设备、时长、费用明细、退款/评价入口）", evidence: "语义推断"),
        .init(id: "134", category: "空调", name: "订单列表（分页/筛选/下拉刷新）", evidence: "语义推断"),
        .init(id: "135", category: "空调", name: "支付结果页（成功/失败/处理中，含轮询）", evidence: "语义推断"),
        .init(id: "136", category: "空调", name: "直接下单（无购物车，按设备+时长计价）", evidence: "语义推断"),
        .init(id: "137", category: "空调", name: "空调用电/用量记录", evidence: "语义推断"),
        .init(id: "138", category: "空调", name: "充值记录（余额/卡充值流水）", evidence: "语义推断"),
        .init(id: "139", category: "空调", name: "红包/现金奖励列表与提现入口", evidence: "语义推断"),
        .init(id: "140", category: "空调", name: "退款记录与进度（原路退回）", evidence: "语义推断"),
        .init(id: "141", category: "空调", name: "租赁退单/退租结算（空调租赁场景）", evidence: "语义推断"),
        .init(id: "142", category: "空调", name: "选择房间/机位（空调租赁场景）", evidence: "语义推断"),
        .init(id: "143", category: "空调", name: "服务主体/收款方公示（合规展示）", evidence: "语义推断"),
        .init(id: "144", category: "空调", name: "待验证：疑为“三月未用/长期未用”名单（休眠卡或设备）", evidence: "语义推断"),
        .init(id: "145", category: "空调", name: "使用规则/计费说明", evidence: "语义推断"),
        .init(id: "146", category: "支付", name: "通用按钮组件", evidence: "静态页面名"),
        .init(id: "147", category: "支付", name: "定位/城市选择组件", evidence: "静态页面名"),
        .init(id: "148", category: "支付", name: "列表“没有更多”占位组件", evidence: "静态页面名"),
        .init(id: "149", category: "支付", name: "充值记录条目组件", evidence: "静态页面名"),
        .init(id: "150", category: "支付", name: "微信免密代扣签约（H5 侧）", evidence: "静态页面名"),
        .init(id: "151", category: "支付", name: "H5 购票/购买", evidence: "静态页面名"),
        .init(id: "152", category: "支付", name: "H5 收银台", evidence: "静态页面名"),
        .init(id: "153", category: "支付", name: "图片资源（勾选态切图）", evidence: "静态页面名"),
        .init(id: "154", category: "支付", name: "H5 优惠券列表", evidence: "静态页面名"),
        .init(id: "155", category: "支付", name: "H5 入口页（收银台/水卡的 H5 外壳）", evidence: "静态页面名"),
        .init(id: "156", category: "支付", name: "H5 公共方法库（格式化、Toast、路由）", evidence: "静态页面名"),
        .init(id: "157", category: "支付", name: "浏览器兼容垫片", evidence: "静态页面名"),
        .init(id: "158", category: "支付", name: "H5 侧退款申请", evidence: "静态页面名"),
        .init(id: "159", category: "支付", name: "H5 网络层封装（统一鉴权头、签名、重试）", evidence: "静态页面名"),
        .init(id: "160", category: "饮水", name: "绑定水卡（实体卡/虚拟卡）", evidence: "语义推断"),
        .init(id: "161", category: "饮水", name: "修正水卡/设备编码（异常码修复）", evidence: "语义推断"),
        .init(id: "162", category: "饮水", name: "H5 入口页（收银台/水卡的 H5 外壳）", evidence: "静态页面名"),
        .init(id: "163", category: "饮水", name: "H5 侧登录（水卡 H5 独立登录页）", evidence: "静态页面名"),
        .init(id: "164", category: "饮水", name: "未支付订单找回与继续支付", evidence: "语义推断"),
        .init(id: "165", category: "饮水", name: "空态组件", evidence: "静态页面名"),
        .init(id: "166", category: "饮水", name: "公告/提示条", evidence: "静态页面名"),
        .init(id: "167", category: "饮水", name: "订单详情（含设备、时长、费用明细、退款/评价入口）", evidence: "语义推断"),
        .init(id: "168", category: "饮水", name: "订单列表（分页/筛选/下拉刷新）", evidence: "语义推断"),
        .init(id: "169", category: "饮水", name: "浏览器兼容垫片", evidence: "静态页面名"),
        .init(id: "170", category: "饮水", name: "设置/录入 8 位设备码（水表/水机编号）", evidence: "静态页面名"),
        .init(id: "171", category: "饮水", name: "收款主体列表（多主体选择）", evidence: "静态页面名"),
        .init(id: "172", category: "饮水", name: "解绑水卡", evidence: "语义推断"),
        .init(id: "173", category: "饮水", name: "水卡总览（余额、绑定状态、充值入口）", evidence: "语义推断"),
        .init(id: "174", category: "跨设备", name: "悬浮窗/快捷窗口启动引导（QuickWindow 引导页）", evidence: "语义推断"),
        .init(id: "175", category: "跨设备", name: "设备/门店首页：附近设备、进行中订单、入口宫格", evidence: "语义推断"),
        .init(id: "176", category: "跨设备", name: "进行中订单的悬浮快捷窗口（剩余时间/一键结束）", evidence: "语义推断"),
    ]
    private let categories = ["洗衣", "饮水", "淋浴", "吹风", "空调", "支付", "跨设备"]
    var body: some View {
        List {
            Section { Text("来自第四阶段 176 项页面映射的业务需求索引，已筛除明显营销/调试项。仅展示规格，不是已接通的业务页面。") .font(.footnote).foregroundStyle(.secondary) }
            ForEach(categories, id: \.self) { category in
                let matching = Self.items.filter { $0.category == category && (search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || category.contains(search)) }
                if !matching.isEmpty {
                    Section(category) {
                        ForEach(matching) { item in
                            NavigationLink { OfficialFeature(service: service, title: item.name) } label: { FeatureRow(title: item.name, subtitle: item.evidence + " · 待授权", color: service.color) }
                        }
                    }
                }
            }
        }.navigationTitle("U净 · 功能索引").searchable(text: $search, prompt: "搜索设备及功能")
    }
}

struct Phase6StatusRows: View {
    let provider: NativeProvider
    var body: some View {
        let status = ProviderIntegrationStatus.phase6(provider)
        VStack(alignment: .leading, spacing: 8) {
            Text("第六阶段 · 接入状态").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            Text("认证：" + status.authentication)
            Text("业务：" + status.business)
            Text("支付：" + status.payment)
        }.font(.footnote).accessibilityElement(children: .combine)
    }
}
