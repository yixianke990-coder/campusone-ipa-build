import SwiftUI
import WebKit

extension Service {
    var nativeProvider: NativeProvider? {
        switch storeID {
        case "1490809012": return .life798
        case "1152127141": return .xiqueer
        case "1142157881": return .ujing
        case "1264484428": return .quzhi
        default: return nil
        }
    }
}

@MainActor struct AccountAccessView: View {
    let service: Service
    var body: some View {
        if let provider = service.nativeProvider { NativeAccountsView(service: service, provider: provider) }
        else if !service.isBuiltIn { WebAccountsView(service: service) }
        else { CampusEmptyState("未配置原生适配器", systemImage: "lock.shield") }
    }
}

@MainActor struct NativeAccountsView: View {
    @EnvironmentObject private var store: CampusStore
    let service: Service
    let provider: NativeProvider
    @AppStorage("native.account.metadata.v1") private var metadata = Data()
    @AppStorage("native.account.selection.v1") private var selection = Data()
    @State private var alias = ""
    @State private var pending: NativeAccount?
    @State private var legacyPending: WebAccount?
    @State private var clearing = false
    @State private var message = ""
    private var accounts: [NativeAccount] { (try? JSONDecoder().decode([NativeAccount].self, from: metadata)) ?? [] }
    private var selected: [String: UUID] { (try? JSONDecoder().decode([String: UUID].self, from: selection)) ?? [:] }
    var body: some View {
        List {
            Section {
                CampusProviderHeader(service: service, subtitle: provider.loginMethod, status: NativeRegistry.service(for: provider).isAuthorized ? "可发起认证" : "在线登录暂不可用")
            }
            Section("账号登录") {
                let adapter = NativeRegistry.service(for: provider)
                if adapter.isAuthorized, let account = accounts.first(where: { $0.provider == provider && selected[provider.rawValue] == $0.id }) {
                    if provider == .life798 {
                        Life798LoginForm(account: account).id(account.id)
                    } else {
                        NativeLoginForm(account: account, adapter: adapter).id(account.id)
                    }
                } else if adapter.isAuthorized {
                    Label("请先添加或选择账号", systemImage: "person.crop.circle.badge.plus")
                } else {
                    Label("暂不能在线登录", systemImage: "exclamationmark.circle")
                        .font(.headline)
                    Text("当前版本没有可用的在线认证连接。不会收集你的账号或验证码。")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }
            Section {
                DisclosureGroup("接入诊断") {
                    Text(provider.blocker).font(.footnote).foregroundStyle(.secondary)
                    Phase6StatusRows(provider: provider)
                }
            }
            Section {
                ForEach(accounts.filter { $0.provider == provider }) { account in
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text(account.alias).font(.headline); Spacer()
                            if selected[provider.rawValue] == account.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(service.color).accessibilityLabel("当前配置") }
                        }
                        Text("本地备注 · 登录状态见上方").font(.caption).foregroundStyle(.secondary)
                        Button("选择此账号配置") { choose(account) }.disabled(selected[provider.rawValue] == account.id)
                        Button("删除本地配置", role: .destructive) { pending = account }
                    }
                }
                TextField("账号备注，例如 主账号", text: $alias).autocorrectionDisabled()
                Button("添加独立账号配置", campusIcon: "person.badge.plus") { add() }.disabled(!NativeAccount.validAlias(alias))
            } header: { Text("本地账号配置") }  footer: { Text("备注不是账号密码。各平台及各账号使用不同的本地标识与 Keychain 存储命名空间；登录会话只保存在本机 Keychain。") }
            let legacy = store.webAccounts.filter { $0.serviceID == service.id }
            if !legacy.isEmpty {
                Section("旧版网页会话清理") {
                    ForEach(legacy) { profile in
                        Button("清除旧网页配置：\(profile.name)", role: .destructive) { legacyPending = profile }.disabled(clearing)
                    }
                    Text("旧版网页登录入口已停用，可主动清除对应网站数据。不会影响自定义网页服务。") .font(.footnote).foregroundStyle(.secondary)
                }
            }
            if clearing { ProgressView("正在清理…") }
            if !message.isEmpty { Text(message).font(.footnote).foregroundStyle(.secondary) }
        }.listStyle(.insetGrouped).navigationTitle("账号登录")
         .navigationBarTitleDisplayMode(.inline)
         .confirmationDialog("删除本地账号配置？", isPresented: Binding(get: { pending != nil }, set: { if !$0 { pending = nil } }), titleVisibility: .visible) {
             Button("删除", role: .destructive) { if let account = pending { remove(account) }; pending = nil }
         } message: { Text("清除本地凭证及备注，不会注销服务商账号。") }
         .confirmationDialog("清除旧网页登录数据？", isPresented: Binding(get: { legacyPending != nil }, set: { if !$0 { legacyPending = nil } }), titleVisibility: .visible) {
             Button("确认清除", role: .destructive) {
                 guard let profile = legacyPending else { return }; legacyPending = nil; clearing = true
                 Task { @MainActor in
                     defer { clearing = false }
                     do {
                         if #available(iOS 17.0, *) { try await WKWebsiteDataStore.remove(forIdentifier: profile.id) }
                         store.webAccounts.removeAll { $0.id == profile.id }; message = "旧版网页配置已清除。"
                     } catch { message = "清除失败，请重试。" }
                 }
             }
         } message: { Text("不会删除原平台账号。") }
    }
    private func add() {
        guard NativeAccount.validAlias(alias) else { return }
        let account = NativeAccount(provider: provider, alias: alias.trimmingCharacters(in: .whitespacesAndNewlines))
        if let data = try? JSONEncoder().encode(accounts + [account]) { metadata = data; choose(account); alias = "" }
        else { message = "保存账号配置失败。" }
    }
    private func choose(_ account: NativeAccount) {
        var values = selected; values[provider.rawValue] = account.id
        if let data = try? JSONEncoder().encode(values) { selection = data }
    }
    private func remove(_ account: NativeAccount) {
        do {
            try KeychainStore().remove(account: account)
            metadata = try JSONEncoder().encode(accounts.filter { $0.id != account.id })
            if selected[provider.rawValue] == account.id {
                var values = selected; values.removeValue(forKey: provider.rawValue); selection = try JSONEncoder().encode(values)
            }
            message = "本地账号配置已删除。"
        } catch { message = "安全存储清理失败，账号配置未确认删除。" }
    }
}

// Only instantiated for an available adapter. Challenge contents and timing are
// adapter-specific; this generic input does not implement a provider captcha SDK.
@MainActor private struct NativeLoginForm: View {
    let account: NativeAccount
    let adapter: any PlatformService
    @State private var school = ""
    @State private var username = ""
    @State private var password = ""
    @State private var phone = ""
    @State private var response = ""
    @State private var reference: String?
    @State private var busy = false
    @State private var authenticated = false
    @State private var status = ""
    @State private var work: Task<Void, Never>?
    var body: some View {
        Group {
            if authenticated {
                Label("会话已确认", systemImage: "checkmark.circle")
                if account.provider == .xiqueer, let xiqueer = adapter as? XiqueerService {
                    XiqueerDataView(account: account, service: xiqueer)
                }
                Button("退出登录") { signOut() }.disabled(busy)
            } else if reference != nil {
                TextField("输入平台要求的验证码", text: $response).textContentType(.oneTimeCode).autocorrectionDisabled()
                Button("验证并登录") { submit() }.disabled(busy || response.isEmpty)
                Button("取消本次验证") { reference = nil; response = ""; status = "" }.disabled(busy)
            } else {
                if account.provider == .xiqueer {
                    TextField("学校标识", text: $school).autocorrectionDisabled()
                    TextField("学号", text: $username).textContentType(.username).autocorrectionDisabled()
                    SecureField("密码", text: $password).textContentType(.password)
                } else {
                    TextField("手机号码", text: $phone).keyboardType(.phonePad).textContentType(.telephoneNumber)
                }
                Button(account.provider == .xiqueer ? "登录" : "发起验证码验证") { submit() }
                    .disabled(busy || (account.provider == .xiqueer ? school.isEmpty || username.isEmpty || password.isEmpty : phone.isEmpty))
            }
            if busy { ProgressView("正在验证…") }
            if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(.secondary) }
        }.onDisappear { work?.cancel(); password = ""; response = ""; reference = nil; phone = ""; username = ""; school = "" }
         .task {
             if account.provider == .xiqueer, let xiqueer = adapter as? XiqueerService,
                await xiqueer.storedSession(account: account) != nil { authenticated = true }
         }
    }
    private func signOut() {
        busy = true
        work = Task { @MainActor in
            defer { busy = false; work = nil }
            try? await adapter.signOut(account: account)
            authenticated = false
            status = "已退出登录。"
        }
    }
    private func submit() {
        guard !busy else { return }
        busy = true; status = ""
        let flow = NativeLoginFlow(service: adapter, account: account)
        let currentReference = reference
        let currentResponse = response
        let input: NativeLoginInput = account.provider == .xiqueer ? .schoolAccount(schoolReference: school, account: username, password: password) : .phoneChallenge(phone: phone)
        password = ""; response = ""
        work = Task { @MainActor in
            defer { busy = false; work = nil }
            do {
                let result: NativeLoginOutcome
                if let currentReference { result = try await flow.complete(reference: currentReference, response: currentResponse) }
                else { result = try await flow.begin(input) }
                try Task.checkCancellation()
                switch result {
                case .challengeRequired(let next): reference = next; status = "请完成平台验证。"
                case .authenticated: reference = nil; authenticated = true; status = ""
                }
            } catch is CancellationError {} catch {
                if !Task.isCancelled { status = "验证未完成，请稍后重试。" }
            }
        }
    }
}

// MARK: - v0.9.1 Xiqueer data (schedule / grades)

@MainActor private struct XiqueerDataView: View {
    let account: NativeAccount
    let service: XiqueerService
    @State private var week = "1"
    @State private var xnxq = XiqueerDataView.currentTerm()
    @State private var result = ""
    @State private var busy = false
    @State private var errorText = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                TextField("学年学期 如20250", text: $xnxq).autocorrectionDisabled().keyboardType(.numberPad)
                TextField("周次", text: $week).autocorrectionDisabled().keyboardType(.numberPad)
            }.font(.footnote)
            HStack(spacing: 16) {
                Button("拉课表") { load(schedule: true) }.disabled(busy || week.isEmpty || xnxq.isEmpty)
                Button("拉成绩") { load(schedule: false) }.disabled(busy || xnxq.isEmpty)
                if busy { ProgressView() }
            }.font(.footnote)
            if !errorText.isEmpty { Text(errorText).font(.footnote).foregroundStyle(.red) }
            if !result.isEmpty { Text(result).font(.caption).textSelection(.enabled) }
        }
    }
    static func currentTerm() -> String {
        let calendar = Calendar.current
        let year = calendar.component(.year, from: Date())
        let month = calendar.component(.month, from: Date())
        switch month {
        case 9...12: return "\(year)0"
        case 1: return "\(year - 1)0"
        default: return "\(year - 1)1"
        }
    }
    private func load(schedule: Bool) {
        busy = true; errorText = ""; result = ""
        Task { @MainActor in
            defer { busy = false }
            do {
                result = schedule ? try await service.fetchSchedule(account: account, week: week, xnxq: xnxq)
                                  : try await service.fetchGrades(account: account, xnxq: xnxq)
                if result.isEmpty { errorText = "服务器没有返回内容。" }
            } catch { errorText = "拉取失败：\(error.localizedDescription)" }
        }
    }
}

// MARK: - v0.9.1 Life798 dedicated login + panel
// The generic challenge form cannot display the graphic captcha image, so
// Life798 gets its own form: captcha image -> SMS code -> login, per channel
// (device channel powers water control; account channel covers points).

@MainActor private struct Life798LoginForm: View {
    let account: NativeAccount
    @State private var client = Life798Client()
    @State private var session: Life798Session?
    @State private var restored = false
    @State private var addingChannel = false
    @State private var phone = ""
    @State private var captchaKey = ""
    @State private var captchaData: Data?
    @State private var graphicCode = ""
    @State private var smsCode = ""
    @State private var codeSent = false
    @State private var loginAsApp = true
    @State private var busy = false
    @State private var status = ""
    @State private var wallets: [Life798Wallet] = []
    @State private var devices: [Life798Device] = []
    @State private var bills: [Life798Bill] = []
    @State private var manualDID = ""
    @State private var deviceStatus = ""

    var body: some View {
        Group {
            if let current = session, !addingChannel {
                loggedIn(current)
            } else {
                loginFields
            }
            if busy { ProgressView("处理中…") }
            if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(.secondary) }
        }.task { await restore() }
    }

    private var loginFields: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("登录通道", selection: $loginAsApp) {
                Text("设备端（开水）").tag(true)
                Text("账户端（积分）").tag(false)
            }.pickerStyle(.segmented)
            HStack(spacing: 12) {
                if let captchaData, let image = UIImage(data: captchaData) {
                    Image(uiImage: image).resizable().scaledToFit().frame(height: 44)
                } else {
                    Text("验证码图未加载").font(.caption).foregroundStyle(.secondary)
                }
                Button("换一张") { Task { await refreshCaptcha() } }.disabled(busy)
            }
            TextField("手机号码", text: $phone).keyboardType(.phonePad).textContentType(.telephoneNumber)
            TextField("图形验证码", text: $graphicCode).autocorrectionDisabled()
            Button("发送短信验证码") { sendCode() }
                .disabled(busy || phone.count != 11 || graphicCode.isEmpty || captchaData == nil)
            TextField("短信验证码", text: $smsCode).keyboardType(.numberPad).textContentType(.oneTimeCode)
            Button("登录") { doLogin() }.disabled(busy || !codeSent || smsCode.isEmpty)
            if addingChannel { Button("取消补登") { addingChannel = false }.disabled(busy) }
            Text("设备端登录用于开水与钱包；账户端用于积分。两个通道各需一条短信验证码，与原 App 一致。")
                .font(.caption).foregroundStyle(.secondary)
        }
    }

    private func loggedIn(_ current: Life798Session) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("已登录 \(current.phone)", systemImage: "checkmark.circle")
            Text("设备端：\(current.appToken != nil ? "已登录" : "未登录") · 账户端：\(current.mainToken != nil ? "已登录" : "未登录")")
                .font(.caption).foregroundStyle(.secondary)
            if current.appToken == nil || current.mainToken == nil {
                Button("补登另一通道") {
                    addingChannel = true; loginAsApp = current.appToken == nil
                    codeSent = false; smsCode = ""; graphicCode = ""
                    Task { await refreshCaptcha() }
                }.disabled(busy)
            }
            if current.appToken != nil {
                if !wallets.isEmpty {
                    Text("钱包").font(.subheadline.bold())
                    ForEach(wallets, id: \.endpointId) { wallet in
                        HStack { Text(wallet.name.isEmpty ? "钱包" : wallet.name); Spacer(); Text("¥" + String(format: "%.2f", wallet.balance)) }
                            .font(.footnote)
                    }
                }
                if !devices.isEmpty {
                    Text("收藏设备").font(.subheadline.bold())
                    ForEach(devices, id: \.id) { device in
                        HStack {
                            Text(device.name.isEmpty ? device.id : device.name).font(.footnote)
                            Spacer()
                            Button("启动") { deviceAction(did: device.id, start: true) }.font(.footnote)
                            Button("停止") { deviceAction(did: device.id, start: false) }.font(.footnote)
                        }
                    }
                }
                TextField("设备号（可粘贴扫码内容）", text: $manualDID).autocorrectionDisabled().font(.footnote)
                HStack(spacing: 16) {
                    Button("启动设备") { deviceAction(did: Life798Client.normalizeDeviceID(manualDID), start: true) }.disabled(busy || manualDID.isEmpty)
                    Button("停止设备") { deviceAction(did: Life798Client.normalizeDeviceID(manualDID), start: false) }.disabled(busy || manualDID.isEmpty)
                }.font(.footnote)
                if !deviceStatus.isEmpty { Text(deviceStatus).font(.footnote).foregroundStyle(.secondary) }
                if !bills.isEmpty {
                    Text("最近账单").font(.subheadline.bold())
                    ForEach(Array(bills.prefix(5).enumerated()), id: \.offset) { _, bill in
                        HStack {
                            Text(bill.createdAt.map { Self.timeFormatter.string(from: $0) } ?? "—")
                            Spacer()
                            Text("¥" + String(format: "%.2f", bill.payment ?? 0))
                            Text(bill.status == 3 ? "已结算" : "状态\(bill.status ?? 0)")
                        }.font(.caption).foregroundStyle(.secondary)
                    }
                }
                Button("刷新数据") { Task { await loadPanel() } }.disabled(busy).font(.footnote)
            }
            Button("退出登录", role: .destructive) { signOut() }.disabled(busy).font(.footnote)
        }
    }

    private static let timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }()

    private func restore() async {
        guard !restored else { return }
        restored = true
        session = await Life798Session.load(account: account)
        if let current = session { phone = current.phone }
        if session?.appToken != nil { await loadPanel() }
        if session == nil { await refreshCaptcha() }
    }

    private func refreshCaptcha() async {
        let key = Life798Client.newCaptchaKey()
        captchaKey = key
        do { captchaData = try await client.fetchCaptcha(key: key) }
        catch { status = "验证码图加载失败，请点换一张重试。" }
    }

    private func sendCode() {
        busy = true; status = ""
        Task { @MainActor in
            defer { busy = false }
            do {
                try await client.sendSmsCode(phone: phone, graphicCode: graphicCode, key: captchaKey, asApp: loginAsApp)
                codeSent = true
                status = "短信验证码已发送。"
            } catch { status = "发送失败：\(error.localizedDescription)" }
        }
    }

    private func doLogin() {
        busy = true; status = ""
        Task { @MainActor in
            defer { busy = false }
            do {
                let result = try await client.login(phone: phone, smsCode: smsCode, asApp: loginAsApp)
                var updated = session ?? Life798Session(phone: phone)
                updated.phone = phone
                if loginAsApp { updated.appToken = result.token } else { updated.mainToken = result.token }
                if let uid = result.uid { updated.uid = uid }
                if let eid = result.eid { updated.eid = eid }
                if updated.uid == nil, let token = result.token,
                   let info = try? await client.viewInfo(token: token, asApp: loginAsApp) {
                    updated.uid = Life798Client.uid(from: info)
                }
                try await updated.save(account: account)
                session = updated
                addingChannel = false
                codeSent = false; smsCode = ""; graphicCode = ""
                status = "登录成功。"
                if updated.appToken != nil { await loadPanel() }
            } catch { status = "登录失败：\(error.localizedDescription)" }
        }
    }

    private func loadPanel() async {
        guard let token = session?.appToken else { return }
        do {
            wallets = try await client.wallets(appToken: token)
            devices = try await client.devices(appToken: token)
            bills = try await client.bills(appToken: token)
        } catch let error as Life798ServerError where error.code == -99 {
            status = "登录已失效，请退出后重新登录。"
        } catch { status = "数据刷新失败：\(error.localizedDescription)" }
    }

    private func deviceAction(did: String, start: Bool) {
        guard let token = session?.appToken, !did.isEmpty else { return }
        busy = true; deviceStatus = ""
        Task { @MainActor in
            defer { busy = false }
            do {
                let result = start ? try await client.deviceStart(appToken: token, did: did)
                                   : try await client.deviceEnd(appToken: token, did: did)
                deviceStatus = !start && result.code == 0 ? "停止请求已发送，请等待设备结束与账单结算。"
                    : Life798Client.deviceMessage(code: result.code, message: result.message)
                if start && result.code == 0 { await loadPanel() }
            } catch { deviceStatus = "操作失败：\(error.localizedDescription)" }
        }
    }

    private func signOut() {
        busy = true
        Task { @MainActor in
            defer { busy = false }
            await Life798Session.clear(account: account)
            session = nil; wallets = []; devices = []; bills = []
            status = "已退出登录。"
            await refreshCaptcha()
        }
    }
}
