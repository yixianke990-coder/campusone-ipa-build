# 工贸助手 v0.8.9 / Build 22 — 真机打包测试

## 构建输入
- 导入整个目录及 CampusOne.xcodeproj，选择 CampusOne scheme。
- 使用 Xcode 26 或支持现有 Liquid Glass / Widget API 的更新 SDK，最低部署 iOS 15。
- 主 App 与 CampusWidgets 均设置版本 0.8.9 / Build 22。
- 使用此前成功安装的 Bundle ID、App Group 和签名团队；若新配置，应同时更新 CAMPUS_BUNDLE_ID、CAMPUS_APP_GROUP 及两个 target 的签名。默认 com.example 值是占位配置。
- 保留 Widget 扩展、权限、Assets、NativeCore（已经作为源文件列入主目标，不重复引入同名依赖）。
- 执行 SDK 编译、签名、安装或归档导出 IPA。记录真实编译日志；不可为了通过编译删除功能。

## 验收
- 启动、导航、深色模式、扫码相机及相册。
- 慧生活798照片二维码应匹配慧生活798候选服务。仅本地识别，不查询设备、不触发设备或支付。
- 喜鹊儿：现有认证输入模型为学校/账号/密码及后续验证码挑战；用户反馈原 App 验证码登录后有数据，具体验证码类型与接入方式未确认。当前 NativeRegistry 仍返回不可用适配器，不能在线登录。可验证本地课表导入，不将其视为在线同步。
- 其他平台真实认证、设备和支付也未接通。
- 保留原 UI、系统扩展及本地数据功能；须在真机验证。

## 环境限制
当前 Linux 环境无 Xcode/iOS SDK，不能生成已签名 IPA。此包为测试源码，不是全功能正式版。不要上传密码、验证码、会话凭证或签名私钥。
