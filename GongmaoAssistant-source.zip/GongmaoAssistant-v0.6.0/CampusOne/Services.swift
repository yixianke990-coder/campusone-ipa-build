import SwiftUI
import WebKit

struct ServicesView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var add = false
    var body: some View {
        List {
            Section("我的服务") {
                ForEach(store.services) { service in
                    NavigationLink { ServiceDetail(id: service.id) } label: {
                        HStack { ServiceRow(service: service); if !service.enabled { Text("已停用").font(.caption).foregroundStyle(.secondary) } }
                    }
                }.onMove { store.services.move(fromOffsets: $0, toOffset: $1) }
            }
            Section { Button("添加自定义网页", systemImage: "plus") { add = true } }
            Section { Text("内置服务使用各平台的官方入口。深度接口尚未接入；网页服务可由用户自行配置，不绑定学校。") .font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("服务").toolbar { EditButton(); Button("添加", systemImage: "plus") { add = true } }
            .sheet(isPresented: $add) { NavigationStack { ServiceEditor(service: Service(name: "", category: "网页", symbol: "globe", tint: "green")) } }
    }
}

struct ServiceDetail: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.openURL) private var openURL
    @Environment(\.dismiss) private var dismiss
    let id: UUID
    @State private var edit = false
    @State private var account = false
    @State private var remove = false
    @State private var message: String?
    var body: some View {
        Group {
            if let service = store.services.first(where: { $0.id == id }) {
                List {
                    Section { HStack { Spacer(); VStack(spacing: 10) { ServiceIcon(service: service); Text(service.name).font(.title2.bold()); Text(service.category).foregroundStyle(.secondary) }; Spacer() }.padding(.vertical, 12) }
                    Section("打开服务") {
                        if let url = WebLoginRules.entryURL(service.url) {
                            if !service.externalBrowser {
                                NavigationLink { WebAccountsView(service: service) } label: { Label("在应用内登录 / 打开网页", systemImage: "person.badge.key") }.disabled(!service.enabled)
                            }
                            Button("在系统浏览器打开", systemImage: "arrow.up.forward.app") {
                                openURL(url) { accepted in if !accepted { message = "无法打开该链接。" } }
                            }.disabled(!service.enabled)
                        }
                        if let url = service.storeURL {
                            Link(destination: url) { Label("前往 App Store 官方页面", systemImage: "apple.logo") }
                            Text("此入口是 App Store 页面，不是直接启动或登录原 App。可在官方页面打开已安装应用（取决于系统）。") .font(.footnote).foregroundStyle(.secondary)
                        }
                        if service.isBuiltIn { Label("真实 API / 设备控制待接入", systemImage: "info.circle").foregroundStyle(.secondary) }
                    }
                    Section("独立账号") {
                        NavigationLink { WebAccountsView(service: service) } label: { Label("独立网页登录与会话", systemImage: "person.crop.circle") }
                        Button("管理本地账号备注", systemImage: "note.text") { account = true }
                        Text("网页登录由原网站完成。各账号的网页数据隔离，不自动判断登录成功。原生 API 登录、余额及支付仍未接入。") .font(.footnote).foregroundStyle(.secondary)
                    }
                    if service.storeID == "1152127141" {
                        Section("教务中心") { NavigationLink { AcademicCenter(service: service) } label: { Label("全部学业服务", systemImage: "graduationcap") }; NavigationLink { CoursesView() } label: { Label("我的课表", systemImage: "calendar") } }
                    }
                    if let evidence = ProviderEvidence.forService(service) {
                        Section("平台功能与接入情况") {
                            NavigationLink { EvidenceCenter(service: service, evidence: evidence) } label: { Label("功能中心与兼容性", systemImage: service.symbol) }
                        }
                    }
                    if service.isBuiltIn { ProviderTools(service: service) }
                    Section("服务设置") {
                        LabeledContent("状态", value: service.enabled ? "已启用" : "已停用")
                        LabeledContent("首页显示", value: service.showOnHome ? "是" : "否")
                        LabeledContent("扫码规则", value: Routing.normalizedHosts(service.hosts).isEmpty ? "未配置" : "\(Routing.normalizedHosts(service.hosts).count) 个域名")
                        Button("编辑服务", systemImage: "slider.horizontal.3") { edit = true }
                        if !service.isBuiltIn { Button("删除网页服务", role: .destructive) { remove = true } }
                    }
                }.navigationTitle(service.name).navigationBarTitleDisplayMode(.inline)
                    .sheet(isPresented: $edit) { NavigationStack { ServiceEditor(service: service) } }
                    .sheet(isPresented: $account) { NavigationStack { AccountEditor(service: service) } }
                    .confirmationDialog("删除本地服务及账号备注？", isPresented: $remove, titleVisibility: .visible) {
                        Button("删除", role: .destructive) {
                            if store.webAccounts.contains(where: { $0.serviceID == id }) { message = "请先在独立网页登录与会话中删除全部网页登录配置及数据。" }
                            else if AccountVault.write("", id: id) { store.remove(service); dismiss() }
                            else { message = "无法清除账号备注，服务未删除。" }
                        }
                    } message: { Text("不会删除原平台账号或网页浏览会话。") }
                    .alert("提示", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) { Button("确定") { message = nil } } message: { Text(message ?? "") }
            } else { ContentUnavailableView("服务不存在", systemImage: "exclamationmark.circle") }
        }
    }
}

struct ServiceEditor: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State var service: Service
    @State private var error: String?
    private let icons = ["globe", "clipboard", "calendar", "book", "creditcard", "graduationcap", "building.2", "link"]
    var body: some View {
        Form {
            Section("基本信息") {
                TextField("服务名称", text: $service.name).disabled(service.isBuiltIn)
                TextField("服务分类", text: $service.category)
                if !service.isBuiltIn { Picker("图标", selection: $service.symbol) { ForEach(icons, id: \.self) { Label($0, systemImage: $0).tag($0) } } }
                Toggle("启用服务", isOn: $service.enabled)
                Toggle("显示在首页", isOn: $service.showOnHome)
            }
            Section {
                TextField("https://…", text: $service.url).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                if !service.isBuiltIn { Toggle("使用系统浏览器", isOn: $service.externalBrowser) }
            } header: { Text(service.isBuiltIn ? "官方 HTTPS 入口（可选）" : "网页链接（必填）") } footer: {
                Text("仅接受 HTTPS。请填写稳定的官方入口，不要粘贴含临时登录码、票据、密码或令牌的链接。企业微信等认证若不支持应用内浏览，请使用原平台。")
            }
            Section {
                TextField("例如 devices.example.com", text: $service.hosts, axis: .vertical).textInputAutocapitalization(.never).autocorrectionDisabled()
            } header: { Text("二维码域名规则（可选）") } footer: { Text("只填写已验证属于该服务商的设备二维码域名，可用空格或逗号分隔。不支持通配符；相同域名出现于多个服务时要求手动选择。") }
        }.navigationTitle("服务配置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("保存", action: save) } }
            .alert("配置有误", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("确定") { error = nil } } message: { Text(error ?? "") }
    }
    private func save() {
        service.name = service.name.trimmingCharacters(in: .whitespacesAndNewlines)
        service.category = service.category.trimmingCharacters(in: .whitespacesAndNewlines)
        service.url = service.url.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !service.name.isEmpty, !service.category.isEmpty else { error = "请填写名称和分类。"; return }
        if !service.isBuiltIn || !service.url.isEmpty {
            guard let url = WebLoginRules.entryURL(service.url) else { error = "请填写稳定的 HTTPS 链接，不含临时认证参数或片段。"; return }
            let sensitive = ["code", "ticket", "token", "access_token", "id_token", "password", "session", "sessionid", "sso_ticket", "auth_code"]
            if URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.contains(where: { sensitive.contains($0.name.lowercased()) }) == true {
                error = "链接含可能用于登录的一次性参数，请填写稳定的服务入口。"; return
            }
        }
        let rawHosts = service.hosts.split(whereSeparator: { $0.isWhitespace || $0 == "," || $0 == "，" })
        let hosts = Routing.normalizedHosts(service.hosts)
        guard rawHosts.count == hosts.count else { error = "二维码规则只能填写完整域名，不可包含路径或通配符。"; return }
        service.hosts = hosts.joined(separator: ", ")
        store.save(service); dismiss()
    }
}

struct AccountEditor: View {
    @Environment(\.dismiss) private var dismiss
    let service: Service
    @State private var label = ""
    @State private var error = false
    var body: some View {
        Form {
            Section(service.name) {
                TextField("账号备注（如手机号后四位）", text: $label).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("清除本地备注", role: .destructive) { if AccountVault.write("", id: service.id) { label = ""; dismiss() } else { error = true } }
            }
            Section { Text("备注独立加密保存在本机 Keychain。请不要输入密码、验证码或令牌。备注不代表已登录；切换真实账号请前往原平台。") .foregroundStyle(.secondary) }
        }.navigationTitle("账号与授权").navigationBarTitleDisplayMode(.inline)
            .onAppear { label = AccountVault.read(service.id) }
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("保存") { if AccountVault.write(label.trimmingCharacters(in: .whitespacesAndNewlines), id: service.id) { dismiss() } else { error = true } } } }
            .alert("Keychain 保存失败", isPresented: $error) { Button("确定", role: .cancel) {} }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: CampusStore
    @AppStorage("appearance") private var appearance = "system"
    var body: some View {
        List {
            Section("各平台独立账号") {
                ForEach(store.services) { service in
                    NavigationLink { WebAccountsView(service: service) } label: { ServiceRow(service: service) }
                }
            }
            Section("外观") { Picker("显示模式", selection: $appearance) { Text("跟随系统").tag("system"); Text("浅色").tag("light"); Text("深色").tag("dark") } }
            Section("服务与隐私") {
                NavigationLink("服务管理") { ServicesView() }
                NavigationLink("隐私与使用说明") {
                    List {
                        Section("数据") { Text("服务配置、手动课表、设备收藏、手动消费及计时记录保存在本机；账号备注保存在 Keychain。网页登录配置与独立网站会话保存在本机。本版本不向 工贸助手 服务器上传数据，也不保存扫码历史。") }
                        Section("第三方服务") { Text("打开原服务时，其登录、支付、数据处理及网页会话遵循各服务商的规则。应用内 WebKit 按账号隔离网站数据；外部浏览器与原 App 的登录由对应应用管理。") }
                        Section("安全") { Text("二维码只做本地识别，不自动打开链接、不自动启动设备、不自动支付。请核对目标平台和设备。") }
                    }.navigationTitle("隐私与使用说明")
                }
            }
            Section("关于") { LabeledContent("版本", value: "0.6.0 · 报告适配预览"); Text("独立校园服务聚合工具，非任何学校或服务商官方产品。无自有广告。") .font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("设置")
    }
}

// The catalog reflects the supplied screenshots; unsupported features never present fake results.
struct AcademicCenter: View {
    let service: Service
    @State private var search = ""
    private let groups: [(String, [String])] = [
        ("学籍", ["增改基本信息", "学期报到", "异动申请"]),
        ("培养方案", ["查看培养方案"]),
        ("选课", ["预选", "预选结果", "正选", "正选结果", "退选"]),
        ("重修", ["重修选", "重修选结果", "重修申请", "重修查询"]),
        ("考试", ["资格考试报名", "考试安排", "补考申请"]),
        ("评教", ["学生评教"]), ("成绩", ["学业成绩", "免修申请"]),
        ("学业", ["学业进展"]), ("教材", ["确认需要教材", "教材对账"]),
        ("课表", ["教室课表"]),
        ("其他", ["校历查询", "蹭课", "资格考试成绩", "空闲教室", "请假登记", "提交作业", "缺勤信息", "课堂表现", "班级课表", "学情警示", "上课签到", "课堂练习", "问卷调查", "校园卡", "消息通知", "报修", "个人信息", "账号安全"])
    ]
    var body: some View {
        List {
            Section("已编写的本地功能") {
                NavigationLink { CoursesView() } label: { Label("我的课表与在线同步", systemImage: "calendar") }
                NavigationLink { TermSettings() } label: { Label("学期及教学周设置", systemImage: "calendar.badge.clock") }
                NavigationLink { WebAccountsView(service: service) } label: { Label("独立账号与网页登录", systemImage: "person.crop.circle") }
            }
            Section { Text("以下是原平台菜单的适配入口。尚未接入原生教务 API；若学校提供对应的官方 HTTPS 网页，可为功能单独配置。否则使用原 App。") .font(.footnote).foregroundStyle(.secondary) }
            ForEach(groups.indices, id: \.self) { index in
                let group = groups[index]
                let items = group.1.filter { search.isEmpty || $0.localizedCaseInsensitiveContains(search) || group.0.contains(search) }
                if !items.isEmpty {
                    Section(group.0) { ForEach(items, id: \.self) { title in
                        NavigationLink { OfficialFeature(service: service, title: title) } label: { Text(title) }
                    } }
                }
            }
        }.navigationTitle("喜鹊儿 · 教务中心").searchable(text: $search, prompt: "搜索学业服务")
    }
}
struct BathCenter: View {
    let service: Service
    @State private var scan = false
    private let official = ["钱包与余额", "充值", "卡包", "卡密激活", "卡券", "我的账单", "添加设备", "我的工单", "常见问题", "在线客服"]
    var body: some View {
        List {
            Section("澡堂") {
                Button("扫描设备二维码", systemImage: "qrcode.viewfinder") { scan = true }
                NavigationLink { OfficialFeature(service: service, title: "淋浴设备启停") } label: { Label("淋浴设备启停（官方入口）", systemImage: "shower") }
                NavigationLink { DeviceList(service: service) } label: { Label("常用设备收藏", systemImage: "star") }
                NavigationLink { TimerList(service: service) } label: { Label("洗澡计时及通知（本地）", systemImage: "timer") }
                Text("本地扫码不会自动启动设备或扣费，计时不等于官方订单。") .font(.footnote).foregroundStyle(.secondary)
            }
            Section("账户与账单") {
                NavigationLink { WebAccountsView(service: service) } label: { Label("独立登录会话", systemImage: "person.crop.circle") }
                NavigationLink { ExpensesView(service: service) } label: { Label("手动消费记录与统计", systemImage: "chart.bar") }
                ForEach(official, id: \.self) { title in NavigationLink { OfficialFeature(service: service, title: title) } label: { Text(title) } }
            }
        }.navigationTitle("慧生活798 · 设备中心")
            .sheet(isPresented: $scan) { NavigationStack { ScanView() } }
    }
}
struct OfficialFeature: View {
    @EnvironmentObject private var store: CampusStore
    let service: Service
    let title: String
    @State private var edit = false
    private var entryName: String { service.name + " · " + title }
    private var entry: Service? { store.services.first { !$0.isBuiltIn && $0.name == entryName } }
    var body: some View {
        List {
            Section("接入状态") {
                Label("原生接口未接入", systemImage: "info.circle").foregroundStyle(.secondary)
                Text("该功能的真实数据和操作由原平台处理；本页不伪造余额、成绩、订单或审批结果。") .font(.footnote).foregroundStyle(.secondary)
            }
            Section("官方入口") {
                if let entry {
                    NavigationLink { ServiceDetail(id: entry.id) } label: { Label("打开已配置网页", systemImage: "globe") }
                } else { Button("添加该功能的官方网页", systemImage: "plus") { edit = true } }
                if let url = service.storeURL { Link("原 App 的 App Store 页面", destination: url) }
            }
        }.navigationTitle(title)
            .sheet(isPresented: $edit) { NavigationStack { ServiceEditor(service: Service(name: entryName, category: "网页", symbol: "globe", tint: "green", showOnHome: false)) } }
    }
}

struct EvidenceCenter: View {
    let service: Service
    let evidence: ProviderEvidence
    @State private var search = ""
    @State private var scan = false
    var body: some View {
        List {
            Section("静态分析依据") {
                LabeledContent("Android 参考版本", value: evidence.version)
                Text(evidence.summary)
                Text(evidence.blocker).font(.footnote).foregroundStyle(.secondary)
                Label("原生业务未接入 · 静态证据非运行验证", systemImage: "info.circle").font(.footnote)
            }
            Section("本地功能") {
                NavigationLink { WebAccountsView(service: service) } label: { Label("独立网页登录与会话", systemImage: "person.crop.circle") }
                if service.storeID == "1152127141" {
                    NavigationLink { AcademicCenter(service: service) } label: { Label("教务功能目录", systemImage: "graduationcap") }
                    NavigationLink { CoursesView() } label: { Label("课表及授权在线同步", systemImage: "calendar") }
                } else {
                    Button("扫描设备二维码", systemImage: "qrcode.viewfinder") { scan = true }
                    NavigationLink { DeviceList(service: service) } label: { Label("常用设备收藏", systemImage: "star") }
                    NavigationLink { TimerList(service: service) } label: { Label("本地计时及通知", systemImage: "timer") }
                    NavigationLink { ExpensesView(service: service) } label: { Label("手动消费统计", systemImage: "chart.bar") }
                }
            }
            ForEach(evidence.groups.indices, id: \.self) { index in
                let group = evidence.groups[index]
                let items = group.1.filter { search.isEmpty || $0.localizedCaseInsensitiveContains(search) || group.0.contains(search) }
                if !items.isEmpty {
                    Section(group.0) {
                        ForEach(items, id: \.self) { title in
                            NavigationLink { OfficialFeature(service: service, title: title) } label: {
                                VStack(alignment: .leading, spacing: 3) { Text(title); Text("待授权接入 / 可配置官方网页").font(.caption).foregroundStyle(.secondary) }
                            }
                        }
                    }
                }
            }
        }.navigationTitle(service.name).searchable(text: $search, prompt: "搜索平台功能")
         .sheet(isPresented: $scan) { NavigationStack { ScanView() } }
    }
}
