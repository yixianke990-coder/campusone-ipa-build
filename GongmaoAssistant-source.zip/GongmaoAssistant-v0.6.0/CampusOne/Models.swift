import Foundation

struct Service: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var category: String
    var symbol: String
    var tint: String
    var storeID: String? = nil
    var url: String = ""
    var hosts: String = ""
    var enabled: Bool = true
    var showOnHome: Bool = true
    var externalBrowser: Bool = false
    var isBuiltIn: Bool { storeID != nil }
    var storeURL: URL? { storeID.flatMap { URL(string: "https://apps.apple.com/cn/app/id\($0)") } }
    static let defaults: [Service] = [
        Service(id: UUID(uuidString: "00000000-0000-4000-8000-000000000001")!, name: "慧生活798", category: "澡堂", symbol: "shower", tint: "blue", storeID: "1490809012"),
        Service(id: UUID(uuidString: "00000000-0000-4000-8000-000000000002")!, name: "喜鹊儿", category: "教务", symbol: "calendar", tint: "orange", storeID: "1152127141"),
        Service(id: UUID(uuidString: "00000000-0000-4000-8000-000000000003")!, name: "U净", category: "洗衣", symbol: "washer", tint: "indigo", storeID: "1142157881"),
        Service(id: UUID(uuidString: "00000000-0000-4000-8000-000000000004")!, name: "趣智校园", category: "校园用水", symbol: "drop", tint: "teal", storeID: "1264484428")
    ]
}

struct Course: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var location: String
    var weekday: Int // 1=Monday, 7=Sunday
    var start: Int // minutes after midnight
    var end: Int
    var detail: CourseDetail? = nil
    static let days = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    static func time(_ minute: Int) -> String { String(format: "%02d:%02d", minute / 60, minute % 60) }
    static func today(_ date: Date = Date(), calendar: Calendar = .current) -> Int { (calendar.component(.weekday, from: date) + 5) % 7 + 1 }
}

// No automatic execution, no unknown schemes, no fuzzy domain matching.
enum Routing {
    static func httpsURL(_ raw: String) -> URL? {
        guard let c = URLComponents(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
              c.scheme?.lowercased() == "https", let host = c.host, !host.isEmpty,
              c.user == nil, c.password == nil, c.port == nil || c.port == 443,
              let url = c.url else { return nil }
        return url
    }
    static func normalizedHosts(_ raw: String) -> [String] {
        raw.split(whereSeparator: { $0.isWhitespace || $0 == "," || $0 == "，" })
            .map { $0.lowercased() }
            .filter { value in
                guard value.contains("."), let c = URLComponents(string: "https://" + value) else { return false }
                return c.host == value && c.user == nil && c.password == nil && c.port == nil && c.path.isEmpty && c.query == nil && c.fragment == nil && !value.contains("*")
            }
    }
    static func matches(_ raw: String, services: [Service]) -> [Service] {
        guard let host = httpsURL(raw)?.host?.lowercased() else { return [] }
        return services.filter { $0.enabled && normalizedHosts($0.hosts).contains(host) }
    }
}

// Local-only records. They are not provider orders, balances or device state.
struct FavoriteDevice: Codable, Identifiable, Equatable {
    var id = UUID()
    var serviceID: UUID
    var name: String
    var reference: String = "" // optional user-entered public device number, never QR payload
}
struct ExpenseEntry: Codable, Identifiable, Equatable {
    var id = UUID()
    var serviceID: UUID
    var cents: Int
    var date: Date = Date()
    var note: String = ""
}
struct LocalTimer: Codable, Identifiable, Equatable {
    var id = UUID()
    var serviceID: UUID
    var label: String
    var end: Date
    var notificationID: String { "campus.timer.\(id.uuidString)" }
}
struct AccountProfile: Codable, Identifiable, Equatable {
    var id = UUID()
    var serviceID: UUID
}
enum LocalTools {
    static func cents(_ raw: String) -> Int? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let parts = text.split(separator: ".", omittingEmptySubsequences: false)
        guard (1...2).contains(parts.count), !parts[0].isEmpty,
              parts.allSatisfy({ $0.utf8.allSatisfy { (48...57).contains($0) } }),
              let whole = Int(parts[0]), whole <= 100_000 else { return nil }
        let fraction = parts.count == 2 ? String(parts[1]) : ""
        guard fraction.count <= 2 else { return nil }
        let value = whole * 100 + (Int(fraction.padding(toLength: 2, withPad: "0", startingAt: 0)) ?? 0)
        return value > 0 ? value : nil
    }
    static func total(_ entries: [ExpenseEntry], serviceID: UUID, interval: DateInterval) -> Int {
        entries.filter { $0.serviceID == serviceID && $0.date >= interval.start && $0.date < interval.end }.reduce(0) { $0 + $1.cents }
    }
    static func currency(_ cents: Int) -> String { String(format: "¥%d.%02d", cents / 100, cents % 100) }
    static func publicReference(_ text: String) -> Bool {
        text.utf8.count <= 64 && text.utf8.allSatisfy { (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 45 || $0 == 95 }
    }
    struct CourseImport: Decodable {
        let name: String, location: String
        let weekday: Int, start: Int, end: Int
        let detail: CourseDetail?
    }
    enum ImportError: Error { case invalid }
    static func importCourses(_ data: Data) throws -> [Course] {
        guard data.count <= 512_000 else { throw ImportError.invalid }
        let input = try JSONDecoder().decode([CourseImport].self, from: data)
        guard !input.isEmpty, input.count <= 500 else { throw ImportError.invalid }
        return try input.map { row in
            let name = row.name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !name.isEmpty, name.count <= 120, row.location.count <= 120, (1...7).contains(row.weekday), row.start >= 0, row.end < 1440, row.start < row.end, row.detail?.isValid != false else { throw ImportError.invalid }
            return Course(name: name, location: row.location, weekday: row.weekday, start: row.start, end: row.end, detail: row.detail)
        }
    }
    static func mergeCourses(_ existing: [Course], _ incoming: [Course]) -> [Course] {
        var result = existing
        for course in incoming where !result.contains(where: { $0.name == course.name && $0.location == course.location && $0.weekday == course.weekday && $0.start == course.start && $0.end == course.end && $0.detail == course.detail }) { result.append(course) }
        return result
    }
}

// Versioned read-only feed contract. Not the native Kingosoft response format.
struct OnlineCourseSnapshot: Codable, Equatable {
    var courses: [Course]
    var syncedAt: Date
}
enum OnlineCourseFeed {
    enum FeedError: LocalizedError {
        case invalidURL, invalidResponse, invalidData, unauthorized, httpStatus(Int)
        var errorDescription: String? {
            switch self {
            case .invalidURL: return "请输入有效的 HTTPS 课表接口地址（不含账号、查询参数或片段）。"
            case .invalidResponse: return "接口返回了不支持的响应。"
            case .invalidData: return "课表格式无效，旧课表已保留。"
            case .unauthorized: return "授权失效，请检查接口授权设置。"
            case .httpStatus(let status): return "服务器请求失败（HTTP \(status)）。"
            }
        }
    }
    private struct Envelope: Decodable {
        let schemaVersion: Int
        let courses: [LocalTools.CourseImport]
    }
    static func endpoint(_ raw: String) -> URL? {
        guard let url = Routing.httpsURL(raw), let parts = URLComponents(url: url, resolvingAgainstBaseURL: false), parts.query == nil, parts.fragment == nil else { return nil }
        return url
    }
    static func decode(_ data: Data) throws -> [Course] {
        guard data.count <= 512_000, let envelope = try? JSONDecoder().decode(Envelope.self, from: data), envelope.schemaVersion == 1, envelope.courses.count <= 500 else { throw FeedError.invalidData }
        var courses: [Course] = []
        for row in envelope.courses {
            let name = row.name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !name.isEmpty, name.count <= 120, row.location.count <= 120, (1...7).contains(row.weekday), row.start >= 0, row.end < 1440, row.start < row.end, row.detail?.isValid != false else { throw FeedError.invalidData }
            courses.append(Course(name: name, location: row.location, weekday: row.weekday, start: row.start, end: row.end, detail: row.detail))
        }
        return LocalTools.mergeCourses([], courses)
    }
}

// Separate WebKit website-data container per account. No password or cookie in app models.
struct WebAccount: Codable, Identifiable, Equatable {
    var id = UUID()
    let serviceID: UUID
    let entry: String
    var name: String
    var entryURL: URL? { WebLoginRules.entryURL(entry) }
    func belongs(to service: Service) -> Bool { service.id == serviceID && entryURL == WebLoginRules.entryURL(service.url) && entryURL != nil }
}
enum WebLoginRules {
    static func entryURL(_ raw: String) -> URL? {
        guard let url = Routing.httpsURL(raw), let c = URLComponents(url: url, resolvingAgainstBaseURL: false), c.fragment == nil else { return nil }
        let sensitive = ["code", "ticket", "token", "access_token", "id_token", "password", "session", "sessionid", "sso_ticket", "auth_code", "refresh_token"]
        guard !(c.queryItems ?? []).contains(where: { sensitive.contains($0.name.lowercased()) }) else { return nil }
        return url
    }
    static func allowedNavigation(_ url: URL) -> Bool { Routing.httpsURL(url.absoluteString) != nil }
    static func validLabel(_ label: String) -> Bool { let n = label.trimmingCharacters(in: .whitespacesAndNewlines).count; return (1...60).contains(n) }
}

// Optional metadata keeps old local courses and schemaVersion=1 feeds readable.
struct CourseDetail: Codable, Equatable {
    var teacher = ""
    var note = ""
    var term = ""
    var firstWeek = 1
    var lastWeek = 30
    var parity = "all"
    var isValid: Bool {
        teacher.count <= 120 && note.count <= 500 && term.count <= 80 && (1...30).contains(firstWeek) && (firstWeek...30).contains(lastWeek) && ["all", "odd", "even"].contains(parity)
    }
    func includes(term selected: String, week: Int) -> Bool {
        isValid && (term.isEmpty || term == selected) && (firstWeek...lastWeek).contains(week) && (parity == "all" || (parity == "odd" ? week % 2 == 1 : week % 2 == 0))
    }
}
struct AcademicTerm: Codable, Equatable {
    var name = ""
    var start = Date()
    var weeks = 20
    func monday(calendar: Calendar = .current) -> Date {
        let day = calendar.startOfDay(for: start)
        return calendar.date(byAdding: .day, value: 1 - Course.today(day, calendar: calendar), to: day) ?? day
    }
    func currentWeek(on date: Date = Date(), calendar: Calendar = .current) -> Int? {
        guard (1...30).contains(weeks), let days = calendar.dateComponents([.day], from: monday(calendar: calendar), to: calendar.startOfDay(for: date)).day, days >= 0, days < weeks * 7 else { return nil }
        return days / 7 + 1
    }
    func date(week: Int, day: Int, calendar: Calendar = .current) -> Date? {
        guard (1...30).contains(weeks), (1...weeks).contains(week), (1...7).contains(day) else { return nil }
        return calendar.date(byAdding: .day, value: (week - 1) * 7 + day - 1, to: monday(calendar: calendar))
    }
    func includes(_ course: Course, week: Int) -> Bool {
        (1...30).contains(weeks) && (1...weeks).contains(week) && (course.detail?.includes(term: name, week: week) ?? true)
    }
}
extension Service {
    static func activeScope(_ existing: [Service]) -> [Service] {
        var result: [Service] = []
        for service in existing where !result.contains(where: { $0.id == service.id || (service.isBuiltIn && $0.storeID == service.storeID) }) {
            if !service.isBuiltIn || defaults.contains(where: { $0.storeID == service.storeID }) { result.append(service) }
        }
        for service in defaults where !result.contains(where: { $0.storeID == service.storeID }) { result.append(service) }
        return result
    }
}

struct ProviderEvidence {
    let version: String
    let package: String
    let summary: String
    let blocker: String
    let groups: [(String, [String])]
    static func forService(_ service: Service) -> ProviderEvidence? {
        switch service.storeID {
        case "1490809012": return .init(version: "3.1.7", package: "com.cloudora.android", summary: "报告发现混合页面、账号、钱包、订单和设备相关路径。", blocker: "接口授权、请求与响应结构、真实登录及设备授权尚未验证。", groups: [
            ("设备", ["淋浴", "洗烘", "饮水", "吹风", "设备信息", "设备状态", "添加设备", "使用结算"]),
            ("账户", ["钱包与余额", "充值", "卡包", "卡密激活", "卡券", "我的账单", "历史订单", "退款"]),
            ("支持", ["我的工单", "常见问题", "在线客服", "意见反馈", "考勤打卡"])
        ])
        case "1152127141": return .init(version: "2.6.458", package: "com.kingosoft.activity_kb_common", summary: "报告发现原生教务页面及通用 WebView 容器；学校端接口尚未确定。", blocker: "需要学校支持的登录入口、授权课表接口及学期、节次和课程字段。", groups: [])
        case "1142157881": return .init(version: "2.4.21", package: "com.midea.vm.washer", summary: "报告发现 Weex 页面、原生扫码、BLE、支付及第三方登录组件。", blocker: "需要授权接口、设备与订单数据模型、官方支付及进度接口；Android 入口不能证明 iOS 可用。", groups: [
            ("设备服务", ["附近洗衣房", "设备列表", "洗衣", "烘干", "饮水", "淋浴", "吹风", "空调", "设备状态", "扫码下单", "预约"]),
            ("订单与支付", ["洗衣模式与价格", "官方支付", "订单查询", "洗衣实时进度", "历史订单", "余额", "退款及异常订单", "门店券"]),
            ("账号与支持", ["个人信息", "手机改绑", "账号注销", "隐私设置", "在线客服"])
        ])
        case "1264484428": return .init(version: "6.5.30", package: "com.klcxkj.zqxy", summary: "报告发现网络、BLE、经典蓝牙设备页面，以及充值、卡包、工单等模块。", blocker: "设备协议和正式授权接口未确认；具体设备的 iOS 通信兼容性需供应商确认。", groups: [
            ("设备服务", ["设备搜索", "洗衣", "饮水", "淋浴", "吹风", "充电", "公寓设备", "设备状态", "使用结算"]),
            ("钱包与订单", ["钱包与余额", "充值", "卡包", "优惠券", "历史订单", "澡堂订单", "消费账单"]),
            ("账号与支持", ["个人信息", "手机改绑", "账号安全", "消息通知", "工单报修", "意见反馈", "在线客服"])
        ])
        default: return nil
        }
    }
}
