import Foundation
import SwiftUI
import Security

@MainActor final class CampusStore: ObservableObject {
    @Published var services: [Service] { didSet { persist(services, key: "services.v1") } }
    @Published var term: AcademicTerm { didSet { persist(term, key: "academic.term.v1") } }
    @Published var courses: [Course] { didSet { persist(courses, key: "courses.v1") } }
    @Published var devices: [FavoriteDevice] { didSet { persist(devices, key: "devices.v1") } }
    @Published var expenses: [ExpenseEntry] { didSet { persist(expenses, key: "expenses.v1") } }
    @Published var timers: [LocalTimer] { didSet { persist(timers, key: "timers.v1") } }
    @Published var profiles: [AccountProfile] { didSet { persist(profiles, key: "profiles.v1") } }
    @Published var webAccounts: [WebAccount] { didSet { persist(webAccounts, key: "web.accounts.v1") } }
    @Published private(set) var onlineEndpoint: String { didSet { persist(onlineEndpoint, key: "course.endpoint.v1") } }
    @Published private(set) var onlineSnapshot: OnlineCourseSnapshot? { didSet { persist(onlineSnapshot, key: "course.snapshot.v1") } }
    @Published var refreshOnOpen: Bool { didSet { persist(refreshOnOpen, key: "course.auto.v1") } }
    @Published private(set) var refreshing = false
    @Published private(set) var syncError: String?
    private var syncGeneration = UUID()
    var displayedCourses: [Course] { LocalTools.mergeCourses(courses, onlineSnapshot?.courses ?? []) }
    @Published var storageError: String? = nil
    private let defaults = UserDefaults.standard
    init() {
        services = Service.activeScope(Self.load([Service].self, key: "services.v1") ?? Service.defaults)
        term = Self.load(AcademicTerm.self, key: "academic.term.v1") ?? AcademicTerm()
        courses = Self.load([Course].self, key: "courses.v1") ?? []
        devices = Self.load([FavoriteDevice].self, key: "devices.v1") ?? []
        expenses = Self.load([ExpenseEntry].self, key: "expenses.v1") ?? []
        timers = Self.load([LocalTimer].self, key: "timers.v1") ?? []
        onlineEndpoint = Self.load(String.self, key: "course.endpoint.v1") ?? ""
        onlineSnapshot = Self.load(OnlineCourseSnapshot.self, key: "course.snapshot.v1")
        refreshOnOpen = Self.load(Bool.self, key: "course.auto.v1") ?? false
        webAccounts = Self.load([WebAccount].self, key: "web.accounts.v1") ?? []
        profiles = Self.load([AccountProfile].self, key: "profiles.v1") ?? []
    }
    private static func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }
    private func persist<T: Encodable>(_ value: T, key: String) {
        do { defaults.set(try JSONEncoder().encode(value), forKey: key) }
        catch { storageError = "本地配置保存失败。" }
    }
    func save(_ service: Service) {
        if let index = services.firstIndex(where: { $0.id == service.id }) { services[index] = service }
        else { services.append(service) }
    }
    func save(_ course: Course) {
        if let index = courses.firstIndex(where: { $0.id == course.id }) { courses[index] = course }
        else { courses.append(course) }
    }
    // A new feed or credential is a different account context; never show the old cache.
    func configureOnline(_ endpoint: String, token: String, auto: Bool) -> Bool {
        let normalized = endpoint.trimmingCharacters(in: .whitespacesAndNewlines)
        guard normalized.isEmpty || OnlineCourseFeed.endpoint(normalized) != nil else { return false }
        guard !token.contains("\r"), !token.contains("\n"), token.utf8.count <= 4096 else { return false }
        let previousToken = CourseFeedVault.read()
        let newToken = normalized.isEmpty ? "" : token
        guard CourseFeedVault.write(newToken) else { return false }
        if onlineEndpoint != normalized || previousToken != newToken {
            syncGeneration = UUID(); onlineSnapshot = nil; refreshing = false; syncError = nil
            onlineEndpoint = normalized
        }
        refreshOnOpen = auto && !normalized.isEmpty
        return true
    }
    func refreshOnline() async {
        guard !refreshing, let url = OnlineCourseFeed.endpoint(onlineEndpoint) else { return }
        refreshing = true; syncError = nil
        let generation = syncGeneration
        defer { if generation == syncGeneration { refreshing = false } }
        do {
            let incoming = try await CourseFeedClient.fetch(url, token: CourseFeedVault.read())
            guard generation == syncGeneration, !Task.isCancelled else { return }
            onlineSnapshot = OnlineCourseSnapshot(courses: incoming, syncedAt: Date())
        } catch {
            guard generation == syncGeneration, !Task.isCancelled else { return }
            syncError = (error as? OnlineCourseFeed.FeedError)?.localizedDescription ?? "网络连接失败，保留上次同步的课表。"
        }
    }
    func remove(_ service: Service) { services.removeAll { $0.id == service.id } }
}

// Stores account labels only, never passwords or third-party login tokens.
enum AccountVault {
    private static func query(_ id: UUID) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "CampusOne.account-label.v1",
         kSecAttrAccount as String: id.uuidString]
    }
    static func read(_ id: UUID) -> String {
        var q = query(id); q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &value) == errSecSuccess, let data = value as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func write(_ value: String, id: UUID) -> Bool {
        let q = query(id)
        if value.isEmpty {
            let status = SecItemDelete(q as CFDictionary)
            return status == errSecSuccess || status == errSecItemNotFound
        }
        let data = Data(value.utf8)
        let status = SecItemUpdate(q as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return true }
        guard status == errSecItemNotFound else { return false }
        var new = q; new[kSecValueData as String] = data; new[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        return SecItemAdd(new as CFDictionary, nil) == errSecSuccess
    }
}

// Dedicated Keychain namespace for an explicitly authorized read-only feed token.
enum CourseFeedVault {
    private static let key: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "CampusOne.course-feed.v1", kSecAttrAccount as String: "active-feed"]
    static func read() -> String {
        var query = key; query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func write(_ value: String) -> Bool {
        if value.isEmpty { let status = SecItemDelete(key as CFDictionary); return status == errSecSuccess || status == errSecItemNotFound }
        let data = Data(value.utf8)
        let status = SecItemUpdate(key as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return true }
        guard status == errSecItemNotFound else { return false }
        var query = key; query[kSecValueData as String] = data; query[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        return SecItemAdd(query as CFDictionary, nil) == errSecSuccess
    }
}

private final class CourseFeedClient: NSObject, URLSessionTaskDelegate {
    // Do not forward credentials to redirected destinations.
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
    static func fetch(_ url: URL, token: String) async throws -> [Course] {
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false; config.httpCookieStorage = nil; config.urlCredentialStorage = nil
        config.timeoutIntervalForRequest = 15; config.timeoutIntervalForResource = 30
        let session = URLSession(configuration: config, delegate: CourseFeedClient(), delegateQueue: nil)
        defer { session.finishTasksAndInvalidate() }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if !token.isEmpty { request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization") }
        let (bytes, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse else { throw OnlineCourseFeed.FeedError.invalidResponse }
        if http.statusCode == 401 || http.statusCode == 403 { throw OnlineCourseFeed.FeedError.unauthorized }
        guard http.statusCode == 200 else { throw OnlineCourseFeed.FeedError.httpStatus(http.statusCode) }
        guard http.mimeType == "application/json", http.expectedContentLength <= 512_000 else { throw OnlineCourseFeed.FeedError.invalidResponse }
        var data = Data()
        for try await byte in bytes { guard data.count < 512_000 else { throw OnlineCourseFeed.FeedError.invalidData }; data.append(byte) }
        return try OnlineCourseFeed.decode(data)
    }
}
