import SwiftUI
import SafariServices

struct ServicesView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var add = false
    var body: some View {
        List {
            Section("我的服务") {
                ForEach(store.services) { service in
                    NavigationLink { ServiceDetail(id: service.id) } label: {
                        HStack { ServiceRow(service: service); if !service.enabled { Text("已停用").font(.caption).foregroundStyle(.secondary) } }
                    }
                }.onMove { store.services.move(fromOffsets: $0, toOffset: $1) }
            }
            Section { Button("添加自定义网页", systemImage: "plus") { add = true } }
            Section { Text("内置服务使用各平台的官方入口。深度接口尚未接入；网页服务可由用户自行配置，不绑定学校。") .font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("服务").toolbar { EditButton(); Button("添加", systemImage: "plus") { add = true } }
            .sheet(isPresented: $add) { NavigationStack { ServiceEditor(service: Service(name: "", category: "网页", symbol: "globe", tint: "green")) } }
    }
}

struct ServiceDetail: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.openURL) private var openURL
    @Environment(\.dismiss) private var dismiss
    let id: UUID
    @State private var edit = false
    @State private var account = false
    @State private var remove = false
    @State private var safariURL: PresentedURL?
    @State private var message: String?
    var body: some View {
        Group {
            if let service = store.services.first(where: { $0.id == id }) {
                List {
                    Section { HStack { Spacer(); VStack(spacing: 10) { ServiceIcon(service: service); Text(service.name).font(.title2.bold()); Text(service.category).foregroundStyle(.secondary) }; Spacer() }.padding(.vertical, 12) }
                    Section("打开服务") {
                        if let url = Routing.httpsURL(service.url) {
                            Button(service.isBuiltIn ? "打开配置的官方入口" : "打开网页", systemImage: "arrow.up.forward.app") {
                                if service.externalBrowser || service.isBuiltIn { openURL(url) { accepted in if !accepted { message = "无法打开该链接。" } } }
                                else { safariURL = PresentedURL(url: url) }
                            }.disabled(!service.enabled)
                        }
                        if let url = service.storeURL {
                            Link(destination: url) { Label("前往 App Store 官方页面", systemImage: "apple.logo") }
                            Text("此入口是 App Store 页面，不是直接启动或登录原 App。可在官方页面打开已安装应用（取决于系统）。") .font(.footnote).foregroundStyle(.secondary)
                        }
                        if service.isBuiltIn { Label("真实 API / 设备控制待接入", systemImage: "info.circle").foregroundStyle(.secondary) }
                    }
                    Section("独立账号") {
                        Button("管理账号备注", systemImage: "person.crop.circle") { account = true }
                        Text("本版本仅保存账号备注；实际登录、退出、余额和支付均在各原平台处理，不会共享密码或登录状态。") .font(.footnote).foregroundStyle(.secondary)
                    }
                    if service.isBuiltIn { ProviderTools(service: service) }
                    Section("服务设置") {
                        LabeledContent("状态", value: service.enabled ? "已启用" : "已停用")
                        LabeledContent("首页显示", value: service.showOnHome ? "是" : "否")
                        LabeledContent("扫码规则", value: Routing.normalizedHosts(service.hosts).isEmpty ? "未配置" : "\(Routing.normalizedHosts(service.hosts).count) 个域名")
                        Button("编辑服务", systemImage: "slider.horizontal.3") { edit = true }
                        if !service.isBuiltIn { Button("删除网页服务", role: .destructive) { remove = true } }
                    }
                }.navigationTitle(service.name).navigationBarTitleDisplayMode(.inline)
                    .sheet(isPresented: $edit) { NavigationStack { ServiceEditor(service: service) } }
                    .sheet(isPresented: $account) { NavigationStack { AccountEditor(service: service) } }
                    .sheet(item: $safariURL) { item in SafariPage(url: item.url).ignoresSafeArea() }
                    .confirmationDialog("删除本地服务及账号备注？", isPresented: $remove, titleVisibility: .visible) {
                        Button("删除", role: .destructive) {
                            if AccountVault.write("", id: id) { store.remove(service); dismiss() }
                            else { message = "无法清除账号备注，服务未删除。" }
                        }
                    } message: { Text("不会删除原平台账号或网页浏览会话。") }
                    .alert("提示", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) { Button("确定") { message = nil } } message: { Text(message ?? "") }
            } else { ContentUnavailableView("服务不存在", systemImage: "exclamationmark.circle") }
        }
    }
}

struct PresentedURL: Identifiable { let id = UUID(); let url: URL }
struct SafariPage: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> SFSafariViewController { SFSafariViewController(url: url) }
    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}

struct ServiceEditor: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State var service: Service
    @State private var error: String?
    private let icons = ["globe", "clipboard", "calendar", "book", "creditcard", "graduationcap", "building.2", "link"]
    var body: some View {
        Form {
            Section("基本信息") {
                TextField("服务名称", text: $service.name).disabled(service.isBuiltIn)
                TextField("服务分类", text: $service.category)
                if !service.isBuiltIn { Picker("图标", selection: $service.symbol) { ForEach(icons, id: \.self) { Label($0, systemImage: $0).tag($0) } } }
                Toggle("启用服务", isOn: $service.enabled)
                Toggle("显示在首页", isOn: $service.showOnHome)
            }
            Section {
                TextField("https://…", text: $service.url).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                if !service.isBuiltIn { Toggle("使用系统浏览器", isOn: $service.externalBrowser) }
            } header: { Text(service.isBuiltIn ? "官方 HTTPS 入口（可选）" : "网页链接（必填）") } footer: {
                Text("仅接受 HTTPS。请填写稳定的官方入口，不要粘贴含临时登录码、票据、密码或令牌的链接。企业微信等认证若不支持应用内浏览，请使用原平台。")
            }
            Section {
                TextField("例如 devices.example.com", text: $service.hosts, axis: .vertical).textInputAutocapitalization(.never).autocorrectionDisabled()
            } header: { Text("二维码域名规则（可选）") } footer: { Text("只填写已验证属于该服务商的设备二维码域名，可用空格或逗号分隔。不支持通配符；相同域名出现于多个服务时要求手动选择。") }
        }.navigationTitle("服务配置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("保存", action: save) } }
            .alert("配置有误", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("确定") { error = nil } } message: { Text(error ?? "") }
    }
    private func save() {
        service.name = service.name.trimmingCharacters(in: .whitespacesAndNewlines)
        service.category = service.category.trimmingCharacters(in: .whitespacesAndNewlines)
        service.url = service.url.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !service.name.isEmpty, !service.category.isEmpty else { error = "请填写名称和分类。"; return }
        if !service.isBuiltIn || !service.url.isEmpty {
            guard let url = Routing.httpsURL(service.url) else { error = "请填写有效的 HTTPS 链接。"; return }
            let sensitive = ["code", "ticket", "token", "access_token", "id_token", "password", "session", "sessionid", "sso_ticket", "auth_code"]
            if URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.contains(where: { sensitive.contains($0.name.lowercased()) }) == true {
                error = "链接含可能用于登录的一次性参数，请填写稳定的服务入口。"; return
            }
        }
        let rawHosts = service.hosts.split(whereSeparator: { $0.isWhitespace || $0 == "," || $0 == "，" })
        let hosts = Routing.normalizedHosts(service.hosts)
        guard rawHosts.count == hosts.count else { error = "二维码规则只能填写完整域名，不可包含路径或通配符。"; return }
        service.hosts = hosts.joined(separator: ", ")
        store.save(service); dismiss()
    }
}

struct AccountEditor: View {
    @Environment(\.dismiss) private var dismiss
    let service: Service
    @State private var label = ""
    @State private var error = false
    var body: some View {
        Form {
            Section(service.name) {
                TextField("账号备注（如手机号后四位）", text: $label).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("清除本地备注", role: .destructive) { if AccountVault.write("", id: service.id) { label = ""; dismiss() } else { error = true } }
            }
            Section { Text("备注独立加密保存在本机 Keychain。请不要输入密码、验证码或令牌。备注不代表已登录；切换真实账号请前往原平台。") .foregroundStyle(.secondary) }
        }.navigationTitle("账号与授权").navigationBarTitleDisplayMode(.inline)
            .onAppear { label = AccountVault.read(service.id) }
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("保存") { if AccountVault.write(label.trimmingCharacters(in: .whitespacesAndNewlines), id: service.id) { dismiss() } else { error = true } } } }
            .alert("Keychain 保存失败", isPresented: $error) { Button("确定", role: .cancel) {} }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var account: Service?
    @AppStorage("appearance") private var appearance = "system"
    var body: some View {
        List {
            Section("各平台独立账号") {
                ForEach(store.services) { service in
                    Button { account = service } label: { HStack { ServiceRow(service: service); Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary) } }.buttonStyle(.plain)
                }
            }
            Section("外观") { Picker("显示模式", selection: $appearance) { Text("跟随系统").tag("system"); Text("浅色").tag("light"); Text("深色").tag("dark") } }
            Section("服务与隐私") {
                NavigationLink("服务管理") { ServicesView() }
                NavigationLink("隐私与使用说明") {
                    List {
                        Section("数据") { Text("服务配置、手动课表、设备收藏、手动消费及计时记录保存在本机；账号备注保存在 Keychain。本版本不向 Campus One 服务器上传数据，也不保存扫码历史。") }
                        Section("第三方服务") { Text("打开原服务时，其登录、支付、数据处理及网页会话遵循各服务商的规则。应用内 Safari 网页不会提供逐服务的独立登录容器。") }
                        Section("安全") { Text("二维码只做本地识别，不自动打开链接、不自动启动设备、不自动支付。请核对目标平台和设备。") }
                    }.navigationTitle("隐私与使用说明")
                }
            }
            Section("关于") { LabeledContent("版本", value: "0.3.0 · 开发预览"); Text("独立校园服务聚合工具，非任何学校或服务商官方产品。无自有广告。") .font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("设置").sheet(item: $account) { service in NavigationStack { AccountEditor(service: service) } }
    }
}
