import SwiftUI

struct CourseRow: View {
    let course: Course
    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) { Text(Course.time(course.start)).font(.headline.monospacedDigit()); Text(Course.time(course.end)).font(.caption.monospacedDigit()).foregroundStyle(.secondary) }.frame(width: 57, alignment: .leading)
            RoundedRectangle(cornerRadius: 2).fill(Color.orange).frame(width: 4)
            VStack(alignment: .leading, spacing: 4) { Text(course.name).font(.headline); if !course.location.isEmpty { Label(course.location, systemImage: "mappin").font(.caption).foregroundStyle(.secondary) } }
            Spacer()
        }.padding(.vertical, 5)
    }
}
struct CoursesView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var day = Course.today()
    @State private var editing: Course?
    var body: some View {
        List {
            Section {
                Picker("星期", selection: $day) { ForEach(1...7, id: \.self) { Text(Course.days[$0-1]).tag($0) } }.pickerStyle(.segmented)
            }
            Section("\(Course.days[day-1]) · 本地课表") {
                let courses = store.courses.filter { $0.weekday == day }.sorted { $0.start < $1.start }
                if courses.isEmpty { ContentUnavailableView("暂无课程", systemImage: "calendar", description: Text("点击右上角添加课程")) }
                ForEach(courses) { course in Button { editing = course } label: { CourseRow(course: course) }.buttonStyle(.plain) }
                    .onDelete { offsets in let ids = Set(offsets.map { courses[$0].id }); store.courses.removeAll { ids.contains($0.id) } }
            }
            Section {
                NavigationLink { CourseImportView() } label: { Label("批量导入本地课表", systemImage: "square.and.arrow.down") }
                if let service = store.services.first(where: { $0.storeID == "1152127141" }) {
                    NavigationLink { ServiceDetail(id: service.id) } label: { Label("喜鹊儿官方入口", systemImage: "arrow.up.forward.app") }
                }
                Text("本地课表按星期循环显示，暂不区分教学周、单双周、节假日及调课。喜鹊儿自动同步尚未接入。") .font(.footnote).foregroundStyle(.secondary)
            }
        }.navigationTitle("课表").toolbar { Button("添加课程", systemImage: "plus") { editing = Course(name: "", location: "", weekday: day, start: 480, end: 570) } }
            .sheet(item: $editing) { course in NavigationStack { CourseEditor(course: course) } }
    }
}
struct CourseEditor: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State var course: Course
    private func date(_ minutes: Int) -> Date { Calendar.current.date(from: DateComponents(year: 2024, month: 1, day: 1, hour: minutes / 60, minute: minutes % 60)) ?? Date() }
    private func minutes(_ date: Date) -> Int { Calendar.current.component(.hour, from: date) * 60 + Calendar.current.component(.minute, from: date) }
    var body: some View {
        Form {
            TextField("课程名称", text: $course.name)
            TextField("上课地点", text: $course.location)
            Picker("星期", selection: $course.weekday) { ForEach(1...7, id: \.self) { Text(Course.days[$0-1]).tag($0) } }
            DatePicker("开始时间", selection: Binding(get: { date(course.start) }, set: { course.start = minutes($0) }), displayedComponents: .hourAndMinute)
            DatePicker("结束时间", selection: Binding(get: { date(course.end) }, set: { course.end = minutes($0) }), displayedComponents: .hourAndMinute)
            if course.end <= course.start { Text("结束时间必须晚于开始时间。") .foregroundStyle(.red) }
        }.navigationTitle("编辑课程").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("保存") { course.name = course.name.trimmingCharacters(in: .whitespacesAndNewlines); store.save(course); dismiss() }.disabled(course.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || course.end <= course.start) } }
    }
}
