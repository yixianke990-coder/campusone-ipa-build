import Foundation
import SwiftUI
import Security

@MainActor final class CampusStore: ObservableObject {
    @Published var services: [Service] { didSet { persist(services, key: "services.v1") } }
    @Published var courses: [Course] { didSet { persist(courses, key: "courses.v1") } }
    @Published var devices: [FavoriteDevice] { didSet { persist(devices, key: "devices.v1") } }
    @Published var expenses: [ExpenseEntry] { didSet { persist(expenses, key: "expenses.v1") } }
    @Published var timers: [LocalTimer] { didSet { persist(timers, key: "timers.v1") } }
    @Published var profiles: [AccountProfile] { didSet { persist(profiles, key: "profiles.v1") } }
    @Published var storageError: String? = nil
    private let defaults = UserDefaults.standard
    init() {
        services = Self.load([Service].self, key: "services.v1") ?? Service.defaults
        courses = Self.load([Course].self, key: "courses.v1") ?? []
        devices = Self.load([FavoriteDevice].self, key: "devices.v1") ?? []
        expenses = Self.load([ExpenseEntry].self, key: "expenses.v1") ?? []
        timers = Self.load([LocalTimer].self, key: "timers.v1") ?? []
        profiles = Self.load([AccountProfile].self, key: "profiles.v1") ?? []
    }
    private static func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }
    private func persist<T: Encodable>(_ value: T, key: String) {
        do { defaults.set(try JSONEncoder().encode(value), forKey: key) }
        catch { storageError = "本地配置保存失败。" }
    }
    func save(_ service: Service) {
        if let index = services.firstIndex(where: { $0.id == service.id }) { services[index] = service }
        else { services.append(service) }
    }
    func save(_ course: Course) {
        if let index = courses.firstIndex(where: { $0.id == course.id }) { courses[index] = course }
        else { courses.append(course) }
    }
    func remove(_ service: Service) { services.removeAll { $0.id == service.id } }
}

// Stores account labels only, never passwords or third-party login tokens.
enum AccountVault {
    private static func query(_ id: UUID) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "CampusOne.account-label.v1",
         kSecAttrAccount as String: id.uuidString]
    }
    static func read(_ id: UUID) -> String {
        var q = query(id); q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &value) == errSecSuccess, let data = value as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func write(_ value: String, id: UUID) -> Bool {
        let q = query(id)
        if value.isEmpty {
            let status = SecItemDelete(q as CFDictionary)
            return status == errSecSuccess || status == errSecItemNotFound
        }
        let data = Data(value.utf8)
        let status = SecItemUpdate(q as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return true }
        guard status == errSecItemNotFound else { return false }
        var new = q; new[kSecValueData as String] = data; new[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        return SecItemAdd(new as CFDictionary, nil) == errSecSuccess
    }
}
