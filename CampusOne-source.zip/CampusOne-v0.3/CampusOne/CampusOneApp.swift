import SwiftUI

@main struct CampusOneApp: App {
    @StateObject private var store = CampusStore()
    @AppStorage("appearance") private var appearance = "system"
    var body: some Scene {
        WindowGroup { RootView().environmentObject(store).tint(.blue).preferredColorScheme(appearance == "light" ? .light : appearance == "dark" ? .dark : nil) }
    }
}

enum MainTab: Hashable { case home, courses, services, settings, search }

struct RootView: View {
    @State private var tab: MainTab = .home
    @EnvironmentObject private var store: CampusStore
    var body: some View {
        Group {
            if #available(iOS 26, *) { tabs.tabBarMinimizeBehavior(.onScrollDown) }
            else { tabs }
        }
        .alert("保存失败", isPresented: Binding(get: { store.storageError != nil }, set: { if !$0 { store.storageError = nil } })) {
            Button("确定", role: .cancel) { store.storageError = nil }
        } message: { Text(store.storageError ?? "") }
    }
    private var tabs: some View {
        TabView(selection: $tab) {
            Tab("首页", systemImage: "house", value: MainTab.home) { NavigationStack { HomeView(tab: $tab) } }
            Tab("课表", systemImage: "calendar", value: MainTab.courses) { NavigationStack { CoursesView() } }
            Tab("服务", systemImage: "square.grid.2x2", value: MainTab.services) { NavigationStack { ServicesView() } }
            Tab("设置", systemImage: "gearshape", value: MainTab.settings) { NavigationStack { SettingsView() } }
            Tab(value: MainTab.search, role: .search) { NavigationStack { SearchView() } }
        }
    }
}

extension Service {
    var color: Color {
        switch tint { case "blue": .blue; case "orange": .orange; case "indigo": .indigo; case "teal": .teal; default: .green }
    }
}
struct ServiceIcon: View {
    let service: Service
    var body: some View {
        Image(systemName: service.symbol).font(.title2.weight(.medium))
            .foregroundStyle(service.color).frame(width: 50, height: 50)
            .background(service.color.opacity(0.12), in: RoundedRectangle(cornerRadius: 15))
    }
}
struct ServiceRow: View {
    let service: Service
    var body: some View {
        HStack(spacing: 12) {
            ServiceIcon(service: service)
            VStack(alignment: .leading, spacing: 4) {
                Text(service.name).font(.headline)
                Text(service.category + (service.isBuiltIn ? " · 官方入口 / 待适配" : " · 网页服务")).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
    }
}
struct HomeView: View {
    @EnvironmentObject private var store: CampusStore
    @Binding var tab: MainTab
    @State private var scan = false
    var today: [Course] { store.courses.filter { $0.weekday == Course.today() }.sorted { $0.start < $1.start } }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text(Date.now.formatted(.dateTime.month().day().weekday(.wide))).font(.subheadline).foregroundStyle(.secondary)
                VStack(alignment: .leading, spacing: 12) {
                    HStack { Label("今日课程", systemImage: "calendar").font(.headline); Spacer(); Button("完整课表") { tab = .courses }.font(.subheadline) }
                    if today.isEmpty { Text("暂无本地课程").font(.title2.bold()); Text("添加课程后在这里显示今日安排。").font(.subheadline).foregroundStyle(.secondary) }
                    else { ForEach(today) { CourseRow(course: $0) } }
                }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 24))
                HStack { Text("我的服务").font(.title2.bold()); Spacer(); Button("管理") { tab = .services } }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 12) {
                    ForEach(store.services.filter { $0.enabled && $0.showOnHome }) { service in
                        NavigationLink { ServiceDetail(id: service.id) } label: {
                            VStack(spacing: 7) { ServiceIcon(service: service); Text(service.category).font(.subheadline.weight(.medium)); Text(service.name).font(.caption2).foregroundStyle(.secondary).lineLimit(1) }
                                .frame(maxWidth: .infinity).padding(.vertical, 14).background(.background, in: RoundedRectangle(cornerRadius: 20))
                        }.buttonStyle(.plain)
                    }
                    Button { tab = .services } label: {
                        VStack(spacing: 8) { Image(systemName: "plus").font(.title2).frame(width: 50,height: 50); Text("添加服务").font(.subheadline); Text("自定义").font(.caption2).foregroundStyle(.secondary) }.frame(maxWidth: .infinity).padding(.vertical, 14).background(.background, in: RoundedRectangle(cornerRadius: 20))
                    }.buttonStyle(.plain)
                }
                Button { scan = true } label: {
                    HStack(spacing: 14) { Image(systemName: "qrcode.viewfinder").font(.largeTitle); VStack(alignment: .leading) { Text("扫一扫").font(.headline); Text("精确匹配 · 手动确认").font(.caption) }; Spacer(); Image(systemName: "chevron.right") }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
                }.buttonStyle(.borderedProminent).buttonBorderShape(.roundedRectangle(radius: 20))
            }.padding(20)
        }.background(Color(uiColor: .systemGroupedBackground)).navigationTitle("Campus One")
            .sheet(isPresented: $scan) { NavigationStack { ScanView() } }
    }
}

struct SearchView: View {
    @EnvironmentObject private var store: CampusStore
    @State private var query = ""
    var body: some View {
        List {
            ForEach(store.services.filter { $0.enabled && (query.isEmpty || ($0.name + $0.category).localizedCaseInsensitiveContains(query)) }) { service in
                NavigationLink { ServiceDetail(id: service.id) } label: { ServiceRow(service: service) }
            }
            let courses = store.courses.filter { !query.isEmpty && ($0.name + $0.location).localizedCaseInsensitiveContains(query) }
            if !courses.isEmpty { Section("课程") { ForEach(courses) { CourseRow(course: $0) } } }
        }.navigationTitle("搜索").searchable(text: $query, prompt: "搜索校园服务、课程")
    }
}
