import SwiftUI
import VisionKit
import AVFoundation
import UIKit
import PhotosUI
import Vision
import ImageIO

struct ScanView: View {
    @EnvironmentObject private var store: CampusStore
    @Environment(\.dismiss) private var dismiss
    @State private var raw = ""
    @State private var photo: PhotosPickerItem?
    @State private var scanning = false
    @State private var status = ""
    @State private var selected: UUID?
    @State private var copied = false
    var matches: [Service] { Routing.matches(raw, services: store.services) }
    var choices: [Service] { matches.isEmpty ? store.services.filter { $0.enabled } : matches }
    var body: some View {
        List {
            Section {
                Button("启动相机扫码", systemImage: "qrcode.viewfinder") { requestCamera() }
                PhotosPicker(selection: $photo, matching: .images) { Label("从相册识别二维码", systemImage: "photo") }

                if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(.secondary) }
                TextField("或粘贴设备二维码内容", text: $raw, axis: .vertical).textInputAutocapitalization(.never).autocorrectionDisabled().lineLimit(2...5)
                if !raw.isEmpty { Button("清空") { raw = ""; selected = nil; copied = false } }
            } footer: { Text("只支持标准二维码；专有小程序码、蓝牙设备码等需要各平台支持。相机不可用时可手动粘贴。") }
            if !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Section("识别结果") {
                    if matches.count == 1 { Label("规则匹配：\(matches[0].name)", systemImage: "checkmark.circle").foregroundStyle(.green) }
                    else if matches.count > 1 { Label("多个服务匹配，请手动确认", systemImage: "exclamationmark.triangle").foregroundStyle(.orange) }
                    else { Label("无法确定服务商", systemImage: "questionmark.circle").foregroundStyle(.secondary) }
                    if let host = Routing.httpsURL(raw)?.host { LabeledContent("二维码域名", value: host) }
                    else { Text("非标准 HTTPS 链接，不自动解析设备信息。") .font(.footnote).foregroundStyle(.secondary) }
                    if choices.isEmpty { Text("没有可用的服务，请先启用服务。") }
                    else {
                        Picker("选择服务", selection: $selected) {
                            Text("请选择").tag(nil as UUID?)
                            ForEach(choices) { service in Text(service.name).tag(Optional(service.id)) }
                        }
                        if let id = selected ?? (matches.count == 1 ? matches[0].id : nil), choices.contains(where: { $0.id == id }) {
                            NavigationLink { ServiceDetail(id: id) } label: { Label("确认并打开服务入口", systemImage: "arrow.up.forward.app") }
                        }
                    }
                    Button(copied ? "已复制" : "复制二维码原文", systemImage: "doc.on.doc") {
                        UIPasteboard.general.setItems([["public.utf8-plain-text": raw]], options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(120)]); copied = true
                    }
                    Text("打开服务入口不会自动传入设备编号、启动设备或付款。请在原平台确认设备。二维码原文不写入历史。") .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }.navigationTitle("扫一扫").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
            .onChange(of: photo) { _, item in
                guard let item else { return }
                Task { await readPhoto(item) }
            }
            .onChange(of: raw) { _, _ in selected = nil; copied = false }
            .fullScreenCover(isPresented: $scanning) {
                NavigationStack {
                    CameraScanner(onCode: { code in raw = code; scanning = false }, onError: { text in status = text; scanning = false })
                        .ignoresSafeArea(edges: .bottom).navigationTitle("扫描设备二维码").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { scanning = false } } }
                }
            }
    }
    @MainActor private func readPhoto(_ item: PhotosPickerItem) async {
        do {
            guard let data = try await item.loadTransferable(type: Data.self), data.count <= 30_000_000 else { status = "图片不可用或超过大小限制。"; return }
            let codes = try await Task.detached(priority: .userInitiated) { () throws -> [String] in
                let request = VNDetectBarcodesRequest(); request.symbologies = [.qr]
                try VNImageRequestHandler(data: data).perform([request])
                return Array(Set((request.results ?? []).compactMap(\.payloadStringValue)))
            }.value
            guard photo == item else { return }
            if codes.count == 1 { raw = codes[0]; status = "已识别相册二维码。" }
            else { raw = ""; status = codes.isEmpty ? "图片中未识别到标准二维码。" : "图片中存在多个二维码，请裁剪后重试。" }
        } catch { if photo == item { status = "图片识别失败。" } }
    }
    private func requestCamera() {
        guard DataScannerViewController.isSupported else { status = "当前设备不支持系统扫码（模拟器也不可用）。可粘贴二维码原文。"; return }
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: startIfAvailable()
        case .notDetermined:
            Task { if await AVCaptureDevice.requestAccess(for: .video) { startIfAvailable() } else { status = "未授权相机，可在系统设置开启。" } }
        default: status = "相机权限不可用，请前往系统设置，或粘贴原文。"
        }
    }
    private func startIfAvailable() {
        guard DataScannerViewController.isAvailable else { status = "相机当前不可用。"; return }
        status = ""; scanning = true
    }
}

struct CameraScanner: UIViewControllerRepresentable {
    let onCode: (String) -> Void
    let onError: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> ScannerContainer {
        let scanner = DataScannerViewController(recognizedDataTypes: [.barcode(symbologies: [.qr])], qualityLevel: .balanced, recognizesMultipleItems: false, isHighFrameRateTrackingEnabled: true, isPinchToZoomEnabled: true, isGuidanceEnabled: true, isHighlightingEnabled: true)
        scanner.delegate = context.coordinator
        return ScannerContainer(scanner: scanner, onError: onError)
    }
    func updateUIViewController(_ uiViewController: ScannerContainer, context: Context) { context.coordinator.parent = self }
    static func dismantleUIViewController(_ uiViewController: ScannerContainer, coordinator: Coordinator) { uiViewController.scanner.stopScanning() }
    final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        var parent: CameraScanner
        var delivered = false
        init(_ parent: CameraScanner) { self.parent = parent }
        func dataScanner(_ dataScanner: DataScannerViewController, didAdd addedItems: [RecognizedItem], allItems: [RecognizedItem]) {
            guard !delivered else { return }
            for item in addedItems {
                if case .barcode(let barcode) = item, let value = barcode.payloadStringValue, !value.isEmpty {
                    delivered = true; dataScanner.stopScanning(); parent.onCode(value); return
                }
            }
        }
        func dataScanner(_ dataScanner: DataScannerViewController, becameUnavailableWithError error: DataScannerViewController.ScanningUnavailable) {
            if !delivered { delivered = true; parent.onError("扫码不可用，请重试或粘贴二维码。") }
        }
    }
}

final class ScannerContainer: UIViewController {
    let scanner: DataScannerViewController
    let onError: (String) -> Void
    init(scanner: DataScannerViewController, onError: @escaping (String) -> Void) { self.scanner = scanner; self.onError = onError; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) not supported") }
    override func viewDidLoad() {
        super.viewDidLoad(); addChild(scanner); view.addSubview(scanner.view); scanner.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([scanner.view.leadingAnchor.constraint(equalTo: view.leadingAnchor), scanner.view.trailingAnchor.constraint(equalTo: view.trailingAnchor), scanner.view.topAnchor.constraint(equalTo: view.topAnchor), scanner.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
        scanner.didMove(toParent: self)
    }
    override func viewDidAppear(_ animated: Bool) { super.viewDidAppear(animated); do { if !scanner.isScanning { try scanner.startScanning() } } catch { onError("相机启动失败，请重试。") } }
    override func viewWillDisappear(_ animated: Bool) { scanner.stopScanning(); super.viewWillDisappear(animated) }
}
