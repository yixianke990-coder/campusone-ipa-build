import Foundation

struct Service: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var category: String
    var symbol: String
    var tint: String
    var storeID: String? = nil
    var url: String = ""
    var hosts: String = ""
    var enabled: Bool = true
    var showOnHome: Bool = true
    var externalBrowser: Bool = false
    var isBuiltIn: Bool { storeID != nil }
    var storeURL: URL? { storeID.flatMap { URL(string: "https://apps.apple.com/cn/app/id\($0)") } }
    static let defaults: [Service] = [
        Service(id: UUID(uuidString: "00000000-0000-4000-8000-000000000001")!, name: "慧生活798", category: "澡堂", symbol: "shower", tint: "blue", storeID: "1490809012"),
        Service(id: UUID(uuidString: "00000000-0000-4000-8000-000000000002")!, name: "喜鹊儿", category: "课表", symbol: "calendar", tint: "orange", storeID: "1152127141"),
        Service(id: UUID(uuidString: "00000000-0000-4000-8000-000000000003")!, name: "U净", category: "洗衣", symbol: "washer", tint: "indigo", storeID: "1142157881"),
        Service(id: UUID(uuidString: "00000000-0000-4000-8000-000000000004")!, name: "趣智校园", category: "校园用水", symbol: "drop", tint: "teal", storeID: "1264484428")
    ]
}

struct Course: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var location: String
    var weekday: Int // 1=Monday, 7=Sunday
    var start: Int // minutes after midnight
    var end: Int
    static let days = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    static func time(_ minute: Int) -> String { String(format: "%02d:%02d", minute / 60, minute % 60) }
    static func today(_ date: Date = Date(), calendar: Calendar = .current) -> Int { (calendar.component(.weekday, from: date) + 5) % 7 + 1 }
}

// No automatic execution, no unknown schemes, no fuzzy domain matching.
enum Routing {
    static func httpsURL(_ raw: String) -> URL? {
        guard let c = URLComponents(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
              c.scheme?.lowercased() == "https", let host = c.host, !host.isEmpty,
              c.user == nil, c.password == nil, c.port == nil || c.port == 443,
              let url = c.url else { return nil }
        return url
    }
    static func normalizedHosts(_ raw: String) -> [String] {
        raw.split(whereSeparator: { $0.isWhitespace || $0 == "," || $0 == "，" })
            .map { $0.lowercased() }
            .filter { value in
                guard value.contains("."), let c = URLComponents(string: "https://" + value) else { return false }
                return c.host == value && c.user == nil && c.password == nil && c.port == nil && c.path.isEmpty && c.query == nil && c.fragment == nil && !value.contains("*")
            }
    }
    static func matches(_ raw: String, services: [Service]) -> [Service] {
        guard let host = httpsURL(raw)?.host?.lowercased() else { return [] }
        return services.filter { $0.enabled && normalizedHosts($0.hosts).contains(host) }
    }
}

// Local-only records. They are not provider orders, balances or device state.
struct FavoriteDevice: Codable, Identifiable, Equatable {
    var id = UUID()
    var serviceID: UUID
    var name: String
    var reference: String = "" // optional user-entered public device number, never QR payload
}
struct ExpenseEntry: Codable, Identifiable, Equatable {
    var id = UUID()
    var serviceID: UUID
    var cents: Int
    var date: Date = Date()
    var note: String = ""
}
struct LocalTimer: Codable, Identifiable, Equatable {
    var id = UUID()
    var serviceID: UUID
    var label: String
    var end: Date
    var notificationID: String { "campus.timer.\(id.uuidString)" }
}
struct AccountProfile: Codable, Identifiable, Equatable {
    var id = UUID()
    var serviceID: UUID
}
enum LocalTools {
    static func cents(_ raw: String) -> Int? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let parts = text.split(separator: ".", omittingEmptySubsequences: false)
        guard (1...2).contains(parts.count), !parts[0].isEmpty,
              parts.allSatisfy({ $0.utf8.allSatisfy { (48...57).contains($0) } }),
              let whole = Int(parts[0]), whole <= 100_000 else { return nil }
        let fraction = parts.count == 2 ? String(parts[1]) : ""
        guard fraction.count <= 2 else { return nil }
        let value = whole * 100 + (Int(fraction.padding(toLength: 2, withPad: "0", startingAt: 0)) ?? 0)
        return value > 0 ? value : nil
    }
    static func total(_ entries: [ExpenseEntry], serviceID: UUID, interval: DateInterval) -> Int {
        entries.filter { $0.serviceID == serviceID && $0.date >= interval.start && $0.date < interval.end }.reduce(0) { $0 + $1.cents }
    }
    static func currency(_ cents: Int) -> String { String(format: "¥%d.%02d", cents / 100, cents % 100) }
    static func publicReference(_ text: String) -> Bool {
        text.utf8.count <= 64 && text.utf8.allSatisfy { (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 45 || $0 == 95 }
    }
    struct CourseImport: Decodable {
        let name: String, location: String
        let weekday: Int, start: Int, end: Int
    }
    enum ImportError: Error { case invalid }
    static func importCourses(_ data: Data) throws -> [Course] {
        guard data.count <= 512_000 else { throw ImportError.invalid }
        let input = try JSONDecoder().decode([CourseImport].self, from: data)
        guard !input.isEmpty, input.count <= 500 else { throw ImportError.invalid }
        return try input.map { row in
            let name = row.name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !name.isEmpty, name.count <= 120, row.location.count <= 120, (1...7).contains(row.weekday), row.start >= 0, row.end < 1440, row.start < row.end else { throw ImportError.invalid }
            return Course(name: name, location: row.location, weekday: row.weekday, start: row.start, end: row.end)
        }
    }
    static func mergeCourses(_ existing: [Course], _ incoming: [Course]) -> [Course] {
        var result = existing
        for course in incoming where !result.contains(where: { $0.name == course.name && $0.location == course.location && $0.weekday == course.weekday && $0.start == course.start && $0.end == course.end }) { result.append(course) }
        return result
    }
}
