# Campus One · 校园服务聚合客户端

**0.3.0 开发预览** · SwiftUI 原生 iOS 工程 · 不绑定学校 · 无第三方依赖

## 在 Mac 上运行

1. 安装 Xcode 26 或更新版本（需要 iOS 26 SDK，即使最低部署版本是 iOS 18）。
2. 双击 `CampusOne.xcodeproj`，选择 `CampusOne` scheme 和 iPhone 模拟器，按 ⌘R。
3. 真机运行：连接 iPhone，选择目标设备，在 Signing & Capabilities 中选择自己的 Team；若提示 Bundle ID 冲突，修改 `com.example.campusone` 为自己的唯一标识。按 ⌘R。相机扫码需支持 VisionKit DataScanner 的真实设备并授权相机。
4. iOS 26 使用原生 TabView、独立搜索 TabRole、滚动收缩导航栏；iOS 18 自动回退。遵循系统浅色/深色模式。此包不是 IPA，也未签名。

## 已实现的源码功能

- 首页：今日手动课表、可配置的服务卡片、统一扫码入口。
- 四个内置平台：慧生活798、喜鹊儿、U净、趣智校园。App Store 官方入口（不等同于直接打开原 App），可填写已确认的官方 HTTPS 入口。
- 服务列表：启停、首页显示、排序；添加/编辑/删除自定义 HTTPS 网页，使用系统 Safari 或应用内 SFSafariViewController。学校信息和域名均未预置。
- 账号：各服务有独立 UUID，Keychain 分别存放**账号备注**，不保存密码或令牌。实际认证仍由原服务完成。网页 Safari 会话不保证每服务隔离。
- 课表：手动添加、编辑、删除、按星期查看；首页显示当天课程。尚未接入喜鹊儿同步、教学周和单双周逻辑。
- 扫码：VisionKit 本机标准二维码扫描；也可粘贴文字。仅匹配用户事先确认的精确 HTTPS 域名，重复规则或无匹配时手动选服务；不会自动打开任意二维码网址、传输设备编号、控制设备或付款。未预设任何未经验证的真实扫码域名。
- 搜索：已启用服务及本地课程。持久化：UserDefaults 保存服务配置和手动课表，Keychain 保存账号备注。无后台服务器、无广告 SDK、无分析追踪。

## v0.3 新增功能（参照 GitHub 项目功能，独立实现）

- 慧生活798、U净、趣智校园：各自的设备收藏、设备别名、公开设备编号、排序和删除；手动消费记录，今日、本月、本年金额统计；手动倒计时及本地通知。均为本地工具，不代表设备绑定、真实订单或消费余额。
- 四个内置服务分别支持多条账号备注，保存在 Keychain；不是实际登录或会话切换。原先的单条备注仍可使用。
- 喜鹊儿：支持 Campus One 自定义 JSON 格式的课程批量导入，自动去重，并保留原有课表。不是喜鹊儿在线同步或原始 JSON 适配。
- 统一扫码：新增相册二维码识别，使用 PhotosPicker 和 Vision 本机识别；多二维码要求裁剪重试。不会自动发送二维码或操作设备。
- 外观：跟随系统、浅色、深色。
- 详细来源及接入阻碍见 `GITHUB_INTEGRATION.md`。未直接复制第三方仓库代码。

## 添加学校学工系统（仅用户自行配置）

服务 → 添加自定义网页 → 名称填“学工系统”或“请假” → 填写学校确认的稳定 HTTPS 入口 → 保存。不要填带一次性 code、ticket、token 的登录回调链接。若学校 CAS / 企业微信认证无法在应用内完成，切换为系统浏览器或使用学校官方入口。本版本未实现企业微信 SDK 或学校 SSO。

## 源码结构

| 文件 | 功能 |
| --- | --- |
| CampusOneApp.swift | App 入口、系统标签栏、首页、搜索 |
| Models.swift | 服务/课程模型、URL 安全检查、扫码规则匹配 |
| Store.swift | 本地持久化、Keychain 账号备注 |
| LocalFeatures.swift | 设备收藏、手动消费统计、计时、账号备注、课表导入 |
| Services.swift | 服务管理、设置、网页容器、账号配置 |
| Courses.swift | 本地课程 CRUD、每周课表 |
| Scanner.swift | 相机扫码、规则匹配、确认入口 |
| PrivacyInfo.xcprivacy | UserDefaults 所需用途声明 |
| Tests/main.swift | 可在 macOS 或 Linux 运行的纯 Swift 规则测试 |

## 测试

```bash
swiftc CampusOne/Models.swift Tests/main.swift -o /tmp/campus-one-tests
/tmp/campus-one-tests
swiftc -frontend -parse CampusOne/*.swift
```

在交付环境中，26 项纯 Swift 断言通过，全部 Swift 源文件语法解析通过；Xcode 工程及隐私 plist 通过 plutil 检查。环境为 Linux，无 Xcode/iOS SDK；**未进行 iOS 类型检查、模拟器/真机编译或 UI/相机/Keychain/网络实测**。Xcode 运行可能仍需修正。应用图标及发布签名尚未制作。

建议真机验收：启动/切换五个标签页、重新启动后本地配置是否保留、保存及清除不同账号备注、添加及删除网页、课表编辑、拒绝相机权限、扫描多个服务的实际二维码、冲突及未知域名、认证回退。扫码规则测试使用 example.com 示例，不代表实际供应商域名。

## 后续接入计划（尚未实现）

1. 获取各服务商公开或授权接口、确认使用条款及授权机制，再实现真实独立账户会话和只读查询。
2. 对每个平台的真实设备二维码建立测试样本；验证合法的官方 Universal Link 或 SDK 跳转，并确认设备编号传递是否受支持。
3. 喜鹊儿课表导入与同步：评估官方接口、支持学校选择、教学周与调课。
4. 慧生活798、U净、趣智校园：在授权情况下验证查询、设备操作与独立支付；禁止自动启动设备或未经用户确认的扣款。
5. Face ID 可选本地保护、逐服务独立网页会话、正式图标、真机测试、TestFlight 发布。

## 公开参考（未复制或依赖这些仓库的代码）

- Apple：<https://developer.apple.com/videos/play/wwdc2025/323/>、<https://developer.apple.com/documentation/swiftui/tabrole/search>
- 慧生活798（第三方 Android 饮水项目，不代表澡堂兼容）：<https://github.com/nocookies111/life-798>
- 喜鹊儿（第三方封装）：<https://github.com/lizhengqiang/kingosoft_api>
- U净参考（特定学校的聚合项目）：<https://github.com/JasonBeam/campus-daily>
- 趣智校园（第三方客户端）：<https://github.com/yehu-imei/linyu>

所有仓库的授权、许可证及适配性在任何源码复用前必须逐一核查。内置 App Store ID 已按公开页面核对：1490809012、1152127141、1142157881、1264484428。本项目不是学校或服务商官方 App。
