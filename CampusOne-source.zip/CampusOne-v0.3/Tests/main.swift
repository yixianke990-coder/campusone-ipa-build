import Foundation
var services = Service.defaults
services[0].hosts = "devices.example.com"
services[2].hosts = "laundry.example.com"
func check(_ label: String, _ passed: Bool) { if !passed { fatalError("FAIL: \(label)") }; print("PASS: \(label)") }
check("four providers", services.count == 4 && Set(services.map(\.id)).count == 4)
check("no unverified default matching", Routing.matches("https://devices.example.com/a", services: Service.defaults).isEmpty)
check("exact host", Routing.matches("https://devices.example.com/a?device=123", services: services).map(\.name) == ["慧生活798"])
check("case insensitive host", Routing.matches("https://DEVICES.EXAMPLE.COM/a", services: services).count == 1)
check("suffix attack rejected", Routing.matches("https://devices.example.com.evil.test/a", services: services).isEmpty)
check("userinfo rejected", Routing.matches("https://devices.example.com@evil.test/a", services: services).isEmpty)
check("userinfo even at allowed host rejected", Routing.matches("https://abc@devices.example.com/a", services: services).isEmpty)
check("subdomain not assumed", Routing.matches("https://a.devices.example.com/a", services: services).isEmpty)
check("plain number rejected", Routing.matches("12345", services: services).isEmpty)
check("insecure or unknown schemes rejected", Routing.httpsURL("http://devices.example.com") == nil && Routing.httpsURL("javascript:alert(1)") == nil)
check("nonstandard port rejected", Routing.httpsURL("https://devices.example.com:444/") == nil)
check("invalid rules rejected", Routing.normalizedHosts("*.example.com, example.com/path, a@example.com, valid.example.com") == ["valid.example.com"])
services[2].hosts = "devices.example.com"
check("ambiguous routes preserved", Routing.matches("https://devices.example.com", services: services).count == 2)
services[0].enabled = false
check("disabled excluded", Routing.matches("https://devices.example.com", services: services).map(\.name) == ["U净"])
let data = try JSONEncoder().encode(services)
let restored = try JSONDecoder().decode([Service].self, from: data)
check("configuration round trip", restored == services)
check("time formatting", Course.time(9*60+5) == "09:05")
let calendar = Calendar(identifier: .gregorian)
check("Monday mapping", Course.today(calendar.date(from: DateComponents(year: 2026, month: 11, day: 23))!, calendar: calendar) == 1)
check("Sunday mapping", Course.today(calendar.date(from: DateComponents(year: 2026, month: 11, day: 29))!, calendar: calendar) == 7)
check("exact cents", LocalTools.cents("1.09") == 109 && LocalTools.cents("0.1") == 10)
check("reject malformed amount", ["-1", "0", "1.001", "NaN", "1e2", "100001", "abc"].allSatisfy { LocalTools.cents($0) == nil })
check("public device number", LocalTools.publicReference("A-001_test") && !LocalTools.publicReference("https://example.com?token=123"))
let start = Date(timeIntervalSince1970: 1000)
let interval = DateInterval(start: start, duration: 100)
let e = [ExpenseEntry(serviceID: services[0].id, cents: 123, date: start), ExpenseEntry(serviceID: services[1].id, cents: 456, date: start), ExpenseEntry(serviceID: services[0].id, cents: 999, date: interval.end)]
check("provider and period isolation", LocalTools.total(e, serviceID: services[0].id, interval: interval) == 123)
let input = Data("""
[{"name":"Math","location":"A1","weekday":1,"start":480,"end":570}]
""".utf8)
let imported = try LocalTools.importCourses(input)
check("course import", imported.count == 1 && imported[0].start == 480)
check("deduplicate import", LocalTools.mergeCourses(imported, try LocalTools.importCourses(input)).count == 1)
check("invalid course rejected", (try? LocalTools.importCourses(Data("[{\"name\":\"X\",\"location\":\"\",\"weekday\":8,\"start\":480,\"end\":570}]".utf8))) == nil)
check("invalid time rejected", (try? LocalTools.importCourses(Data("[{\"name\":\"X\",\"location\":\"\",\"weekday\":1,\"start\":600,\"end\":570}]".utf8))) == nil)
